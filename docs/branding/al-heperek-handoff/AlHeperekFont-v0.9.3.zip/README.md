# Al Heperek Font 0.9.3

Compiled assets for BibleOnSite integration. Family: Al Heperek Font UI.
Regular 400, SemiBold 600, Bold 700; TTF for native/PDF, WOFF2 for web.
All Hebrew letters and digits use the selected design by default.

Selections: A22 / E26 / T21 / C28 / S35, including C28's paired final tsadi.
The nine SVG logos are already outlined from this release. The wide logo
has one wordmark beside the book; 24px repeats the 32px composition.

Preserve the bundled restricted LICENSE.txt, notices and all font bytes.
Application consumers may register/embed/copy these files and rasterize
the supplied outlined SVGs as required. Font outlines, metrics, features,
compiler/export code and releases are maintained in the font repository;
do not regenerate, subset, convert, relabel or patch the fonts downstream.
Report font defects to the maintainer for a new version.

Use the matching TTF/WOFF2 weight, not synthetic bold. Keep Taamey D and its
independent license for scripture/cantillation. Al Heperek excludes taamim.
Integrate license/TOS notices without relicensing the surrounding project.

Verify every copied font/logo against manifest.json SHA-256 values.
Canonical release: bible-on-site/al-heperek-font, tag v0.9.3.
Store listing/distribution is a separate application rollout decision.
