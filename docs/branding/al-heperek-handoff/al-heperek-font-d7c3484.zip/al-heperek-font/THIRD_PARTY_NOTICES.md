# Third-party notices

The restricted Al Heperek Font license applies to the original font and original project code. It does not replace the licenses of development tools or other fonts.

## Development tools

The following direct and principal transitive tools are installed as development dependencies. Exact versions and the complete dependency graph are recorded in `uv.lock`. Their distributions retain their own copyright notices and license files.

| Tool | Purpose | License reported by the installed distribution | Upstream |
| --- | --- | --- | --- |
| fontmake | Compile editable font sources | Apache-2.0 | [googlefonts/fontmake](https://github.com/googlefonts/fontmake) |
| FontTools | Font tables, outline conversion and inspection | MIT | [fonttools/fonttools](https://github.com/fonttools/fonttools) |
| ufoLib2 | Read and write UFO sources | Apache-2.0 | [fonttools/ufoLib2](https://github.com/fonttools/ufoLib2) |
| skia-pathops | Original contour geometry and overlap operations | BSD-3-Clause | [fonttools/skia-pathops](https://github.com/fonttools/skia-pathops) |
| uharfbuzz | Text shaping checks and specimens | Apache-2.0; bundled HarfBuzz retains its own notices | [harfbuzz/uharfbuzz](https://github.com/harfbuzz/uharfbuzz) |
| ufo2ft | Compile UFO outlines and features | MIT | [googlefonts/ufo2ft](https://github.com/googlefonts/ufo2ft) |
| Pillow | Raster review specimens | MIT-CMU | [python-pillow/Pillow](https://github.com/python-pillow/Pillow) |
| Brotli | WOFF2 compression support | MIT | [google/brotli](https://github.com/google/brotli) |
| pytest | Development checks | MIT | [pytest-dev/pytest](https://github.com/pytest-dev/pytest) |
| uv | Isolated dependency and Python management | MIT OR Apache-2.0 | [astral-sh/uv](https://github.com/astral-sh/uv) |

These packages are build and development tools, not imported font designs. This repository does not vendor their source trees or incorporate their licensed font outlines. If tool distributions are redistributed later, include the notices and license material required by those distributions.

## Taamey D

Taamey D is a separate third-party font used for cantillated Bible text by the wider Tanach Al Haperek project. Its glyphs, font sources and generated files remain under its own GPL license with the font-embedding exception. Relevant upstream rights holders are identified in its [font notice](https://github.com/bdenckla/MAM-basics/blob/main/in/font-support/taamey-d-1.2/FONT-NOTICE.txt).

No Taamey D font software is included in Al Heperek Font. The proprietary license in this repository imposes no restriction on rights granted by Taamey D or any other third-party license.
