# Al Heperek Font

An original Hebrew and Latin typeface for Tanach Al Haperek branding and general text. Its proportions, rhythm and baseline are intended to work beside Taamey D, while its letter construction is more contemporary and restrained.

This is a private, restricted-license project. Copyright © 2026 DoradSoft. See [LICENSE](LICENSE) for the permitted uses of its sources and generated fonts.

## Current stage

Version 0.9 adds an opt-in reconstruction of Yehuda's supplied SVG lettering.
Seven letters keep the supplied outlines in Bold; twenty more extend their
shared shoulders, entries, returns and sloping feet. All 27 Hebrew letters and
final forms have Regular 400, SemiBold 600 and Bold 700 masters, fitted spacing
and niqqud anchors. [View the compiled font sheet](specimens/yehuda.svg) or
[open the interactive comparison](specimens/yehuda.html). The source SVG and
its hash are recorded in `sources/yehuda/`; see [PROVENANCE.md](PROVENANCE.md).

Use `font-feature-settings: "ss03" 1` for this reconstruction. The existing
reading, display (`ss01`) and approved inscription (`ss02`) outlines remain
available. No website, application or store assets are replaced by this branch.

Each Hebrew letter has individually fitted sidebearings for its cut and weight. Pair adjustments and Hebrew word spacing were proofed with both ordinary and pointed words. The [word comparison](specimens/word-comparison.svg) sets version 0.6 on the right and version 0.5 on the left at the same sizes and weights.

The reading face is still the default. The prior inscription comparison is
available in [its original sheet](specimens/inscription.svg).

In 0.9.1, the left entrances of א ט מ ע צ ש ץ follow tav's lifted corner and
forward turn. Bet and final mem finish on a flat baseline, tet's arms stay
separate, and tsadi's branch ends inside its main stroke.

Version 0.9.2 fits the strokes of א צ ץ ג ע ש to resh's pen width, including
the diagonals and returning arms. Alef, tsadi and final tsadi share the same
right arm. Their proportions stay close to the earlier design, with open
spaces between alef's three strokes. Gimel has a continuous head, body and
feet; shin's lower-left turn and ayin's return are smoother. The reviewed
left entrances remain intact. Ten original tabular
lining figures now share the Hebrew stem weight, broad horizontal returns
and cut terminals. `ss03` selects these figures in Hebrew, Latin and standalone
digit runs; the installable study maps both Hebrew and digits by default.
[Compare the compiled strokes and figures](specimens/yehuda-weight.svg).

The next design review contains [20 alternatives each for א ע ט צ ש](specimens/alternatives.html),
100 numbered vector proposals in total. Each appears at display size and in a
32px word alongside the current font. Select any proposal to compare it with
the current letter; selection codes persist in the review URL. Five portable
SVG contact sheets are in `specimens/alternatives/`. These are unselected Bold
700 construction studies, not additional glyphs in the installed font.
Regenerate their specimens with `uv run python tools/yehuda_alternatives.py`.
The shared left head has since been optically reduced, following review of its
excessive prominence on alef. The same correction keeps all five sets aligned;
proposal IDs and their bodies, branches and feet are preserved.
[Compare the exact before/after outlines](specimens/alternatives/head-balance.svg),
including unchanged ת ה ח reference letters at the same body height.
Regenerate this comparison with `uv run python tools/yehuda_head_proof.py`.

### Second round: fewer anchors and complete context

[Review the second round](specimens/refinements.html): 20 new alternatives per
letter, explicitly following A01, E09, T07, C01 and S03 as directions, not approved
designs. IDs run from 21 through 40. Every card renders the exact requested
`אבגדהוזחטיכלמנסעפצקרשתךםןףץ 0123456789`, with all 27 letters and ten figures.
Context follows the other shortlisted directions and any new selections. Each
tsadi has its own matched final tsadi; choosing it updates both צ and ץ in
subsequent alphabet samples. The tsadi word now actually contains צ (`צדק`).

The new contours are traced directly with a small number of Bézier segments.
The renderer applies one affine transform; it does not union, offset, fit,
resample or simplify the authored outlines. Geometry QA uses Boolean operations
only to validate connectivity and area, never as the source of rendered paths.
It checks tangency at curve joins, allowing only explicitly marked intentional
corners. Authored anchor counts drop from 50/41/39/42/27 in the five directions
to 28/20/20/24/19. Final tsadi has 22 anchors.

Regenerate with `uv run python tools/yehuda_refinements.py`. The five portable
SVG sheets include the full alphabet and figures in every row; the
[comparison sheet](specimens/refinements/before-after.svg) shows the directions
beside one example from each new group. No second-round outline is installed in
the canonical font or application.

### Combined selection review

Dorad selected **A22, E26, T21, C28 and S35**, including the final tsadi paired
with C28. [Open the combined review](specimens/selected.html) to type arbitrary
text with all six forms in one actual font, compare the full alphabet and
digits, and inspect the matching logo family. The current scope is Bold 700.
The lighter weights and production adoption await the combined design review.

`uv run python tools/selected_review.py` reads the saved recipe in
`sources/yehuda/selected-refinements.json`, clones the Bold UFO into a temporary
build directory and replaces only the six selected `ss03` forms. Quadratic
turns are elevated exactly to cubic curves. The separate CFF OpenType/WOFF2
review face preserves the authored anchor counts and curve coordinates,
without overlap removal, fitting, integer rounding or additional contour points.
Compilation verifies all six actual output glyphs against the chosen sources,
checks default Hebrew/digit mapping and the cantillation exclusion, and checks
that the canonical master remains byte-identical.

`dist/selected/` contains the restricted-license review font and nine outlined
logo exports using that exact face. The wide logo uses one wordmark beside the
book; every על uses E26. These are separate review artifacts and do not replace
the canonical masters, application exports or store assets.

### Existing logo review

The first-round page also proposes a simpler horizontal logo with one wordmark beside the
book symbol, omitting the duplicated stacked name. This layout is also pending
review and has not replaced the existing website or logo assets.

The matching logo family is generated with `uv run python tools/yehuda_logos.py`.
It uses the compiled Bold `ss03` outlines for every word, including each
instance of על. Glyph-free SVG layouts in `sources/yehuda/logo-layouts/`
retain the project book symbol and single launcher tile. The export includes
light/reversed horizontal and compact logos, the 1024px launcher source and
16/24/32/48px marks; 24 and 32 share exactly the same composition.
See [the before/after asset sheet](specimens/yehuda-logos.svg).

The [motif sheet](specimens/motifs.svg) shows the right shoulder of ו ר ח ך ף ה ב ת, the lower turn of פ ס ט, the left entry of ט ש, the descending turn of ק ל and the upper terminal of א צ ץ in the reading face. Its ruled row shows ל above the roof and ך ן ף ץ ק below the baseline. The [interactive specimen](specimens/index.html) includes all three settings and a reading sample at 16, 24, 32 and 48 CSS pixels.

A successful build validates the font files; it does not mean the type design has received visual approval or has been installed on the production website or app. Font and logo adoption awaits design review.

The initial family contains Regular 400, SemiBold 600 and Bold 700. Its scope is general Hebrew and Latin text, including the Hebrew final forms, digits and punctuation. Niqqud is developed independently as part of the general-text coverage. Generated coverage reports and specimens describe the actual supported characters.

**Cantillation is intentionally excluded.** Al Heperek Font must not map U+0591–U+05AF. Existing cantillated Bible text continues to use Taamey D under Taamey D's own license.

## Sources and build

The approved inscription cut is exported for website, native and document use with `uv run python tools/export_ui.py`. `dist/ui/` contains three TTF and three WOFF2 faces named Al Heperek Font UI. The export maps Hebrew Unicode characters directly to the approved `ss02` glyphs, preserving their outlines, spacing and individually fitted mark positioning. Applications can use this cut without platform-specific OpenType feature settings. The original masters and review fonts retain all their cuts.

`uv run python tools/export_yehuda.py` exports the unapproved reconstruction to
`dist/yehuda/` as the separate installable **Al Heperek Yehuda Study** family,
with `ss03` mapped to the default Hebrew letters and digits. This avoids replacing the
approved UI font during design review. `tools/yehuda_study.py` is an explicit
authoring operation; normal builds compile the committed UFOs.

`uv run python tools/export_yehuda_ui.py` produces the same reconstruction in
`dist/yehuda-ui/` under the application's existing **Al Heperek Font UI** family
and filenames. This keeps the website, native, email and PDF loaders stable
while their repository assets are updated for review. The earlier approved
`dist/ui/` export is retained separately. Both new exports map the Hebrew
letters and companion figures directly, without requiring feature controls.

To review locally, run `uv run python tools/yehuda_proof.py`, then
`uv run python -m http.server 4177 --bind 127.0.0.1` and open
`http://127.0.0.1:4177/specimens/yehuda.html`. The optional local Taamey D pairing
expects a separately licensed reference font at `build/reference/TaameyD.woff2`;
the font is not required to build or use the study. No reference binary is
committed or included in the Al Heperek font files.

For review in the actual website, create a separate worktree of the brand
adoption branch and reuse its installed website dependencies. Then run:

```sh
uv run python tools/preview_website.py --source-checkout /path/to/existing-site --preview-checkout /path/to/separate-review-worktree --node /path/to/node
```

This overlays only the review font and local generated bootstrap artifacts in
that checkout. Start its normal Next.js development server on a free local
port. The production content is read through the existing local environment;
this tool does not change production data or deploy the font. The exact source
site commit and preview font hashes are saved in `build/website-preview.json`.
Add `--logos` after generating the website's logo assets to preview the same
logo family. The tool checks SVG hashes against this font export before
copying them, and records the logo hashes in the local review manifest.

The editable UFO sources under `sources/` are the authoring source of truth. Their contours, metrics and features can be edited in UFO-compatible font tools. The original construction modules record the independent drawings. Routine builds compile the committed UFOs. `nib_motifs.py`, `reading_hebrew.py` and `pen_hebrew.py` contain the Hebrew motifs and their use in individual letters. `editorial_latin.py` contains the Latin alphabet and figures. Earlier construction helpers supply punctuation and marks.

The build uses [UFO 3](https://unifiedfontobject.org/versions/ufo3/), [fontmake](https://github.com/googlefonts/fontmake) and FontTools. Dependencies are isolated and pinned by `uv.lock`.

Requirements: Python 3.13 or 3.14 and [uv](https://docs.astral.sh/uv/). CI uses Python 3.14.

```sh
uv sync --frozen
uv run python tools/build.py
uv run python tools/qa.py
uv run pytest
uv run python tools/specimen.py
```

Generated font binaries are written to `dist/`; review specimens are written to `specimens/`. The `build/` directory holds temporary build and QA output and is not an authoring source.

## Repository layout

```text
sources/             Editable original font masters and features
tools/               Build, QA, specimen and original bootstrap utilities
src/al_heperek/      Original construction helpers
tests/               Coverage, shaping and font integrity checks
specimens/           Review material generated from the built fonts
dist/                Generated font binaries
LICENSE              Restricted Al Heperek Font license
PROVENANCE.md        Authorship and reference boundaries
THIRD_PARTY_NOTICES.md
uv.lock              Reproducible development dependencies
```

## Review and validation

Review the complete Hebrew and Latin alphabets, final forms, mixed RTL/LTR strings, numbers, punctuation and small text sizes. Inspect baseline compatibility beside Taamey D without importing Taamey D data into the new font. Any unsupported character must fall back explicitly to another suitable font.

CI runs frozen dependency installation, the font build, QA and tests. It generates specimens and retains font and review files as private workflow artifacts. It does not publish a public font release or deploy fonts to the website or app.

## Relationship to Taamey D

Taamey D is a visual compatibility reference and a source of ideas about project organization. Al Heperek Font does not import its Git history, glyph outlines, OpenType positioning, feature code or build scripts. The two fonts remain separate works with separate licenses. Details and reference links are recorded in [PROVENANCE.md](PROVENANCE.md).

The site's and app's font notice must distinguish the restricted Al Heperek Font license from rights granted by Taamey D and other third-party font licenses.
