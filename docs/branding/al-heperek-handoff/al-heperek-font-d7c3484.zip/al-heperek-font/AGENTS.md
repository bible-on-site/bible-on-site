# Al Heperek Font

This repository contains independently authored, restricted-license font sources and build code. Preserve `LICENSE`, copyright metadata and the distinction between this font and separately licensed third-party works.

## Source boundaries

- Do not import or trace another font's outlines, anchors, positioning, features, hinting or source code into this font.
- Taamey D is a visual compatibility and project-organization reference only. It remains a separate GPL-licensed font for cantillated text.
- Keep `PROVENANCE.md` and `THIRD_PARTY_NOTICES.md` accurate when adding external material or dependencies.
- Do not map Hebrew cantillation U+0591–U+05AF in Al Heperek Font. Test the exclusion in generated binaries.
- The committed UFO masters under `sources/` are canonical editable sources. A normal build must compile them without regenerating or replacing their design.

## Validation

Use the locked development environment:

```sh
uv sync --frozen
uv run python tools/build.py
uv run python tools/qa.py
uv run pytest
uv run python tools/specimen.py
```

Check actual specimens as well as binary validity. Inspect Hebrew final forms, mixed RTL/LTR text, numbers, punctuation, niqqud where supported, small UI sizes and clipping. Keep original sources and generated output clearly separated.

## Delivery

Commit and push finished, validated repository changes. Follow the user's established review requirements for font designs and production logo adoption. Do not treat a green build as visual approval, publish a public font release automatically, or change repository visibility as a side effect of development.
