"""Regression checks on the actual generated font family, not drawing helpers."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import unicodedata

import pytest
from fontTools.ttLib import TTFont
from fontTools.pens.pointInsidePen import PointInsidePen
from ufoLib2 import Font

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('al_heperek_qa', ROOT / 'tools/qa.py')
qa = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = qa
spec.loader.exec_module(qa)


@pytest.fixture(params=list(qa.STYLES.items()), ids=list(qa.STYLES))
def built_font(request):
    style, weight = request.param
    file = ROOT / 'dist/ttf' / f'AlHeperek-{style}.ttf'
    assert file.is_file(), 'Run uv run python tools/build.py before the tests'
    with TTFont(file, recalcTimestamp=False) as font:
        yield style, weight, file, font


def test_general_text_coverage_and_no_cantillation(built_font):
    _, _, _, font = built_font
    actual = set(font.getBestCmap())
    expected = set(json.loads((ROOT / 'sources/charset.json').read_text(encoding='utf-8'))['codepoints'])
    assert actual == expected
    assert set(range(0x20, 0x7F)) <= actual
    assert set(range(0x05D0, 0x05EB)) <= actual
    assert {0x05F3, 0x05F4} <= actual
    assert not any(0x0591 <= cp <= 0x05AF for cp in actual)


def test_real_family_names_restricted_license_and_embedding_flag(built_font):
    style, weight, _, font = built_font
    assert qa.preferred_name(font, 16, 1) == 'Al Heperek Font'
    assert qa.preferred_name(font, 17, 2) == style
    assert font['OS/2'].usWeightClass == weight
    assert font['OS/2'].fsType == 4
    assert 'DoradSoft' in font['name'].getDebugName(0)
    assert font['name'].getDebugName(13).strip() == (ROOT / 'LICENSE').read_text(encoding='utf-8').strip()


def test_zero_advance_niqqud_and_real_mark_attachment(built_font):
    _, _, file, font = built_font
    cmap = font.getBestCmap()
    marks = [cp for cp in cmap if unicodedata.combining(chr(cp))]
    assert marks
    assert all(font['hmtx'][cmap[cp]][0] == 0 for cp in marks)
    data = file.read_bytes()
    for text in qa.MARK_CASES:
        positioned = qa.shape(data, text, features={'mark': True, 'mkmk': True})
        unpositioned = qa.shape(data, text, features={'mark': False, 'mkmk': False})
        assert positioned != unpositioned, text
        assert any(item['xAdvance'] == 0 and (item['xOffset'] or item['yOffset']) for item in positioned), text


def test_av_kerning_is_applied(built_font):
    _, _, file, _ = built_font
    data = file.read_bytes()
    on = qa.shape(data, 'AV', 'ltr', 'Latn', {'kern': True})
    off = qa.shape(data, 'AV', 'ltr', 'Latn', {'kern': False})
    assert 0 < sum(item['xAdvance'] for item in on) < sum(item['xAdvance'] for item in off)


@pytest.fixture(params=[{}, {'ss01': True}, {'ss02': True}, {'ss03': True}], ids=['reading', 'display', 'inscription', 'yehuda'])
def hebrew_features(request):
    return request.param


def test_hebrew_pairs_kern_across_niqqud_without_displacing_the_mark(built_font, hebrew_features):
    _, _, file, _ = built_font
    data = file.read_bytes()

    def measure(text, kern):
        run = qa.shape(data, text, features={**hebrew_features, 'kern': kern, 'mark': True})
        cursor = 0
        first_cluster = {}
        for item in run:
            if item['cluster'] == 0:
                kind = 'base' if item['xAdvance'] else 'mark'
                first_cluster[kind] = (cursor + item['xOffset'], item['yOffset'])
            cursor += item['xAdvance']
        return cursor, first_cluster

    bare_on, _ = measure('רק', True)
    bare_off, _ = measure('רק', False)
    pointed_on, on = measure('רַק', True)
    pointed_off, off = measure('רַק', False)
    assert bare_off - bare_on == pointed_off - pointed_on > 0
    for axis in (0, 1):
        assert on['mark'][axis] - on['base'][axis] == off['mark'][axis] - off['base'][axis]


def test_hebrew_word_space_and_latin_word_space_are_fitted_separately(built_font, hebrew_features):
    _, _, file, font = built_font
    data = file.read_bytes()
    space_width = font['hmtx'][font.getBestCmap()[ord(' ')]][0]
    def width(text):
        return sum(g['xAdvance'] for g in qa.shape(data, text, features=hebrew_features))

    word = 'בַּיִת'
    for separator in (' ', '\u00a0'):
        assert 0 < width(word + separator) - width(word) < space_width
    latin_word = qa.shape(data, 'day', 'ltr', 'Latn')
    spaced = qa.shape(data, 'day ', 'ltr', 'Latn')
    assert sum(g['xAdvance'] for g in spaced) - sum(g['xAdvance'] for g in latin_word) == space_width


@pytest.mark.parametrize('tag', ['ss01', 'ss02', 'ss03'])
def test_display_cut_covers_the_entire_hebrew_alphabet(built_font, tag):
    _, _, file, font = built_font
    data = file.read_bytes()
    for cp in range(0x05D0, 0x05EB):
        ch = chr(cp)
        normal = qa.shape(data, ch)[0]['glyph']
        poster = qa.shape(data, ch, features={tag: True})[0]['glyph']
        assert font.getGlyphName(poster) == font.getGlyphName(normal) + '.' + tag, ch
        regular_shape = font['glyf'][font.getGlyphName(normal)]
        display_shape = font['glyf'][font.getGlyphName(poster)]
        assert regular_shape.coordinates != display_shape.coordinates, ch
    for text in qa.MARK_CASES:
        on = qa.shape(data, text, features={tag: True, 'mark': True})
        off = qa.shape(data, text, features={tag: True, 'mark': False})
        assert on != off and all(g['glyph'] for g in on), text
    assert qa.shape(data, 'Al Heperek', 'ltr', 'Latn') == qa.shape(
        data, 'Al Heperek', 'ltr', 'Latn', {tag: True})


def test_inscription_niqqud_uses_its_own_fitted_anchors(built_font):
    style, _, file, font = built_font
    data = file.read_bytes()
    marks = {'bottom': 'ִ', 'center': 'ּ', 'top': 'ֹ', 'shin': 'ׁ', 'sin': 'ׂ'}
    with Font.open(ROOT / 'sources' / f'AlHeperek-{style}.ufo') as source:
        for cp in range(0x05D0, 0x05EB):
            letter = chr(cp)
            glyph_name = font.getBestCmap()[cp] + '.ss02'
            anchors = {a.name: (a.x, a.y) for a in source[glyph_name].anchors}
            expected = set(marks) if letter == 'ש' else {'bottom', 'center', 'top'}
            assert anchors.keys() == expected, letter
            for anchor, point in anchors.items():
                mark, base = qa.shape(data, letter + marks[anchor], features={'ss02': True})
                assert font.getGlyphName(base['glyph']) == glyph_name and mark['xAdvance'] == 0
                assert (mark['xOffset'] - base['xOffset'], mark['yOffset'] - base['yOffset']) == point


def test_full_height_hebrew_reaches_the_shared_optical_baseline(built_font):
    _, _, _, font = built_font
    for letter in 'אבגדהוזחטכלמנסעפצרשת':
        bounds = qa.glyph_bounds(font, font.getBestCmap()[ord(letter)])
        assert -35 <= bounds[1] <= 0, (letter, bounds)


def test_hebrew_ascender_and_descender_inventory(built_font, hebrew_features):
    _, _, file, font = built_font
    data = file.read_bytes()
    ascenders, descenders = set(), set()
    for cp in range(0x05D0, 0x05EB):
        ch = chr(cp)
        glyph = qa.shape(data, ch, features=hebrew_features)[0]['glyph']
        _, bottom, _, top = qa.glyph_bounds(font, font.getGlyphName(glyph))
        # Exclude normal optical overshoot around the 0–650 body.
        if top > 725:
            ascenders.add(ch)
        if bottom < -75:
            descenders.add(ch)
    assert ascenders == {'ל'}
    assert descenders == set('ךןףץק')


def test_alef_branches_attach_on_opposite_sides_in_reading_order(built_font, hebrew_features):
    _, _, file, font = built_font
    index = qa.shape(file.read_bytes(), 'א', features=hebrew_features)[0]['glyph']
    glyphs = font.getGlyphSet()
    alef = glyphs[font.getGlyphName(index)]
    # Between the high joint of the left leg and the lower joint of the
    # right arm, a scan must cross all three strokes with two open spaces.
    for y in (315, 340, 365, 390):
        sections, previous = 0, False
        for x in range(0, alef.width, 6):
            probe = PointInsidePen(glyphs, (x, y))
            alef.draw(probe)
            inside = probe.getResult()
            sections += int(inside and not previous)
            previous = inside
        if sections == 3:
            return
    pytest.fail('The two arms of alef lost their overlapping vertical span')


def test_ayin_left_shaft_has_one_continuous_lean(built_font, hebrew_features):
    _, _, file, font = built_font
    index = qa.shape(file.read_bytes(), 'ע', features=hebrew_features)[0]['glyph']
    glyphs = font.getGlyphSet()
    ayin = glyphs[font.getGlyphName(index)]
    centers = []
    # Scan only the shaft between the head and the fork. The first ink run
    # from the physical left is the shaft, the second is the outer bowl.
    # The SVG cut now has tav's full-depth roof entrance. Above 410 units the
    # scan enters that head; assess the straight shaft below it in this cut.
    heights = (230, 275, 320, 365, 410) if hebrew_features.get('ss03') else (250, 320, 390, 460, 530)
    for height in heights:
        shaft = []
        for x in range(0, ayin.width, 2):
            probe = PointInsidePen(glyphs, (x, height))
            ayin.draw(probe)
            if probe.getResult():
                shaft.append(x)
            elif shaft:
                break
        assert shaft, height
        centers.append((shaft[0] + shaft[-1]) / 2)
    assert centers[0] > centers[-1]
    for i, actual in enumerate(centers[1:-1], start=1):
        interpolated = centers[0] + i * (centers[-1] - centers[0]) / 4
        assert abs(actual - interpolated) <= 5


def test_closed_counters_remain_open_in_the_compiled_font(built_font, hebrew_features):
    _, _, file, font = built_font
    glyphs = font.getGlyphSet()
    for letter, height in [('ם', 650), ('ס', 650), ('O', 700), ('o', 515), ('0', 700)]:
        if letter in 'םס':
            index = qa.shape(file.read_bytes(), letter, features=hebrew_features)[0]['glyph']
            name = font.getGlyphName(index)
        else:
            name = font.getBestCmap()[ord(letter)]
        advance = font['hmtx'][name][0]
        pen = PointInsidePen(glyphs, (advance / 2, height / 2), evenOdd=False)
        glyphs[name].draw(pen)
        assert not pen.getResult(), f'Counter filled in {letter}'


@pytest.mark.parametrize('case,text,direction,script', qa.SHAPING_CASES, ids=[case[0] for case in qa.SHAPING_CASES])
def test_representative_text_shapes_without_missing_glyphs_or_clipping(built_font, case, text, direction, script):
    _, _, file, font = built_font
    positioned = qa.shape(file.read_bytes(), text, direction, script)
    assert positioned and all(item['glyph'] != 0 for item in positioned), case
    bounds = qa.positioned_ink_bounds(font, positioned)
    assert bounds is not None
    assert font['hhea'].descent <= bounds[1] <= bounds[3] <= font['hhea'].ascent, (case, bounds)


def test_woff2_preserves_all_outlines_metrics_and_features(built_font):
    style, _, _, font = built_font
    result = qa.verify_woff2_roundtrip(font, ROOT / 'dist/woff2' / f'AlHeperek-{style}.woff2')
    assert result['status'] == 'passed'
    assert result['outlineCount'] == len(font.getGlyphOrder())


def test_distribution_hashes_and_license_match_built_files():
    manifest = json.loads((ROOT / 'dist/manifest.json').read_text(encoding='utf-8'))
    assert manifest['family'] == 'Al Heperek Font'
    assert manifest['cantillation'] is False
    assert len(manifest['files']) == 6
    for file in manifest['files']:
        assert hashlib.sha256((ROOT / file['file']).read_bytes()).hexdigest() == file['sha256']
    assert (ROOT / 'dist/LICENSE.txt').read_bytes() == (ROOT / 'LICENSE').read_bytes()


def test_full_family_binary_audit_passes():
    report = qa.audit_family(ROOT)
    assert report['status'] == 'passed', report
