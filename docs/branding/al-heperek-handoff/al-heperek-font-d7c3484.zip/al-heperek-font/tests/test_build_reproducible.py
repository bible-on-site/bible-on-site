"""The normal compiler must preserve editable sources and reproduce its binaries."""
from pathlib import Path
import hashlib
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]

def snapshot(directory):
    return {file.relative_to(directory).as_posix(): hashlib.sha256(file.read_bytes()).hexdigest() for file in directory.rglob('*') if file.is_file()}

def test_build_reproduces_binaries_without_rewriting_sources():
    sources_before = snapshot(ROOT / 'sources')
    output_before = snapshot(ROOT / 'dist')
    assert output_before, 'Run tools/build.py before the test suite'
    subprocess.run([sys.executable, str(ROOT / 'tools/build.py')], cwd=ROOT, check=True, capture_output=True, text=True)
    assert snapshot(ROOT / 'sources') == sources_before
    assert snapshot(ROOT / 'dist') == output_before
