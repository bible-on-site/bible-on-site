"""The new font must retain the actual source lettering and its readable forms."""

import hashlib
import json
from pathlib import Path

from fontTools.pens.boundsPen import BoundsPen
from fontTools.pens.pointInsidePen import PointInsidePen
from fontTools.pens.transformPen import TransformPen
from fontTools.svgLib.path import parse_path
from fontTools.ttLib import TTFont
import pathops
import pytest

ROOT = Path(__file__).resolve().parents[1]


def test_reference_hash_and_origin_record():
    source = ROOT / "sources/yehuda"
    record = json.loads((source / "lettering.json").read_text(encoding="utf-8"))
    assert (
        hashlib.sha256((source / "icon.svg").read_bytes()).hexdigest()
        == record["sourceSha256"]
    )
    assert set(record["glyphs"]) == set("תנךהפרק")


@pytest.mark.parametrize("ch", list("תנךהפרק"))
def test_bold_retains_supplied_svg_outline_after_compilation(ch):
    record = json.loads(
        (ROOT / "sources/yehuda/lettering.json").read_text(encoding="utf-8")
    )
    font = TTFont(ROOT / "dist/ttf/AlHeperek-Bold.ttf")
    glyphs = font.getGlyphSet()
    name = f"uni{ord(ch):04X}.ss03"
    actual = pathops.Path()
    glyphs[name].draw(actual.getPen())
    bounds = BoundsPen(glyphs)
    glyphs[name].draw(bounds)
    reference = pathops.Path()
    scale = 650 / 133.6
    parse_path(
        record["glyphs"][ch]["path"],
        TransformPen(reference.getPen(), (scale, 0, 0, -scale, bounds.bounds[0], 650)),
    )
    delta = pathops.op(actual, reference, pathops.PathOp.XOR)
    assert delta.area / reference.area < 0.006, (ch, delta.area / reference.area)


@pytest.mark.parametrize("style", ["Regular", "SemiBold", "Bold"])
def test_no_study_glyph_is_empty_or_outside_its_advance(style):
    font = TTFont(ROOT / f"dist/ttf/AlHeperek-{style}.ttf")
    gs = font.getGlyphSet()
    for cp in range(0x05D0, 0x05EB):
        glyph = gs[f"uni{cp:04X}.ss03"]
        p = BoundsPen(gs)
        glyph.draw(p)
        assert p.bounds is not None
        assert 0 <= p.bounds[0] < p.bounds[2] < glyph.width


def test_weights_increase_ink_without_closing_mem_or_samekh():
    for ch in "אבגדהוזחטיכלמנסעפצקרשתךםןףץ":
        areas = []
        for style in ("Regular", "SemiBold", "Bold"):
            f = TTFont(ROOT / f"dist/ttf/AlHeperek-{style}.ttf")
            p = pathops.Path()
            f.getGlyphSet()[f"uni{ord(ch):04X}.ss03"].draw(p.getPen())
            areas.append(p.area)
        assert areas[0] < areas[1] < areas[2], (ch, areas)


@pytest.mark.parametrize("style", ["Regular", "SemiBold", "Bold"])
def test_bet_and_final_mem_feet_finish_inside_the_flat_baseline(style):
    font = TTFont(ROOT / f"dist/ttf/AlHeperek-{style}.ttf")
    for letter in "בם":
        glyph = font["glyf"][f"uni{ord(letter):04X}.ss03"]
        glyph.recalcBounds(font["glyf"])
        assert glyph.yMin == 0, (style, letter, glyph.yMin)


@pytest.mark.parametrize("style", ["Regular", "SemiBold", "Bold"])
def test_tet_keeps_air_between_its_two_arms(style):
    font = TTFont(ROOT / f"dist/ttf/AlHeperek-{style}.ttf")
    gs = font.getGlyphSet()
    glyph = gs["uni05D8.ss03"]
    b = BoundsPen(gs)
    glyph.draw(b)
    # This channel was filled by the old left arm and inward hook touching.
    x = b.bounds[0] + 0.46 * (b.bounds[2] - b.bounds[0])
    for y in (370, 390, 410):
        pen = PointInsidePen(gs, (x, y))
        glyph.draw(pen)
        assert not pen.getResult(), (style, y)


def test_left_entrances_follow_the_supplied_tav_corner():
    font = TTFont(ROOT / "dist/ttf/AlHeperek-Bold.ttf")
    gs = font.getGlyphSet()

    def first_ink(letter, y):
        glyph = gs[f"uni{ord(letter):04X}.ss03"]
        bounds = BoundsPen(gs)
        glyph.draw(bounds)
        start = round(bounds.bounds[0])
        for x in range(start, start + 300):
            p = PointInsidePen(gs, (x, y))
            glyph.draw(p)
            if p.getResult():
                return x - start
        raise AssertionError((letter, y, "missing corner"))

    for y in (675, 650, 600, 525, 475):
        reference = first_ink("ת", y)
        for letter in "אטמעצשץ":
            assert abs(first_ink(letter, y) - reference) <= 2, (letter, y)
