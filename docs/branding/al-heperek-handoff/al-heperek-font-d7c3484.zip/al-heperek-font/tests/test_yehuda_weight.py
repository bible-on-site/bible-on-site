"""Measure real compiled ink, including diagonals normal to their movement."""

from pathlib import Path
import math

from fontTools.pens.pointInsidePen import PointInsidePen
from fontTools.ttLib import TTFont
import pytest
import uharfbuzz as hb

ROOT = Path(__file__).resolve().parents[1]


def inside(glyphs, glyph, x, y):
    pen = PointInsidePen(glyphs, (x, y))
    glyph.draw(pen)
    return pen.getResult()


def runs(glyphs, glyph, y):
    result = []
    start = None
    for x in range(round(glyph.width) + 1):
        ink = inside(glyphs, glyph, x, y)
        if ink and start is None:
            start = x
        if not ink and start is not None:
            result.append((start, x))
            start = None
    return result


def normal_width(glyphs, glyph, y, index, normal):
    sections = runs(glyphs, glyph, y)
    assert sections, (glyph.name, y)
    begin, end = sections[index]
    x = (begin + end) / 2
    dx, dy = normal
    length = math.hypot(dx, dy)
    dx, dy = dx / length, dy / length
    distances = []
    for sign in (-1, 1):
        for distance in range(1, 400):
            if not inside(
                glyphs, glyph, x + sign * distance * dx, y + sign * distance * dy
            ):
                distances.append(distance)
                break
        else:
            raise AssertionError(
                (glyph.name, "stroke joins another region at this probe")
            )
    return sum(distances)


PROBES = [
    ("alef left", "א", 125, 0, (1, 0)),
    ("alef diagonal", "א", 100, -1, (0.65, 0.76)),
    ("alef right", "א", 400, -1, (1, -0.4)),
    ("tsadi diagonal", "צ", 400, 0, (1, 0.65)),
    ("tsadi right", "צ", 400, -1, (1, -0.4)),
    ("final tsadi diagonal", "ץ", 400, 0, (1, 0.4)),
    ("final tsadi right", "ץ", 400, -1, (1, -0.4)),
    ("gimel middle", "ג", 400, 0, (1, 0)),
    ("gimel left foot", "ג", 100, 0, (0.56, -0.83)),
    ("gimel right foot", "ג", 100, -1, (0.7, 0.7)),
    ("ayin right", "ע", 325, -1, (1, -0.35)),
    ("shin middle", "ש", 400, 1, (1, -0.05)),
]


@pytest.fixture(params=["Regular", "SemiBold", "Bold"])
def font(request):
    with TTFont(ROOT / f"dist/ttf/AlHeperek-{request.param}.ttf") as value:
        yield value


@pytest.mark.parametrize(
    "label,letter,y,index,normal", PROBES, ids=[p[0] for p in PROBES]
)
def test_constructed_strokes_keep_the_reference_pen_weight(
    font, label, letter, y, index, normal
):
    glyphs = font.getGlyphSet()
    reference = normal_width(glyphs, glyphs["uni05E8.ss03"], 325, 0, (1, 0))
    width = normal_width(glyphs, glyphs[f"uni{ord(letter):04X}.ss03"], y, index, normal)
    assert 0.90 * reference <= width <= 1.30 * reference, (label, width, reference)


@pytest.mark.parametrize("letter", list("אגעצץש"))
def test_heads_and_branches_remain_one_connected_contour_in_every_weight(font, letter):
    # Narrow overlaps in separately drawn parts previously broke apart when
    # the Regular master was inset. These six letters have no enclosed holes.
    assert font["glyf"][f"uni{ord(letter):04X}.ss03"].numberOfContours == 1


@pytest.mark.parametrize(
    "digit,y,normal",
    [
        ("0", 325, (1, 0)),
        ("1", 325, (1, 0)),
        ("4", 100, (1, 0)),
        ("7", 325, (0.89, -0.456)),
    ],
)
def test_figures_use_the_corresponding_hebrew_stem_weight(font, digit, y, normal):
    glyphs = font.getGlyphSet()
    reference = normal_width(glyphs, glyphs["uni05E8.ss03"], 325, 0, (1, 0))
    width = normal_width(glyphs, glyphs[f"uni{ord(digit):04X}.ss03"], y, 0, normal)
    assert 0.90 * reference <= width <= 1.15 * reference, (digit, width, reference)


@pytest.mark.parametrize("script", ["Hebr", "Latn", "Zyyy"])
def test_digit_feature_and_installable_export_agree_in_each_script(font, script):
    style = font["name"].getDebugName(17) or font["name"].getDebugName(2)
    source = ROOT / f"dist/ttf/AlHeperek-{style}.ttf"
    exported = ROOT / f"dist/yehuda/ttf/AlHeperekYehuda-{style}.ttf"

    def shape(path, features):
        shaper = hb.Font(hb.Face(path.read_bytes()))
        b = hb.Buffer()
        b.add_str("0123456789 2026")
        b.direction = "ltr"
        b.script = script
        hb.shape(shaper, b, features)
        return [
            (i.codepoint, p.x_advance) for i, p in zip(b.glyph_infos, b.glyph_positions)
        ]

    assert shape(source, {"ss03": True}) == shape(exported, {})
    exported_font = TTFont(exported)
    assert all(
        exported_font.getBestCmap()[cp].endswith(".ss03") for cp in range(0x30, 0x3A)
    )


def test_figures_are_tabular_and_keep_their_counters(font):
    widths = {font["hmtx"][f"uni{cp:04X}.ss03"][0] for cp in range(0x30, 0x3A)}
    assert widths == {640}
    for digit, counters in [("0", 1), ("4", 1), ("6", 1), ("8", 2), ("9", 1)]:
        assert (
            font["glyf"][f"uni{ord(digit):04X}.ss03"].numberOfContours == counters + 1
        ), digit
