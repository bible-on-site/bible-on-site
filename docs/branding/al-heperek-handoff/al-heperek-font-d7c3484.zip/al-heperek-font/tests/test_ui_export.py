"""The cross-platform export must shape exactly like the approved preview."""

from pathlib import Path

from fontTools.ttLib import TTFont
import pytest
import uharfbuzz as hb

ROOT = Path(__file__).resolve().parents[1]


def shape(path, text, features):
    font = hb.Font(hb.Face(path.read_bytes()))
    buffer = hb.Buffer()
    buffer.add_str(text)
    buffer.guess_segment_properties()
    hb.shape(font, buffer, features)
    return [
        (g.codepoint, p.x_advance, p.x_offset, p.y_offset)
        for g, p in zip(buffer.glyph_infos, buffer.glyph_positions)
    ]


@pytest.mark.parametrize("style", ["Regular", "SemiBold", "Bold"])
@pytest.mark.parametrize(
    "directory,stem,cut,family",
    [
        ("ui", "AlHeperekUI", "ss02", "Al Heperek Font UI"),
        ("yehuda", "AlHeperekYehuda", "ss03", "Al Heperek Yehuda Study"),
        ("yehuda-ui", "AlHeperekUI", "ss03", "Al Heperek Font UI"),
    ],
)
def test_ui_export_matches_preview_glyphs_and_positioning(
    style, directory, stem, cut, family
):
    source = ROOT / "dist" / "ttf" / f"AlHeperek-{style}.ttf"
    exported = ROOT / "dist" / directory / "ttf" / f"{stem}-{style}.ttf"
    for text in [
        "על הפרק",
        "אצלנו בארץ",
        "בְּרֵאשִׁית",
        "אבגדהוזחטיכךלמםנןסעפףצץקרשת",
        "Al Heperek 2026",
    ]:
        assert shape(source, text, {cut: True}) == shape(exported, text, {})
    font = TTFont(exported)
    assert (font["name"].getDebugName(16) or font["name"].getDebugName(1)) == family
    cmap = font.getBestCmap()
    assert not set(range(0x0591, 0x05B0)).intersection(cmap)
    assert all(cmap[c].endswith("." + cut) for c in range(0x05D0, 0x05EB))
