"""Extend the lettering in Yehuda's user-supplied SVG into a Hebrew alphabet.

Authoring coordinates retain the source's 133.6-unit body. Seven glyphs are
the supplied outlines; the remaining twenty use their shoulders, entrances,
flat returns, cut feet and diagonal heads. No third-party font is an input.
"""

import json
from pathlib import Path

import pathops
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.svgLib.path import parse_path

SOURCE = Path(__file__).resolve().parents[2] / "sources/yehuda/lettering.json"
BODY = 133.6
PEN_WIDTH = 32.4


def pen_outline(path, width=PEN_WIDTH):
    """Draw a companion figure's curved stroke at the source resh's weight."""
    drawing = pathops.Path()
    parse_path(path, drawing.getPen())
    drawing.stroke(width, pathops.LineCap.BUTT_CAP, pathops.LineJoin.ROUND_JOIN, 4)
    drawing.convertConicsToQuads(0.02)
    pen = SVGPathPen(None)
    drawing.draw(pen)
    return pen.getCommands()


def translated(outline, dx=0, dy=0):
    pen = SVGPathPen(None)
    parse_path(outline, TransformPen(pen, (1, 0, 0, 1, dx, dy)))
    return pen.getCommands()


def shoulder(width=101.4, bottom=136.5, narrow=False):
    """Resh's entrance, upper-right turn and tapered stem, at optical widths."""
    a = 0.55 if narrow else 1
    return (
        f"M {23 * a} -8.7 L {27.4 * a} -3.9 "
        f"C {28.8 * a} -2.1 {30.1 * a} -1 {31.4 * a} -.6 "
        f"C {32.6 * a} -.2 {34.8 * a} 0 {38 * a} 0 "
        f"L {width - 42.6} 0 C {width - 31.4} 0 {width - 22.9} 1.5 {width - 16.8} 4.5 "
        f"C {width - 10.8} 7.5 {width - 6.5} 12.6 {width - 4} 19.9 "
        f"C {width - 1.5} 27.1 {width - 0.1} 37.4 {width} 50.8 "
        f"C {width} {bottom * 0.53} {width - 1.4} {bottom * 0.8} {width - 3.4} {bottom - 4.8} "
        f"L {width - 22} {bottom} {width - 32.4} {bottom} "
        f"C {width - 32.4} {bottom * 0.7} {width - 32.7} 79 {width - 33.4} 60.8 "
        f"C {width - 33.5} 52.9 {width - 34.8} 47.5 {width - 37.3} 44.7 "
        f"C {width - 39.7} 41.8 {width - 43.9} 40.4 {width - 50.1} 40.4 "
        f"L {17.2 * a} 40.4 C {14.6 * a} 40.4 {8.9 * a} 39.1 0 36.3 "
        f"C 1.1 21.5 {3.3 * a} 7.4 {6.6 * a} -5.8 Z"
    )


def upright(x, top=62.7, bottom=136.5):
    """The detached he leg; its rising head and sloping foot are shared."""
    return (
        f"M {x + 35.8} {top} L {x + 35.6} {bottom - 4.8} "
        f"L {x + 10.2} {bottom} {x} {bottom} "
        f"L {x + 1.2} {top + 4.8} {x + 25.9} {top + 0.2} Z"
    )


def floor(left, right, top=94.4, bottom=133.6):
    return (
        f"M {left + 1.9} {top} L {right} {top} {right - 1.9} {bottom} {left} {bottom} Z"
    )


def diagonal_entry(x, y=0):
    # A cut, sloping entry taken from the nun's broad, forward-facing head.
    return (
        f"M {x + 13} {y - 6.8} C {x + 25.1} {y - 1.6} {x + 33.8} {y + 2.6} {x + 39.1} {y + 5.8} "
        f"C {x + 44.1} {y + 8.7} {x + 47.8} {y + 11.6} {x + 50.3} {y + 14.5} "
    )


def left_entry():
    """Tav's lifted left entrance, turning forward into its left leg.

    The upper-right face continues to the right as it descends. Nun's head
    returns in the opposite direction and belongs on the right-hand arms.
    """
    return (
        "M 23 -8.7 L 27.4 -3.9 C 28.8 -2.1 30.1 -1 31.4 -.6 "
        "C 32.6 -.2 34.8 0 38 0 L 47 0 "
        "C 49 10 50 23 50.8 40.4 "
    )


def left_return():
    """Close against the same left entrance as the supplied tav and resh."""
    return "L 14.3 40.2 C 12.8 39.9 8 38.6 0 36.3 C 1.1 21.5 3.3 7.4 6.6 -5.8 Z"


def fork(x=77, joint_x=77, joint_y=95):
    """Identical upper-right arm on alef, tsadi and final tsadi."""
    return (
        diagonal_entry(x) + f"C {x + 52.7} 17.4 {x + 54} 22 {x + 53} 29 "
        f"C {x + 51} 52 {joint_x + 36} {joint_y - 8} {joint_x + 14} {joint_y + 9} "
        f"L {joint_x - 10} {joint_y - 13} "
        f"C {joint_x + 8} {joint_y - 27} {x + 18} 46 {x + 20} 32 "
        f"Q {x + 20} 26 {x + 12} 22 L {x - 6.8} 12.2 "
        f"C {x - 4.7} 4.8 {x - 0.2} -7.4 {x + 6.7} -5.5 Z"
    )


def native_letters():
    supplied = json.loads(SOURCE.read_text(encoding="utf-8"))["glyphs"]
    letters = {ch: [drawing["path"]] for ch, drawing in supplied.items()}

    def put(ch, *contours):
        letters[ch] = list(contours)

    put("ו", shoulder(62, narrow=True))
    put("ן", shoulder(62, bottom=173.2, narrow=True))
    put("ח", shoulder(124.7), upright(3.9, 36))
    put("ב", shoulder(111.4, bottom=133.6), floor(0, 124.5))
    put("ד", shoulder(109.4), "M 62 0 L 120 0 116.5 40.4 86 40.4 Q 72 40.4 62 33 Z")
    put("ז", shoulder(69, narrow=True), "M 37 0 L 82 0 78.5 40.4 49 40.4 Z")
    put("י", shoulder(63, bottom=69, narrow=True))

    # The lower return repeats pe's level, slightly tapered bottom stroke.
    put(
        "כ",
        "M 23 -8.7 L 27.4 -3.9 C 30 -.6 32 0 38 0 L 68 0 "
        "C 99 0 113 15 113 47 L 112 92 C 111 121 99 133.6 73 133.6 "
        "L 0 133.6 1.9 94.4 71 94.4 Q 81 94.4 81 79 L 81 62 "
        "Q 81 40.4 62 40.4 L 17.2 40.4 C 14.6 40.4 8.9 39.1 0 36.3 "
        "C 1.1 21.5 3.3 7.4 6.6 -5.8 Z",
    )
    # Final pe keeps the exact mouth and shoulder; its floor becomes a stem.
    # Explicit return follows the supplied pe rather than a distorted copy.
    put(
        "ף",
        "M 23 -6.8 C 42.7 -5 60.4 -2.8 76.2 -.2 "
        "C 86.4 1.5 93.9 4.3 98.8 8.1 C 103.8 11.9 107.2 17.7 109.1 25.5 "
        "C 111.1 33.4 112 44.9 112 60 "
        "C 112 97 111 137 109.3 168.4 L 90.4 173.2 80.3 173.2 "
        "C 80.3 137 80 91 80.8 56.9 "
        "C 80.5 52 79.9 48.5 79.1 46.1 C 78.3 43.8 76.9 42 75 40.9 "
        "C 73.1 39.8 69.9 38.8 65.6 38 C 53 35.9 43 34.5 35.6 33.7 "
        "L 35.8 38.5 C 36 42.5 36.4 45.1 37 46.2 "
        "C 37.7 47.4 39.2 48.5 41.6 49.6 L 51.5 53.7 "
        "C 50.9 58.3 49.9 63.6 48.5 69.7 C 47.1 75.8 45.6 81.4 44 86.4 "
        "C 33.1 83.3 25 80.6 19.8 78.3 C 14.7 76 11 73.3 8.9 70.2 "
        "C 6.8 67.1 5.6 62.8 5.1 57.1 C 4.7 52.6 5.1 45.4 6.3 35.6 "
        "C 7.4 25.7 9.2 12.6 11.6 -3.9 Z",
    )

    put("ם", shoulder(125, bottom=133.6), upright(4, 36.3, 133.6), floor(4, 121.6))
    put(
        "ס",
        "M 23 -6.8 C 42.7 -5 66 -2.8 82 -.2 C 112 3 126 23 126 61 "
        "L 125 89 C 124 120 107 136.5 67 136.5 C 27 136.5 8 120 7 89 "
        "L 6 56 C 5.6 42 7.4 25.7 11.6 -3.9 Z",
        "M 39 37 C 36 52 36 66 37 79 Q 38 98 67 98 "
        "Q 94 98 94 79 L 94 61 Q 94 41 76 40 Z",
    )
    put(
        "ט",
        left_entry() + "C 56.8 71.4 59.7 82 59.7 88 Q 59.7 99 75 99 Q 95 99 96 75 "
        "L 97 60 Q 97 39 84 39 Q 77 39 76 57 L 64 61 "
        "C 61 23 70 -3 92 -3 C 115 -3 129 16 129 54 L 128 87 "
        "C 126 120 107 136.5 66 136.5 C 34 136.5 20 121 25 91 "
        "C 26 78 21 58 14.3 40.2 " + left_return(),
    )

    put(
        "ג",
        diagonal_entry(19)
        + "C 73 21 74 32 73 47 L 70 78 C 72 94 86 106 105 113 "
        "L 100 131.7 72 136.5 C 60 125 50 112 46 101 "
        "Q 33 125 0 136.5 L 2 93 Q 23 90 30 73 "
        "L 35 53 Q 36 43 27 38 L 12.2 28.2 Q 15 17 25.7 .9 Z",
    )
    put(
        "מ",
        left_entry() + "C 65 8 84 0 102 0 C 130 0 143 16 143 48 "
        "L 141 133.6 75 133.6 77 94.4 111 94.4 112 60 Q 112 40.4 97 40.4 "
        "Q 77 40.4 64 64 L 35 131.7 11 136.5 1 136.5 "
        "C 6 117 20 91 23 78 C 25 65 21 53 14.3 40.2 " + left_return(),
    )

    # Qof's descending right turn is retained on lamed, with a new ascender.
    put(
        "ל",
        "M 0 -50 L 25.4 -54.8 35.6 -54.8 34.4 -8 Q 34.4 0 45 0 "
        "L 91.3 .3 C 100.6 .3 107.9 3.1 113 8.7 C 118.2 14.4 120.8 22.3 120.8 32.4 "
        "C 120.8 48.1 116.5 64.2 107.8 80.8 C 99.2 97.5 85.9 115.2 67.8 134.1 "
        "L 57.4 134.1 C 56.7 124.9 56.4 114.2 56.4 101.9 L 56.4 91.7 "
        "C 68.5 79.3 76.8 70.6 81.3 65.5 C 85.9 60.4 88.8 56.3 90.3 53.3 "
        "C 90.5 47.9 90 44.5 88.8 42.9 C 87.7 41.2 85.3 40.4 81.6 40.4 "
        "L 17.2 40.4 Q 0 40.4 0 24 Z",
    )
    put(
        "ע",
        left_entry() + "L 70 89 C 94 78 104 62 104 40 "
        "L 104 4.8 129.4 0 139.6 0 L 139.6 40 "
        "C 139.6 98 107 133.6 54 133.6 L 0 133.6 1.9 94.4 31 94.4 "
        "C 26 76 20 57 14.3 40.2 " + left_return(),
    )

    put(
        "א",
        left_entry()
        + "C 57 64 101 85 131 112 Q 135 119 130 128 "
        "L 104 136.5 95 136.5 C 76 108 57 82 34 60 " + left_return(),
        "M 30 31 L 48 50 C 32 60 29 77 34 104 L 34 129 "
        "L 10 136.5 0 136.5 C 0 107 0 77 12 55 Q 17 41 30 31 Z",
        fork(),
    )
    put(
        "צ",
        left_entry() + "C 57 64 103 75 125 106 Q 130 117 125 133.6 "
        "L 0 133.6 1.9 94.4 68 94.4 C 43 88 20 65 14.3 40.2 " + left_return(),
        fork(),
    )
    put(
        "ץ",
        left_entry() + "C 56.8 71.4 83 73 94 96 C 98 113 97 141 96 168.4 "
        "L 70.6 173.2 60.4 173.2 C 61 139 61 118 55 105 "
        "C 43 94 19 66 14.3 40.2 " + left_return(),
        fork(),
    )
    put(
        "ש",
        left_entry() + "C 56.8 71.4 59.7 83 64 91 Q 68 98 77 98 "
        "L 78 74 C 80 56 79 27 78 4.8 L 103.4 0 113.6 0 "
        "C 116 43 112 70 102 96 Q 130 96 131 74 "
        "L 131 4.8 156.4 0 166.6 0 L 165 74 "
        "C 164 115 141 136.5 87 136.5 C 41 136.5 18 119 20 90 "
        "C 21 75 18 57 14.3 40.2 " + left_return(),
    )
    assert set(letters) == set(map(chr, range(0x05D0, 0x05EB)))
    return letters


def compile_outline(contours, weight):
    """Apply the same weight model to a Hebrew letter or a companion figure."""
    inset = {400: 6.5, 600: 2.8, 700: 0}[weight]
    scale = 650 / (BODY - 2 * inset)
    drawing = pathops.Path()
    for contour in contours:
        p = pathops.Path()
        parse_path(contour, p.getPen())
        drawing.addPath(p)
    drawing = pathops.simplify(drawing, clockwise=False)
    if inset:
        boundary = pathops.Path(drawing)
        boundary.stroke(
            2 * inset, pathops.LineCap.ROUND_CAP, pathops.LineJoin.ROUND_JOIN, 4
        )
        boundary.convertConicsToQuads(0.02)
        drawing = pathops.op(drawing, boundary, pathops.PathOp.DIFFERENCE)
    drawing.convertConicsToQuads(0.02)
    pen = SVGPathPen(None)
    drawing.draw(TransformPen(pen, (scale, 0, 0, -scale, 0, (BODY - inset) * scale)))
    return pen.getCommands()


def outlines(weight):
    """Three weights; the bold source letters keep their supplied outlines."""
    return {
        ch: compile_outline(contours, weight)
        for ch, contours in native_letters().items()
    }
