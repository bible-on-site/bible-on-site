"""Optical fitting for the Hebrew reading and headline cuts, in 1000 UPM."""

# Physical left and right bearings in upright font coordinates. The open
# sides of lamed, resh and kaf can share more space with a neighbour than
# a wall such as the right of final pe or the left of heth.
READING_BEARINGS = {
    'א': (40, 43), 'ב': (39, 45), 'ג': (30, 30), 'ד': (30, 31),
    'ה': (40, 43), 'ו': (30, 43), 'ז': (32, 30), 'ח': (50, 52),
    'ט': (37, 39), 'י': (34, 34), 'ך': (30, 42), 'כ': (31, 38),
    'ל': (25, 28), 'ם': (48, 51), 'מ': (40, 48), 'ן': (32, 44),
    'נ': (30, 36), 'ס': (36, 37), 'ע': (33, 36), 'ף': (44, 45),
    'פ': (34, 40), 'ץ': (29, 32), 'צ': (32, 36), 'ק': (37, 34),
    'ר': (29, 40), 'ש': (36, 43), 'ת': (35, 46),
}

# Logical Hebrew reading order (right-hand letter first). Read and display
# pairs have separate values because their roofs and internal whites differ.
PAIRS = {
    'על': (-12, -16), 'לע': (-19, -23), 'אל': (-10, -14),
    'לו': (-13, -16), 'ול': (-8, -10), 'יל': (-8, -10),
    'לי': (-12, -16), 'לם': (-12, -16), 'לת': (-12, -15),
    'יו': (-8, -9), 'פר': (-8, -11), 'רק': (-17, -21),
    'קו': (-7, -9), 'אר': (-8, -12), 'רא': (-10, -13),
}


def fit_hebrew(font, weight):
    """Fit completed outlines and their anchors, then set Hebrew pair kerning."""
    # The inscription has a little more air beside the flared foot.
    optical_insets = {'': 0, '.ss01': -8, '.ss02': -3}
    for suffix, optical_inset in optical_insets.items():
        # Bold needs a little more white at body sizes. At display sizes the
        # larger counters and clean rendering allow closer flank-to-flank fit.
        inset = {400: 0, 600: 2, 700: 4}[weight] + optical_inset
        for letter, (left, right) in READING_BEARINGS.items():
            glyph = font[f'uni{ord(letter):04X}' + suffix]
            bounds = glyph.getBounds(font)
            dx = left + inset - round(bounds.xMin)
            glyph.move((dx, 0))
            glyph.width = round(bounds.xMax) + dx + right + inset
        for pair, (reading_value, display_value) in PAIRS.items():
            glyph_pair = tuple(f'uni{ord(letter):04X}' + suffix for letter in pair)
            font.kerning[glyph_pair] = display_value if suffix else reading_value

    # A neutral space keeps its Latin metrics. Following a word in a Hebrew
    # run it gives back some of the large space reserved by the 300-unit advance.
    group = 'public.kern1.HebrewBeforeSpace'
    font.groups[group] = [f'uni{ord(letter):04X}' + suffix
                          for suffix in optical_insets for letter in READING_BEARINGS]
    for space in ('space', 'uni00A0'):
        font.kerning[group, space] = -42
