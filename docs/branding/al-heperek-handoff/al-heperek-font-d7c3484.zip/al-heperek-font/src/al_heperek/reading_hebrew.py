"""Original Al Heperek Hebrew drawings for the text alphabet.

Dimensions are in upright font coordinates. The three masters reserve ink
independently for the pen face (h) and the thin side of the pen (v).
"""
from .editorial_hebrew import glyph
from .nib_motifs import bowl_turn, diagonal_entry, entry_leg, floor_exit, open_head, returning_arm, roof_entry, shoulder_turn, stem_exit


def reading_letters(nib):
    h, v = nib.broad, nib.thin
    # The diagonal of alef and tsadi carries more ink than a vertical stem.
    d = round(h * .91 + v * .13)
    gain = v - 72
    r = {}

    # A high take-off on the left and a low returning arm keep a long, open
    # interval through the alef. The low foot turns back into its own counter.
    r['א'] = glyph(659,
        f'{diagonal_entry(nib,50-gain*.28)} '
        f'C {212+gain*.47} 546 {302+gain*.53} 420 {380+gain*.50} 332 '
        f'C {468+gain*.56} 232 {553+gain*.50} 155 {592+gain*.28} 76 '
        f'Q {600+gain*.28} 61 {593+gain*.25} 49 L {562-gain*.25} 0 '
        f'Q {557-gain*.25} -8 {550-gain*.25} 1 '
        f'C {502-gain*.32} 75 {431-gain*.46} 141 {347-gain*.49} 237 '
        f'C {256-gain*.46} 342 {159-gain*.36} 488 {50-gain*.28} 616 Z',
        returning_arm(nib, 384, 256, run=183),
        f'M 247 488 L {280+gain*.14} 443 C 212 403 {168+gain*.32} 350 {155+gain*.50} 286 '
        f'C {144+gain*.50} 231 {131+gain*.51} 186 {138+gain*.47} {h+38} '
        f'Q {142+gain*.47} {h+17} {164+gain*.45} {h+7} '
        f'Q {179+gain*.44} {h+1} {175+gain*.43} {h-12} '
        f'L {157+gain*.42} 22 Q {151+gain*.42} 5 {137+gain*.40} 4 '
        f'Q 95 -1 {44-gain*.28} -1 Q {35-gain*.28} -1 {39-gain*.28} 9 '
        f'C {56-gain*.21} 45 {64-gain*.26} 87 {64-gain*.30} 131 '
        f'C {65-gain*.30} 241 {73-gain*.26} 326 {129-gain*.12} 396 Q 169 447 247 488 Z')
    # Bet. An advancing toe marks the writing direction at the baseline.
    shoulder = shoulder_turn(nib, 537, run=202, drop=175)
    r['ב'] = glyph(619,
        f'{roof_entry(nib,51)} L {shoulder.outer_start} '
        f'{shoulder.outer} Q 536 337 522 {h+17} '
        f'Q 542 {h+15} 573 {h+24} Q 581 {h+25} 580 {h+14} '
        f'L 572 17 Q 571 8 562 7 Q 401 0 231 0 {floor_exit(nib,48)} '
        f'Q 234 {h-6} {522-v} {h+5} '
        f'L {shoulder.inner_start} {shoulder.inner} '
        f'L 54 {650-h} Z')
    # Gimel. Open stride and separate heel: the diagonal is visible in text.
    r['ג'] = glyph(479,
        f'{roof_entry(nib,142)} L 251 650 C 322 650 354 622 353 549 '
        f'C 352 457 335 347 349 271 C 363 182 399 96 439 38 '
        f'Q 446 28 436 22 L {410-v*.43:.1f} -3 Q {403-v*.43:.1f} -6 {397-v*.43:.1f} 2 '
        f'C {354-gain*.33:.1f} 48 {325-gain*.35:.1f} 111 303 181 '
        f'C 256 117 175 39 103 3 Q 78 -8 46 1 Q 41 3 42 12 '
        f'L 49 {h-1} Q 50 {h+8} 60 {h+11} Q 197 {h+55} 273 224 '
        f'Q 302 251 {340-v} 320 L {351-v} 477 '
        f'Q {354-v} {650-h} {292-v} {650-h} L 145 {650-h} Z')
    # Dalet's lintel projects distinctly beyond its upright even at 16 px.
    r['ד'] = glyph(605,
        f'{roof_entry(nib,48)} Q 364 652 552 653 Q 563 653 562 642 '
        f'L 558 {652-h} Q 557 {646-h} 548 {646-h} L 498 {648-h} '
        f'C 495 410 480 192 477 44 {stem_exit(nib,477,-3)} '
        f'C {479-v} 179 {493-v} 409 {497-v} {649-h} L 51 {650-h} Z')
    # Narrow letters have their own silhouettes. Yod curls in on release.
    shoulder = shoulder_turn(nib, 232, run=119, drop=135)
    r['ו'] = glyph(267,
        f'{roof_entry(nib,31,reach=66)} L {shoulder.outer_start} {shoulder.outer} '
        f'Q 231 373 215 51 {stem_exit(nib,214,-4)} '
        f'Q {218-v} 222 {shoulder.inner_start} {shoulder.inner} L 34 {650-h} Z')
    r['ז'] = glyph(337,
        f'{roof_entry(nib,42,644)} Q 181 643 283 658 Q 301 661 301 649 '
        f'L 294 {653-h} Q 293 {643-h} 284 {642-h} Q 248 {638-h} 210 {640-h} '
        f'Q 194 353 193 220 Q 193 105 211 27 Q 214 14 203 11 '
        f'L {210-v} -4 Q {203-v} -5 {200-v} 5 '
        f'C {177-v} 107 {180-v} 259 {208-v} {639-h} Q 110 {640-h} 45 {644-h} Z')
    # Heth has a quieter, longer top than bet and two different lower exits.
    shoulder = shoulder_turn(nib, 568, run=206, drop=165)
    r['ח'] = glyph(635,
        f'{roof_entry(nib,45)} L {shoulder.outer_start} {shoulder.outer} '
        f'Q 568 379 558 58 {stem_exit(nib,557,-3)} '
        f'Q {561-v} 275 {shoulder.inner_start} {shoulder.inner} L {99+v} {650-h} '
        f'Q {111+v} 405 {97+v} 212 {stem_exit(nib,84+v,-3)} '
        f'Q 88 171 97 314 Q 108 439 94 {650-h} L 48 {650-h} Z')
    # Tet: the bent inward tip springs from the right-hand return. The join
    # is an open notch, so its silhouette can survive small-screen rasterizing.
    left = entry_leg(nib, 47)
    bowl = bowl_turn(nib, 583, bottom=-10, run=270, rise=320)
    r['ט'] = glyph(646,
        f'M {left.outer_start} {left.outer} '
        f'C {90+v} 157 230 {h-10} {bowl.inner_start} {bowl.inner} '
        f'L {580-v} 451 C {583-v} {612-h} {558-v} {650-h} 469 {650-h} '
        f'C 405 {650-h} 365 {600-h} 355 445 Q 348 411 350 390 '
        f'Q 350 381 341 375 L {339-v*.53:.1f} 352 Q {330-v*.53:.1f} 347 {328-v*.53:.1f} 359 '
        f'C 270 503 354 659 475 659 C 560 659 597 610 593 505 '
        f'L {bowl.outer_start} {bowl.outer} '
        f'C 150 -10 76 78 {left.inner_start} {left.inner} Z')
    yod_return = 650 - h - 429
    r['י'] = glyph(278,
        f'{roof_entry(nib,47,reach=66)} C 201 650 239 623 234 553 '
        f'C 229 481 200 422 169 396 Q 164 391 156 395 '
        f'L {151-v*.48:.1f} 415 Q {139-v*.48:.1f} 419 {145-v*.48:.1f} 429 '
        f'Q {177-v*.44:.1f} {429+yod_return*.36:.1f} {210-v*.64:.1f} {429+yod_return*.64:.1f} '
        f'C {229-v*.78:.1f} {429+yod_return*.93:.1f} {212-v} {650-h} {187-v} {650-h} '
        f'L 50 {650-h} Z')
    # Kaf's bowl is pulled forward first, then released into the low left exit.
    r['כ'] = glyph(564,
        f'{roof_entry(nib,47)} Q 158 652 218 653 C 427 656 523 563 515 345 '
        f'C 508 129 409 -7 220 -7 Q 166 -7 113 -3 {floor_exit(nib,43,-3)} '
        f'Q 159 {h-8} 217 {h-4} '
        f'C 355 {h-4} {512-v} 189 {514-v} 342 C {516-v} 478 383 {654-h} 252 {654-h} '
        f'Q 134 {654-h} 50 {650-h} Z')
    shoulder = shoulder_turn(nib, 531, run=205, drop=173)
    r['ך'] = glyph(584,
        f'{roof_entry(nib,44)} L {shoulder.outer_start} {shoulder.outer} '
        f'Q 530 315 511 -188 {stem_exit(nib,510,-226)} '
        f'Q {513-v} 149 {shoulder.inner_start} {shoulder.inner} L 47 {650-h} Z')
    # Medial mem uses two gestures; its narrow upper notch and open lower
    # aperture must stay clear even when the flat strokes are darkest.
    r['מ'] = glyph(663,
        f'M 51 614 Q 47 620 56 626 L 113 657 Q 121 662 128 654 '
        f'Q 170 601 184 541 C 237 616 295 658 380 658 C 522 658 595 585 588 433 '
        f'L 575 22 Q 574 10 562 8 Q 458 0 321 0 Q 315 0 316 9 L 324 {h-10} '
        f'Q 325 {h-3} 333 {h-3} Q 439 {h-2} {572-v} {h+5} L {588-v} 402 '
        f'C {593-v} {596-h} 454 {652-h} 368 {652-h} '
        f'C 281 {652-h} 223 483 207 409 Q 190 324 174 219 '
        f'L {85+v} 17 Q {84+v} 10 {76+v} 9 L 57 -3 Q 50 -4 51 5 '
        f'Q 84 216 119 424 Q 138 522 51 614 Z')
    # The outline and counter of final mem have separate, winding directions.
    # Its counter is almost rectangular; samekh below has a tear-shaped eye.
    r['ם'] = glyph(636,
        f'{roof_entry(nib,52)} Q 181 651 281 651 C 477 651 577 619 577 478 '
        f'L 562 21 Q 562 9 549 8 Q 337 -1 78 0 Q 70 0 70 9 L 83 304 '
        f'Q 90 437 86 {650-h} L 55 {650-h} Z',
        f'M {74+v} {h-1} Q 330 {h-7} {562-v} {h+4} '
        f'L {577-v} 422 Q {581-v} {643-h} 412 {648-h} '
        f'Q 333 {652-h} {88+v} {650-h} Q {95+v} 391 {81+v} 244 Z')
    r['נ'] = glyph(438,
        f'{roof_entry(nib,141)} L 240 650 C 340 650 393 614 386 504 L 374 296 '
        f'C 365 138 332 47 249 16 Q 207 -2 130 -2 {floor_exit(nib,50,-2)} '
        f'Q 151 {h-5} 180 {h-2} '
        f'C 269 {h} {369-v} 147 {375-v} 267 L {387-v} 453 '
        f'Q {395-v} {650-h} {294-v} {650-h} L 144 {650-h} Z')
    r['ן'] = glyph(277,
        f'{roof_entry(nib,40,reach=72)} L 132 650 C 201 650 236 620 232 542 '
        f'Q 225 294 205 -178 {stem_exit(nib,203,-226)} '
        f'Q {212-v} 81 {231-v} 476 Q {236-v} {650-h} {178-v} {650-h} '
        f'L 43 {650-h} Z')
    # Samekh: a pitched shoulder, a level of tension at the right wall, and
    # a low point to the left of its inner counter's center.
    bowl = bowl_turn(nib, 575, bottom=-10, run=266, rise=340)
    r['ס'] = glyph(622,
        f'{roof_entry(nib,48)} Q 182 650 259 651 C 450 657 575 579 {bowl.outer_start} '
        f'{bowl.outer} C 148 -10 66 89 67 263 Q 67 414 103 {650-h} L 51 {650-h} Z',
        f'M {95+v} {650-h} C {80+v} 488 {60+v} 350 {76+v} 250 '
        f'C {94+v} 133 220 {h-10} {bowl.inner_start} {bowl.inner} '
        f'C {575-v} {584-h} 432 {650-h} 330 {650-h} Z')
    # The same diagonal entry and returning head sit over two different bases.
    # Medial tsadi settles onto a long foot; final tsadi stands under the fork.
    r['צ'] = glyph(596,
        f'{diagonal_entry(nib,46-gain*.28)} '
        f'C {181+gain*.31} 565 {229+gain*.44} 476 {312+gain*.38} 388 '
        f'C {399+gain*.36} 293 470 212 521 {h+24} '
        f'Q 530 {h+9} 526 {h-6} L 512 19 Q 509 5 494 5 '
        f'C 337 1 183 -3 46 0 Q 38 0 40 10 L 53 {h-8} Q 55 {h+3} 67 {h+3} '
        f'Q 243 {h-3} {485-d} {h+2} '
        f'C {328-gain*.42} 218 {240-gain*.50} 306 {144-gain*.31} 462 '
        f'Q 85 560 {46-gain*.28} 616 Z',
        returning_arm(nib, 287, 367, run=250))
    r['ץ'] = glyph(556,
        f'{diagonal_entry(nib,53-gain*.28)} '
        f'C {168+gain*.37} 552 {225+gain*.40} 448 {279+gain*.22} 370 '
        f'C {315+gain*.21} 318 {335+gain*.25} 280 {339+gain*.34} 225 '
        f'C {345+gain*.34} 128 {321+gain*.33} -79 {320+gain*.32} -187 '
        f'{stem_exit(nib,319+gain*.32,-227)} '
        f'C {319+gain*.32-v} -103 {337+gain*.35-v} 118 {329+gain*.32-v} 195 '
        f'C {251-gain*.45} 278 {206-gain*.43} 345 {158-gain*.35} 432 '
        f'Q 96 551 {53-gain*.28} 616 Z',
        returning_arm(nib, 251, 341, run=260))
    # The three shin arms share an inlet, but bend into two different joins.
    left = entry_leg(nib, 47)
    middle = 276
    right = 652-v
    r['ש'] = glyph(747,
        f'M {left.outer_start} {left.outer} Q {95+v} 191 218 155 '
        f'C 271 186 296 251 304 322 Q 313 421 302 534 '
        f'Q 301 588 {middle+5} 617 {open_head(nib,middle,653)} '
        f'Q {middle+v+29} 369 {middle+v+2} 277 C {middle+v-18} 198 301 143 250 {h+12} '
        f'Q 290 {h-8} 360 {h-8} C 505 {h-8} {659-v} 211 {660-v} 378 '
        f'L {661-v} 487 Q {664-v} 582 {right+5} 630 {open_head(nib,right,666)} '
        f'C 690 331 659 186 582 97 C 522 27 440 -10 340 -9 '
        f'C 170 -7 78 96 {left.inner_start} {left.inner} Z')
    shoulder = shoulder_turn(nib, 623, run=215, drop=170)
    r['ת'] = glyph(685,
        f'{roof_entry(nib,48)} L {shoulder.outer_start} '
        f'{shoulder.outer} L 607 55 {stem_exit(nib,606,-4)} '
        f'Q {612-v} 204 {shoulder.inner_start} {shoulder.inner} L {180+v} {650-h} '
        f'C {192+v} 446 {183+v} 319 {177+v} 224 '
        f'C {167+v} 72 168 -2 92 -2 {floor_exit(nib,38,-2)} '
        f'C 140 {h-7} 156 {h+30} 165 190 '
        f'Q 190 427 165 {650-h} L 51 {650-h} Z')
    return r
