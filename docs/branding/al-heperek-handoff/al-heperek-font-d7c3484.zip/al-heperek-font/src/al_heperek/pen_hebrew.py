"""Original Hebrew brand letters. Upright coordinates, on a 650-unit body."""
from .editorial_hebrew import glyph
from .nib_motifs import bowl_turn, floor_exit, roof_entry, shoulder_turn, stem_exit


def descending_turn(nib, right, tail_x, tail_y):
    """Roll off the roof into a diagonal, then release at the foot of ל or ק."""
    broad, thin = nib.broad, nib.thin
    knee = tail_y + (650 - tail_y) * .51
    heel = broad * .98
    wall_bottom = min(knee + 76, 654 - broad - 56)
    foot_x, foot_y = tail_x + thin*.45, tail_y + heel*.84
    elbow_x, elbow_y = right - 65, knee - 51
    return (
        f'C {right-38} 654 {right} 623 {right} 531 L {right} {wall_bottom} '
        f'C {right} {knee+15} {right-24} {knee-10} {elbow_x} {elbow_y} '
        f'C {elbow_x-60} {elbow_y-60} {foot_x-7} {foot_y+47} {foot_x} {foot_y} '
        f'C {foot_x+3} {tail_y+heel*.56} {foot_x+thin*.32} {tail_y+heel*.38} {foot_x+thin*.29} {tail_y+heel*.25} '
        f'Q {foot_x+thin*.22} {tail_y+heel*.09} {tail_x+thin*.19} {tail_y+2} '
        f'Q {tail_x-thin*.07} {tail_y-3} {tail_x-thin*.31} {tail_y+heel*.13} '
        f'C {tail_x-thin*.65} {tail_y+heel*.36} {foot_x-thin*1.02} {tail_y+heel*.61} {foot_x-thin*.95} {foot_y} '
        f'C {foot_x-thin*.95+11} {foot_y+64} {elbow_x-thin*.73-55} {elbow_y-55} {elbow_x-thin*.73} {elbow_y} '
        f'C {right-24-thin*.86} {knee-10} {right-thin} {knee+15} {right-thin} {wall_bottom} '
        f'L {right-thin} {654-broad-40} Q {right-thin} {654-broad} {right-162} {654-broad} ')


def detached_stem(nib, left, top, bottom):
    """The detached left stems of he and qof share an inlet and slight lean."""
    thin = nib.thin
    return (
        f'M {left+17} {top-31} Q {left+17} {top-22} {left+29} {top-18} '
        f'L {left+thin+10} {top-2} Q {left+thin+19} {top} {left+thin+18} {top-13} '
        f'C {left+thin+16} {top-103} {left+thin} {bottom+112} {left+thin} {bottom+40} '
        f'{stem_exit(nib, left+thin, bottom)}'
        f'C {left-1} {bottom+125} {left+13} {top-122} {left+17} {top-31} Z')


def downstroke(nib, turn, right, foot):
    """The right stem of resh and he settles on a lightly angled terminal."""
    thin = nib.thin
    return (
        f'C {right} 352 {foot-5} 133 {foot} 28 '
        f'{stem_exit(nib, foot)}'
        f'C {foot-thin-8} 122 {right-thin} 365 {turn.inner_start} {turn.inner} ')


def brand_letters(nib):
    broad, thin = nib.broad, nib.thin

    r = shoulder_turn(nib, 523, run=227, drop=185)
    resh = glyph(567,
        roof_entry(nib, 39) +
        f'C 156 648 217 650 {r.outer_start} {r.outer} ' +
        downstroke(nib, r, 523, 511) +
        f'C 218 {650-broad} 112 {650-broad+2} 42 {650-broad} Z')

    h = shoulder_turn(nib, 576, run=211, drop=179)
    he = glyph(622,
        roof_entry(nib, 44) +
        f'C 159 649 284 650 {h.outer_start} {h.outer} ' +
        downstroke(nib, h, 576, 565) +
        f'C 290 {650-broad} 117 {650-broad+1} 47 {650-broad} Z',
        detached_stem(nib, 71, 355, 0))

    # The entry rolls into one straight, lightly leaning left stroke. The
    # bowl, rather than a change of direction in that stroke, makes the turn.
    ayin = glyph(608,
        f'M 49 620 Q 47 630 60 635 Q 82 642 {79+thin*.22} 657 '
        f'Q {83+thin*.22} 662 {92+thin*.22} 656 '
        f'C {106+thin*.43} 645 {131+thin*.61} 626 {133+thin*.62} 600 '
        f'Q {134+thin*.63} 581 {122+thin*.68} 568 '
        f'L {219+thin*.71} {96+broad*.58} '
        f'C 391 {144+broad*.43} {556-thin*.88} 281 {547-thin*.86} 442 '
        f'C {544-thin*.88} 521 {525-thin*.96} 545 {502-thin*.98} 561 '
        f'C {483-thin*.98} 575 {472-thin*.95} 592 {476-thin*.90} 611 '
        f'Q {478-thin*.9} 622 {489-thin*.81} 626 Q {513-thin*.64} 637 {516-thin*.49} 654 '
        f'Q {521-thin*.47} 663 {532-thin*.43} 654 '
        f'C 544 622 563 580 560 542 Q 557 506 559 465 '
        f'C 555 279 482 156 337 86 C 258 48 139 9 53 -9 '
        f'Q 43 -11 43 2 Q 46 {broad*.31} 53 {broad-17} '
        f'Q 55 {broad-8} 68 {broad-9} C 127 {broad-13} 180 {broad+4} 215 {broad+23} '
        f'L 108 542 Q 101 565 78 579 C 58 591 48 603 49 620 Z')

    # Preserve the ascender, level roof and baseline return. The softened
    # cap feeds into the upright in a single curve at small and large sizes.
    lamed = glyph(521,
        f'M 38 {862-broad*.05} Q 34 868 45 875 '
        f'Q 63 882 {65+thin*.27} 898 Q {69+thin*.28} 904 {79+thin*.34} 898 '
        f'C {112+thin*.66} 881 {136+thin*.71} 850 {129+thin*.60} 818 '
        f'Q {111+thin*.52} 774 {108+thin*.55} 735 '
        f'L {99+thin*.53} 673 Q {96+thin*.52} 654 {119+thin*.52} 654 '
        f'L 353 654 ' + descending_turn(nib, 478, 202, -7) +
        f'L 110 {654-broad} Q 85 {654-broad} 69 {648-broad} '
        f'Q 60 {645-broad} 62 {659-broad} '
        f'C 70 639 87 747 78 790 C 74 829 42 834 38 {862-broad*.05} Z')

    def pe(final=False):
        shoulder = shoulder_turn(nib, 590, run=220, drop=201)
        bowl = bowl_turn(nib, 590, bottom=-5, run=279, rise=301)
        top = (f'M 62 460 C 59 570 99 641 178 648 '
               f'Q 214 651 254 650 L {shoulder.outer_start} {shoulder.outer} ')
        if final:
            base = (f'C 590 252 577 -76 579 -194 Q 580 -204 568 -208 '
                    f'L {579-thin+8} -225 Q {579-thin-2} -228 {579-thin-2} -212 '
                    f'C {575-thin} -95 {590-thin} 263 {shoulder.inner_start} ')
        else:
            base = (f'L {bowl.outer_start} {bowl.outer} {floor_exit(nib,47,-5)} '
                    f'Q 210 {broad-5} {bowl.inner_start} {bowl.inner} L {shoulder.inner_start} ')
        mouth = (f'{shoulder.inner} L 231 {650-broad} '
                 f'C 169 {650-broad} {58+thin} {624-broad} {58+thin} 475 '
                 f'C {59+thin} 431 {101+thin} 405 {166+thin*.50} 405 '
                 f'Q 237 402 262 416 Q 276 423 281 410 '
                 f'C 291 387 283 {393-broad*.65} 266 {396-broad*.79} '
                 f'Q 260 {389-broad*.82} 245 {393-broad*.84} '
                 f'C 148 {414-broad*.86} 65 {418-broad*.33} 62 460 Z')
        return glyph(635, top + base + mouth)

    qof = glyph(594,
        roof_entry(nib, 38) +
        f'C 161 649 254 654 424 654 ' + descending_turn(nib, 552, 289, 61) +
        f'C 285 {654-broad} 137 {650-broad} 41 {650-broad} Z',
        detached_stem(nib, 68, 351, -223))
    return {'ע': ayin, 'ל': lamed, 'ה': he, 'פ': pe(), 'ף': pe(True),
            'ר': resh, 'ק': qof}
