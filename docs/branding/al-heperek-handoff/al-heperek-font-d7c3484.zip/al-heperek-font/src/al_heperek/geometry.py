"""Original construction helpers. No font outlines or upstream drawing code imported."""
from fontTools.pens.roundingPen import RoundingPen
from fontTools.svgLib.path import parse_path
import pathops

def emit(pen, commands):
    for command in commands:
        verb, *v = command
        if verb == 'M': pen.moveTo(tuple(v))
        elif verb == 'L': pen.lineTo(tuple(v))
        elif verb == 'C': pen.curveTo(tuple(v[:2]), tuple(v[2:4]), tuple(v[4:]))
        elif verb == 'Q': pen.qCurveTo(tuple(v[:2]), tuple(v[2:]))
        elif verb == 'Z': pen.closePath()
        else: raise ValueError(verb)

def circle(cx, cy, radius):
    k = radius * 0.5522847498
    return [('M', cx + radius, cy), ('C', cx + radius, cy + k, cx + k, cy + radius, cx, cy + radius),
            ('C', cx - k, cy + radius, cx - radius, cy + k, cx - radius, cy),
            ('C', cx - radius, cy - k, cx - k, cy - radius, cx, cy - radius),
            ('C', cx + k, cy - radius, cx + radius, cy - k, cx + radius, cy), ('Z',)]

def draw_spec(glyph, spec, stroke, character=''):
    """Expand authored centerlines, union overlaps, and save editable UFO contours."""
    total = pathops.Path()
    # Match cap heights across masters rather than allowing bold expansion to grow them.
    hebrew = bool(character) and 0x05D0 <= ord(character) <= 0x05EA
    lower = bool(character) and 'a' <= character <= 'z'
    reference_top = 615 if hebrew else 480 if lower else 665
    target_top = 650 if hebrew else 515 if lower else 700
    adjust = spec.get('normalize', True) and not spec.get('mark', False)
    factor = (target_top - stroke) / (reference_top - 35) if adjust else 1
    def normalized(commands):
        if not adjust: return commands
        transformed = []
        for command in commands:
            verb, *values = command
            values = [value if i % 2 == 0 else (value - 35) * factor + stroke / 2 for i, value in enumerate(values)]
            transformed.append((verb, *values))
        return transformed
    for commands in spec.get('strokes', []):
        curve = pathops.Path()
        emit(curve.getPen(), normalized(commands))
        curve.stroke(stroke * spec.get('strokeFactor', 1), pathops.LineCap.BUTT_CAP, pathops.LineJoin.ROUND_JOIN, 4)
        total.addPath(curve)
    for commands in spec.get('fills', []):
        curve = pathops.Path()
        emit(curve.getPen(), normalized(commands))
        total.addPath(curve)
    for outline in spec.get('outlines', []):
        curve = pathops.Path()
        parse_path(outline, curve.getPen())
        total.addPath(curve)
    for x, y, radius_factor in spec.get('dots', []):
        if adjust: y = (y - 35) * factor + stroke / 2
        curve = pathops.Path()
        emit(curve.getPen(), circle(x, y, stroke * radius_factor))
        total.addPath(curve)
    if total.verbs:
        total.convertConicsToQuads(0.1)
        total = pathops.simplify(total, clockwise=False)
        total.convertConicsToQuads(0.1)
        total.draw(RoundingPen(glyph.getPen()))
    glyph.width = spec['advance']
