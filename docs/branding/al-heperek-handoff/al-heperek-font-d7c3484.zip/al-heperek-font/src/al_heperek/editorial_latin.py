"""Original contour drawings for the editorial Latin companion.

SPDX-License-Identifier: LicenseRef-Al-Heperek-Proprietary
Copyright (c) 2026 DoradSoft. All rights reserved.

The letters and figures below are independent drawings, authored as filled
contours for this project. No font outlines, source drawings, or upstream font
construction code are imported or traced. The earlier, independently authored
punctuation remains in use while its own optical revision is pending.

Cap height is 700, x-height 515, ascender height 740; round forms overshoot the
alignment zones. The Latin has a different, script-appropriate contrast axis
from the Hebrew: stronger verticals and lighter horizontals. Weight changes
move the inner contours and joins rather than expanding a centerline drawing.
"""

from __future__ import annotations

from .latin import latin_glyphs as _original_punctuation

Path = list[tuple]


def _reverse(path: Path) -> Path:
    """Reverse a single closed contour, preserving the cubic geometry."""
    start = path[0][1:]
    previous = start
    segments = []
    for command in path[1:]:
        if command[0] == "Z":
            continue
        segments.append((previous, command))
        previous = command[-2:]
    result = [("M", *previous)]
    for begin, command in reversed(segments):
        if command[0] == "C":
            result.append(("C", *command[3:5], *command[1:3], *begin))
        elif command[0] == "Q":
            result.append(("Q", *command[1:3], *begin))
        else:
            result.append(("L", *begin))
    result.append(("Z",))
    return result


def _area(path: Path) -> float:
    """Determine orientation from a small, deterministic geometric sampling."""
    points = []
    current = (0.0, 0.0)
    for command in path:
        if command[0] in ("M", "L"):
            current = command[1:]
            points.append(current)
        elif command[0] == "C":
            x0, y0 = current
            x1, y1, x2, y2, x3, y3 = command[1:]
            for step in range(1, 13):
                t = step / 12
                u = 1 - t
                points.append((u**3 * x0 + 3 * u*u*t * x1 + 3 * u*t*t * x2 + t**3 * x3,
                               u**3 * y0 + 3 * u*u*t * y1 + 3 * u*t*t * y2 + t**3 * y3))
            current = (x3, y3)
        elif command[0] == "Q":
            x0, y0 = current
            x1, y1, x2, y2 = command[1:]
            for step in range(1, 13):
                t = step / 12
                u = 1 - t
                points.append((u*u*x0 + 2*u*t*x1 + t*t*x2,
                               u*u*y0 + 2*u*t*y1 + t*t*y2))
            current = (x2, y2)
    return sum(a[0] * b[1] - b[0] * a[1]
               for a, b in zip(points, points[1:] + points[:1])) / 2


def _p(*commands: tuple) -> Path:
    contour = list(commands)
    return _reverse(contour) if _area(contour) > 0 else contour


def _poly(*points: tuple[float, float]) -> Path:
    return _p(("M", *points[0]), *[("L", *point) for point in points[1:]], ("Z",))


def _rect(left: float, bottom: float, right: float, top: float) -> Path:
    return _poly((left, bottom), (left, top), (right, top), (right, bottom))


def _oval(left: float, bottom: float, right: float, top: float,
          tension: float = 0.56, center: float = 0.50) -> Path:
    """Four original cubic arcs; tension is tuned independently for each bowl."""
    cx = (left + right) / 2
    cy = bottom + (top - bottom) * center
    rx = (right - left) / 2
    upper = top - cy
    lower = cy - bottom
    return _p(("M", cx, top),
              ("C", cx + tension * rx, top, right, cy + tension * upper, right, cy),
              ("C", right, cy - tension * lower, cx + tension * rx, bottom, cx, bottom),
              ("C", cx - tension * rx, bottom, left, cy - tension * lower, left, cy),
              ("C", left, cy + tension * upper, cx - tension * rx, top, cx, top),
              ("Z",))


def _counter(outer: Path, *inners: Path) -> Path:
    return outer + [command for inner in inners for command in _reverse(inner)]


def _g(advance: int, *contours: Path) -> dict:
    return {"advance": advance, "strokes": [], "fills": list(contours),
            "dots": [], "normalize": False}


def _transform(path: Path, sx: float = 1, sy: float = 1,
               dx: float = 0, dy: float = 0) -> Path:
    result = []
    for command in path:
        if command[0] == "Z":
            result.append(command)
            continue
        values = command[1:]
        result.append((command[0], *[value * (sx if index % 2 == 0 else sy)
                                     + (dx if index % 2 == 0 else dy)
                                     for index, value in enumerate(values)]))
    # A reflection reverses every contour, including its counters, together.
    # Nonzero fill therefore retains the same outer/counter relationship.
    return result


def latin_glyphs(stroke: float = 96) -> dict[str, dict]:
    """Return 130 characters, with independently redrawn filled Latin forms.

    ``stroke`` is the nominal vertical weight in font units. These are review
    drawings, with explicit contours for each form; punctuation is inherited
    from the project's original construction and keeps its existing contract.
    """
    if not 45 <= stroke <= 145:
        raise ValueError("Editorial Latin is drawn for nominal weights 45–145")
    glyphs = _original_punctuation()
    v = float(stroke)
    h = v * 0.80
    # The amount by which an inner edge moves from the SemiBold reference.
    dv = v - 96
    dh = h - 76.8

    # Capitals. The round bowls are broader than the figures; the B has a
    # smaller upper bowl, and E/F have deliberately different middle arms.
    glyphs["A"] = _g(700, _counter(
        _poly((45, 0), (295, 700), (402, 700), (655, 0),
              (550 - dv * .45, 0), (478 - dv * .2, 209 - dh * .5),
              (219 + dv * .2, 209 - dh * .5), (145 + dv * .45, 0)),
        _poly((246 + dv * .42, 286 + dh * .5),
              (450 - dv * .42, 286 + dh * .5), (349, 584 - dv * .9))))
    b_outer = _p(("M", 75, 0), ("L", 75, 700), ("L", 322, 700),
                 ("C", 482, 700, 576, 636, 576, 521),
                 ("C", 576, 446, 536, 394, 468, 370),
                 ("C", 552, 351, 608, 293, 608, 195),
                 ("C", 608, 71, 508, 0, 334, 0), ("Z",))
    b_upper = _p(("M", 75 + v, 700 - h), ("L", 315, 700 - h),
                 ("C", 424, 700 - h, 576 - v, 589, 576 - v, 515),
                 ("C", 576 - v, 439, 425, 402 + dh * .4, 315, 402 + dh * .4),
                 ("L", 75 + v, 402 + dh * .4), ("Z",))
    b_lower = _p(("M", 75 + v, 325 - dh * .4), ("L", 325, 325 - dh * .4),
                 ("C", 448, 325 - dh * .4, 608 - v, 280, 608 - v, 195),
                 ("C", 608 - v, 115, 448, h, 325, h), ("L", 75 + v, h), ("Z",))
    glyphs["B"] = _g(660, _counter(b_outer, b_upper, b_lower))
    c_cap = _p(("M", 628, 619),
               ("C", 563, 681, 479, 712, 377, 712),
               ("C", 177, 712, 60, 574, 60, 350),
               ("C", 60, 127, 178, -12, 377, -12),
               ("C", 479, -12, 563, 20, 628, 81),
               ("L", 576 - dv * .35, 143 + dh * .35),
               ("C", 523, 94 + dh * .3, 459, -12 + h, 383, -12 + h),
               ("C", 239, -12 + h, 60 + v, 173, 60 + v, 350),
               ("C", 60 + v, 528, 239, 712 - h, 383, 712 - h),
               ("C", 459, 712 - h, 523, 607 - dh * .3, 576 - dv * .35, 557 - dh * .35),
               ("Z",))
    glyphs["C"] = _g(700, c_cap)
    d_outer = _p(("M", 75, 0), ("L", 75, 700), ("L", 307, 700),
                 ("C", 528, 700, 660, 569, 660, 351),
                 ("C", 660, 131, 528, 0, 307, 0), ("Z",))
    d_inner = _p(("M", 75 + v, h), ("L", 303, h),
                 ("C", 469, h, 660 - v, 174, 660 - v, 351),
                 ("C", 660 - v, 527, 469, 700 - h, 303, 700 - h),
                 ("L", 75 + v, 700 - h), ("Z",))
    glyphs["D"] = _g(720, _counter(d_outer, d_inner))
    glyphs["E"] = _g(610, _rect(75, 0, 75 + v, 700),
                      _rect(75, 700 - h, 550, 700), _rect(75, 0, 550, h),
                      _rect(75, 340 - h / 2, 488, 340 + h / 2))
    glyphs["F"] = _g(590, _rect(75, 0, 75 + v, 700),
                      _rect(75, 700 - h, 545, 700),
                      _rect(75, 352 - h / 2, 473, 352 + h / 2))
    glyphs["G"] = _g(740, c_cap, _rect(426, 307, 674, 307 + h),
                      _rect(674 - v, 101, 674, 307 + h))
    glyphs["H"] = _g(720, _rect(75, 0, 75 + v, 700), _rect(645 - v, 0, 645, 700),
                      _rect(75, 346 - h / 2, 645, 346 + h / 2))
    glyphs["I"] = _g(350, _rect(175 - v / 2, 0, 175 + v / 2, 700),
                      _rect(55, 700 - h, 295, 700), _rect(55, 0, 295, h))
    glyphs["J"] = _g(550, _p(("M", 500, 700), ("L", 500, 210),
        ("C", 500, 61, 419, -12, 280, -12),
        ("C", 185, -12, 120, 16, 68, 61), ("L", 113, 125 + dh * .4),
        ("C", 158, 86 + dh * .3, 208, -12 + h, 273, -12 + h),
        ("C", 358, -12 + h, 500 - v, 104, 500 - v, 216),
        ("L", 500 - v, 700 - h), ("L", 260, 700 - h),
        ("L", 260, 700), ("Z",)))
    glyphs["K"] = _g(680, _poly((75, 0), (75, 700), (75 + v, 700),
        (75 + v, 334 - dv * .3), (529 - dv * .35, 700), (650, 700),
        (338 + dv * .2, 374), (655, 0), (534 - dv * .5, 0),
        (267 - dv * .25, 306), (75 + v, 208 - dv * .4), (75 + v, 0)))
    glyphs["L"] = _g(590, _rect(75, 0, 75 + v, 700), _rect(75, 0, 542, h))
    glyphs["M"] = _g(880, _poly((75, 0), (75, 700), (182 + dv * .3, 700),
        (440, 240 + dv * .6), (698 - dv * .3, 700), (805, 700), (805, 0),
        (805 - v, 0), (805 - v, 531 + dv), (480 + dv * .3, 132),
        (400 - dv * .3, 132), (75 + v, 531 + dv), (75 + v, 0)))
    glyphs["N"] = _g(740, _poly((75, 0), (75, 700), (166 + dv * .45, 700),
        (665 - v, 161 + dv * .8), (665 - v, 700), (665, 700), (665, 0),
        (574 - dv * .45, 0), (75 + v, 539 - dv * .8), (75 + v, 0)))
    o_cap = _counter(_oval(60, -12, 700, 712, .565),
                     _oval(60 + v, -12 + h, 700 - v, 712 - h, .555))
    glyphs["O"] = _g(760, o_cap)
    p_outer = _p(("M", 75, 0), ("L", 75, 700), ("L", 321, 700),
        ("C", 492, 700, 589, 630, 589, 506),
        ("C", 589, 379, 492, 307, 321, 307), ("L", 75 + v, 307),
        ("L", 75 + v, 0), ("Z",))
    p_inner = _p(("M", 75 + v, 700 - h), ("L", 315, 700 - h),
        ("C", 433, 700 - h, 589 - v, 582, 589 - v, 506),
        ("C", 589 - v, 427, 433, 307 + h, 315, 307 + h),
        ("L", 75 + v, 307 + h), ("Z",))
    glyphs["P"] = _g(650, _counter(p_outer, p_inner))
    glyphs["Q"] = _g(780, o_cap,
        _poly((408, 181 + dh * .4), (486 + dv * .25, 204),
              (725, -76), (643 - dv * .35, -116)))
    glyphs["R"] = _g(700, _counter(p_outer, p_inner),
        _p(("M", 307, 331), ("L", 412 + dv * .3, 331),
           ("C", 435, 306, 451, 277, 476, 240),
           ("L", 656, 0), ("L", 535 - dv * .4, 0),
           ("L", 377 - dv * .25, 218),
           ("C", 350, 256, 330, 292, 307, 331), ("Z",)))
    glyphs["S"] = _g(660, _p(("M", 578, 624),
        ("C", 513, 682, 436, 712, 341, 712),
        ("C", 179, 712, 79, 628, 79, 510),
        ("C", 79, 393, 167, 347, 316, 305),
        ("C", 445, 269, 503 - dv * .6, 239, 503 - dv * .6, 172),
        ("C", 503 - dv * .6, 102, 438, -12 + h, 328, -12 + h),
        ("C", 238, -12 + h, 165, 96 + dh * .3, 107, 153 + dh * .4),
        ("L", 53, 90), ("C", 122, 22, 219, -12, 327, -12),
        ("C", 498, -12, 601, 64, 601, 184),
        ("C", 601, 297, 518, 349, 361, 393),
        ("C", 238, 428, 79 + v, 456, 79 + v, 521),
        ("C", 79 + v, 588, 236, 712 - h, 341, 712 - h),
        ("C", 417, 712 - h, 480, 610 - dh * .3, 525, 567 - dh * .35), ("Z",)))
    glyphs["T"] = _g(680, _rect(40, 700 - h, 640, 700),
                      _rect(340 - v / 2, 0, 340 + v / 2, 700))
    glyphs["U"] = _g(740, _p(("M", 75, 700), ("L", 75 + v, 700),
        ("L", 75 + v, 239), ("C", 75 + v, 124, 231, -12 + h, 370, -12 + h),
        ("C", 509, -12 + h, 665 - v, 124, 665 - v, 239),
        ("L", 665 - v, 700), ("L", 665, 700), ("L", 665, 238),
        ("C", 665, 73, 565, -12, 370, -12),
        ("C", 175, -12, 75, 73, 75, 238), ("Z",)))
    glyphs["V"] = _g(700, _poly((36, 700), (143 + dv * .45, 700),
        (350, 117 + dv * .65), (557 - dv * .45, 700), (664, 700),
        (402 + dv * .3, 0), (298 - dv * .3, 0)))
    glyphs["W"] = _g(1000, _poly((37, 700), (141 + dv * .4, 700),
        (280, 125 + dv * .5), (450 - dv * .3, 622), (550 + dv * .3, 622),
        (720, 125 + dv * .5), (859 - dv * .4, 700), (963, 700),
        (779 + dv * .3, 0), (679 - dv * .3, 0), (500, 505 - dv * .7),
        (321 + dv * .3, 0), (221 - dv * .3, 0)))
    glyphs["X"] = _g(680,
        _poly((43, 700), (161 + dv * .5, 700), (641, 0), (522 - dv * .5, 0)),
        _poly((528 - dv * .4, 700), (637, 700), (152 + dv * .4, 0), (43, 0)))
    glyphs["Y"] = _g(700, _poly((35, 700), (151 + dv * .45, 700),
        (350, 409 + dv * .65), (549 - dv * .4, 700), (665, 700),
        (350 + v / 2, 323), (350 + v / 2, 0), (350 - v / 2, 0),
        (350 - v / 2, 323)))
    glyphs["Z"] = _g(670, _poly((65, 700), (615, 700), (615, 633 - dh * .4),
        (176 + dv * .65, h), (618, h), (618, 0), (52, 0), (52, 67 + dh * .4),
        (491 - dv * .65, 700 - h), (65, 700 - h)))

    # Lowercase. The a/e counters and n/h shoulders are drawn to the same
    # optical colour, not to identical geometric widths. b/d/p/q are given
    # explicit asymmetric joins; the g is a compact double-storey form.
    a_outer = _p(("M", 500, 0), ("L", 411 - dv * .1, 0),
        ("L", 404 - dv * .2, 65), ("C", 365, 15, 313, -12, 246, -12),
        ("C", 134, -12, 65, 47, 65, 146),
        ("C", 65, 249, 149, 307, 287, 307),
        ("C", 333, 307, 371, 301, 500 - v, 290), ("L", 500 - v, 323),
        ("C", 500 - v, 407, 362, 527 - h, 286, 527 - h),
        ("C", 225, 527 - h, 168, 429 - dh * .3, 123, 397 - dh * .3),
        ("L", 90, 465), ("C", 151, 504, 218, 527, 297, 527),
        ("C", 434, 527, 500, 454, 500, 321), ("Z",))
    a_inner = _p(("M", 500 - v, 214 - dh * .25), ("L", 500 - v, 144),
        ("C", 371, 91, 327, -12 + h, 268, -12 + h),
        ("C", 204, -12 + h, 65 + v, 94, 65 + v, 147),
        ("C", 65 + v, 205, 212, 307 - h, 295, 307 - h),
        ("C", 334, 307 - h, 372, 229 - dh * .25, 500 - v, 214 - dh * .25), ("Z",))
    glyphs["a"] = _g(570, _counter(a_outer, a_inner))

    def right_bowl(ascender: bool, descender: bool = False) -> Path:
        bottom = -210 if descender else 0
        top = 740 if ascender else 515
        outer_commands = [("M", 75, bottom), ("L", 75, top), ("L", 75 + v, top),
            ("L", 75 + v, 455), ("C", 216, 502, 268, 527, 335, 527),
            ("C", 467, 527, 554, 423, 554, 261),
            ("C", 554, 100, 466, -12, 331, -12),
            ("C", 256, -12, 201, 18, 75 + v if descender else 165 + dv * .2, 67)]
        if descender:
            outer_commands.append(("L", 75 + v, bottom))
        else:
            outer_commands.append(("L", 157 + dv * .2, 0))
        outer = _p(*outer_commands, ("Z",))
        inner = _p(("M", 75 + v, 364), ("L", 75 + v, 150),
            ("C", 211, 95, 258, -12 + h, 317, -12 + h),
            ("C", 408, -12 + h, 554 - v, 136, 554 - v, 259),
            ("C", 554 - v, 384, 409, 527 - h, 319, 527 - h),
            ("C", 260, 527 - h, 209, 419, 75 + v, 364), ("Z",))
        return _counter(outer, inner)

    def left_bowl(ascender: bool, descender: bool = False) -> Path:
        bottom = -210 if descender else 0
        top = 740 if ascender else 515
        outer_commands = [("M", 565, bottom),
            ("L", 565 - v if descender else 483 - dv * .2, bottom),
            ("L", 565 - v if descender else 475 - dv * .2, 67),
            ("C", 430, 17, 374, -12, 302, -12),
            ("C", 168, -12, 82, 96, 82, 258),
            ("C", 82, 422, 170, 527, 306, 527),
            ("C", 371, 527, 425, 503, 565 - v, 458),
            ("L", 565 - v, top), ("L", 565, top)]
        outer = _p(*outer_commands, ("Z",))
        inner = _p(("M", 565 - v, 365),
            ("C", 430, 419, 379, 527 - h, 321, 527 - h),
            ("C", 229, 527 - h, 82 + v, 382, 82 + v, 259),
            ("C", 82 + v, 136, 228, -12 + h, 319, -12 + h),
            ("C", 377, -12 + h, 429, 95, 565 - v, 150), ("Z",))
        return _counter(outer, inner)

    glyphs["b"] = _g(630, right_bowl(True))
    glyphs["d"] = _g(640, left_bowl(True))
    glyphs["p"] = _g(630, right_bowl(False, True))
    glyphs["q"] = _g(640, left_bowl(False, True))
    c_lower = _p(("M", 510, 458),
        ("C", 457, 504, 393, 527, 314, 527),
        ("C", 155, 527, 60, 421, 60, 258),
        ("C", 60, 95, 155, -12, 314, -12),
        ("C", 393, -12, 457, 12, 510, 58), ("L", 462 - dv * .3, 119 + dh * .3),
        ("C", 421, 83 + dh * .2, 375, -12 + h, 320, -12 + h),
        ("C", 218, -12 + h, 60 + v, 136, 60 + v, 258),
        ("C", 60 + v, 381, 218, 527 - h, 320, 527 - h),
        ("C", 375, 527 - h, 421, 432 - dh * .2, 462 - dv * .3, 397 - dh * .3),
        ("Z",))
    glyphs["c"] = _g(570, c_lower)
    e_outer = _p(("M", 548, 236 - dh * .5), ("L", 158 + dv, 236 - dh * .5),
        ("C", 162 + dv, 123, 224, -12 + h, 324, -12 + h),
        ("C", 397, -12 + h, 454, 86 + dh * .2, 500, 124 + dh * .3),
        ("L", 540, 57), ("C", 479, 12, 404, -12, 315, -12),
        ("C", 153, -12, 60, 102, 60, 256),
        ("C", 60, 418, 156, 527, 303, 527),
        ("C", 454, 527, 548, 431, 548, 281), ("Z",))
    e_inner = _p(("M", 158 + dv, 310 + dh * .5), ("L", 452 - dv, 310 + dh * .5),
        ("C", 444 - dv, 401, 395, 527 - h, 307, 527 - h),
        ("C", 223, 527 - h, 174 + dv, 405, 158 + dv, 310 + dh * .5), ("Z",))
    glyphs["e"] = _g(600, _counter(e_outer, e_inner))
    glyphs["f"] = _g(420, _p(("M", 155, 0), ("L", 155, 515 - h),
        ("L", 55, 515 - h), ("L", 55, 515), ("L", 155, 515), ("L", 155, 599),
        ("C", 155, 700, 209, 758, 303, 758),
        ("C", 342, 758, 376, 751, 401, 741), ("L", 382, 667 - dh * .25),
        ("C", 359, 675 - dh * .25, 339, 758 - h, 315, 758 - h),
        ("C", 270, 758 - h, 155 + v, 653, 155 + v, 597),
        ("L", 155 + v, 515), ("L", 383, 515), ("L", 383, 515 - h),
        ("L", 155 + v, 515 - h), ("L", 155 + v, 0), ("Z",)))
    glyphs["g"] = _g(640,
        _counter(_oval(70, 135, 512, 527, .57, .51),
                 _oval(70 + v, 135 + h, 512 - v, 527 - h, .55, .51)),
        _counter(_oval(60, -215, 557, 88, .57, .50),
                 _oval(60 + v, -215 + h, 557 - v, 88 - h, .56, .50)),
        _poly((420, 480), (420, 515), (580, 515), (580, 442), (485, 442)),
        _p(("M", 173, 186), ("L", 253 + dv * .3, 186),
           ("C", 213, 148, 195 + dv * .3, 123, 195 + dv * .3, 103),
           ("C", 195 + dv * .3, 79, 218, 69, 263, 69),
           ("L", 391, 69), ("L", 391, 7 - dh * .3), ("L", 245, 7 - dh * .3),
           ("C", 158, 7 - dh * .3, 111, 42, 111, 93),
           ("C", 111, 130, 134, 159, 173, 186), ("Z",)))

    def shoulder(top: float) -> Path:
        return _p(("M", 75, 0), ("L", 75, top), ("L", 75 + v, top),
            ("L", 75 + v, 443), ("C", 214, 499, 270, 527, 343, 527),
            ("C", 470, 527, 544, 447, 544, 309),
            ("L", 544, 0), ("L", 544 - v, 0), ("L", 544 - v, 300),
            ("C", 544 - v, 404, 413, 527 - h, 330, 527 - h),
            ("C", 263, 527 - h, 209, 410, 75 + v, 347),
            ("L", 75 + v, 0), ("Z",))

    glyphs["h"] = _g(620, shoulder(740))
    glyphs["n"] = _g(620, shoulder(515))
    glyphs["i"] = _g(290, _rect(145 - v / 2, 0, 145 + v / 2, 515),
        _oval(145 - v * .58, 625, 145 + v * .58, 625 + v * 1.16, .55))
    glyphs["j"] = _g(330, _p(("M", 195 + v / 2, 515),
        ("L", 195 + v / 2, -31),
        ("C", 195 + v / 2, -152, 191, -215, 87, -215),
        ("C", 58, -215, 34, -210, 14, -201), ("L", 32, -127 + dh * .2),
        ("C", 49, -134 + dh * .2, 65, -215 + h, 82, -215 + h),
        ("C", 128, -215 + h, 195 - v / 2, -107, 195 - v / 2, -33),
        ("L", 195 - v / 2, 515), ("Z",)),
        _oval(195 - v * .58, 625, 195 + v * .58, 625 + v * 1.16, .55))
    glyphs["k"] = _g(600, _poly((75, 0), (75, 740), (75 + v, 740),
        (75 + v, 251 - dv * .3), (441 - dv * .35, 515), (560, 515),
        (333 + dv * .2, 306), (570, 0), (451 - dv * .4, 0),
        (264 - dv * .25, 243), (75 + v, 163 - dv * .4), (75 + v, 0)))
    glyphs["l"] = _g(330, _p(("M", 95, 740), ("L", 95 + v, 740),
        ("L", 95 + v, 129), ("C", 95 + v, 81, 211, -12 + h, 253, -12 + h),
        ("C", 270, -12 + h, 286, 67 + dh * .2, 300, 72 + dh * .2),
        ("L", 312, 0), ("C", 282, -9, 257, -12, 230, -12),
        ("C", 142, -12, 95, 33, 95, 124), ("Z",)))
    glyphs["m"] = _g(930, _p(("M", 75, 0), ("L", 75, 515),
        ("L", 168 + dv * .2, 515), ("L", 173 + dv * .2, 443),
        ("C", 216, 500, 270, 527, 333, 527),
        ("C", 418, 527, 473, 492, 504, 433),
        ("C", 553, 494, 612, 527, 686, 527),
        ("C", 795, 527, 855, 455, 855, 329), ("L", 855, 0),
        ("L", 855 - v, 0), ("L", 855 - v, 317),
        ("C", 855 - v, 405, 728, 527 - h, 663, 527 - h),
        ("C", 604, 527 - h, 557, 414, 429 + v, 357),
        ("L", 429 + v, 0), ("L", 429, 0), ("L", 429, 317),
        ("C", 429, 405, 394, 527 - h, 330, 527 - h),
        ("C", 266, 527 - h, 211, 411, 75 + v, 348), ("L", 75 + v, 0), ("Z",)))
    glyphs["o"] = _g(640, _counter(_oval(60, -12, 580, 527, .565, .503),
        _oval(60 + v, -12 + h, 580 - v, 527 - h, .555, .503)))
    glyphs["r"] = _g(450, _p(("M", 75, 0), ("L", 75, 515),
        ("L", 169 + dv * .2, 515), ("L", 173 + dv * .2, 417),
        ("C", 211, 489, 272, 527, 348, 527),
        ("C", 378, 527, 403, 523, 425, 514), ("L", 409, 424 - dh * .25),
        ("C", 387, 433 - dh * .25, 366, 437 - dh * .25, 342, 437 - dh * .25),
        ("C", 260, 437 - dh * .25, 204, 380, 75 + v, 291),
        ("L", 75 + v, 0), ("Z",)))
    glyphs["s"] = _g(550, _p(("M", 483, 464),
        ("C", 427, 506, 360, 527, 280, 527),
        ("C", 148, 527, 65, 464, 65, 371),
        ("C", 65, 284, 132, 248, 260, 214),
        ("C", 359, 187, 416 - dv * .6, 169, 416 - dv * .6, 126),
        ("C", 416 - dv * .6, 84, 365, -12 + h, 283, -12 + h),
        ("C", 211, -12 + h, 152, 85 + dh * .25, 102, 121 + dh * .25),
        ("L", 59, 58), ("C", 120, 11, 198, -12, 283, -12),
        ("C", 423, -12, 507, 45, 507, 137),
        ("C", 507, 227, 433, 264, 306, 299),
        ("C", 204, 327, 65 + v, 345, 65 + v, 385),
        ("C", 65 + v, 425, 207, 527 - h, 280, 527 - h),
        ("C", 342, 527 - h, 396, 434 - dh * .25, 440, 403 - dh * .25), ("Z",)))
    glyphs["t"] = _g(460, _p(("M", 142, 657), ("L", 142 + v, 679),
        ("L", 142 + v, 515), ("L", 404, 515), ("L", 404, 515 - h),
        ("L", 142 + v, 515 - h), ("L", 142 + v, 146),
        ("C", 142 + v, 86, 263, -12 + h, 306, -12 + h),
        ("C", 338, -12 + h, 368, 69 + dh * .2, 395, 82 + dh * .2),
        ("L", 420, 12), ("C", 379, -5, 337, -12, 292, -12),
        ("C", 190, -12, 142, 43, 142, 144), ("L", 142, 515 - h),
        ("L", 45, 515 - h), ("L", 45, 515), ("L", 142, 515), ("Z",)))
    glyphs["u"] = _g(620, _p(("M", 75, 515), ("L", 75 + v, 515),
        ("L", 75 + v, 204), ("C", 75 + v, 112, 207, -12 + h, 287, -12 + h),
        ("C", 354, -12 + h, 409, 107, 543 - v, 170),
        ("L", 543 - v, 515), ("L", 543, 515), ("L", 543, 0),
        ("L", 451 - dv * .2, 0), ("L", 446 - dv * .2, 73),
        ("C", 402, 17, 350, -12, 281, -12),
        ("C", 149, -12, 75, 100, 75, 206), ("Z",)))
    glyphs["v"] = _g(580, _poly((40, 515), (142 + dv * .45, 515),
        (290, 107 + dv * .6), (438 - dv * .45, 515), (540, 515),
        (338 + dv * .3, 0), (241 - dv * .3, 0)))
    glyphs["w"] = _g(830, _poly((40, 515), (141 + dv * .4, 515),
        (252, 108 + dv * .5), (369 - dv * .3, 463), (458 + dv * .3, 463),
        (575, 108 + dv * .5), (689 - dv * .4, 515), (790, 515),
        (632 + dv * .3, 0), (532 - dv * .3, 0), (415, 346 - dv * .6),
        (298 + dv * .3, 0), (198 - dv * .3, 0)))
    glyphs["x"] = _g(580,
        _poly((36, 515), (154 + dv * .5, 515), (548, 0), (430 - dv * .5, 0)),
        _poly((435 - dv * .4, 515), (544, 515), (145 + dv * .4, 0), (36, 0)))
    glyphs["y"] = _g(580, _poly((37, 515), (141 + dv * .4, 515),
        (293, 118 + dv * .5), (246, -2), (235 - dv * .3, 0)),
        _p(("M", 440 - dv * .4, 515), ("L", 544, 515),
           ("L", 300, -76), ("C", 255, -185, 209, -215, 127, -215),
           ("C", 96, -215, 68, -209, 45, -199), ("L", 63, -127 + dh * .2),
           ("C", 82, -134 + dh * .2, 101, -215 + h, 122, -215 + h),
           ("C", 163, -215 + h, 191, -115, 215, -59), ("Z",)))
    glyphs["z"] = _g(560, _poly((61, 515), (507, 515), (507, 449 - dh * .4),
        (176 + dv * .6, h), (509, h), (509, 0), (48, 0), (48, 66 + dh * .4),
        (379 - dv * .6, 515 - h), (61, 515 - h)))

    # Tabular lining figures. Oval figures are narrower than O/o; 1 has both
    # a flag and a baseline, 4 has a clear triangular counter, and 8 has a
    # visibly smaller upper compartment. No slashed-zero ambiguity in text.
    glyphs["0"] = _g(640, _counter(_oval(75, -12, 565, 712, .56),
        _oval(75 + v, -12 + h, 565 - v, 712 - h, .54)))
    glyphs["1"] = _g(640,
        _poly((151, 540), (304, 700), (379 + dv * .3, 700), (379 + dv * .3, 0),
              (379 + dv * .3 - v, 0), (379 + dv * .3 - v, 574 - dv * .4),
              (201, 485 - dh * .3)), _rect(161, 0, 522, h))
    glyphs["2"] = _g(640, _p(("M", 75, 551),
        ("C", 105, 654, 193, 712, 321, 712),
        ("C", 474, 712, 565, 638, 565, 519),
        ("C", 565, 424, 493, 352, 391, 270),
        ("L", 177 + dv * .6, h), ("L", 571, h), ("L", 571, 0),
        ("L", 70, 0), ("L", 70, 69 + dh * .35), ("L", 329, 303),
        ("C", 421, 386, 565 - v, 448, 565 - v, 520),
        ("C", 565 - v, 594, 416, 712 - h, 320, 712 - h),
        ("C", 229, 712 - h, 176, 590 - dh * .25, 163 + dv * .35, 523 - dh * .3),
        ("Z",)))
    glyphs["3"] = _g(640, _p(("M", 85, 626),
        ("C", 147, 682, 230, 712, 323, 712),
        ("C", 472, 712, 560, 637, 560, 525),
        ("C", 560, 448, 518, 390, 445, 367),
        ("C", 535, 348, 582, 286, 582, 194),
        ("C", 582, 68, 481, -12, 320, -12),
        ("C", 214, -12, 126, 23, 65, 85), ("L", 118, 148 + dh * .3),
        ("C", 172, 96 + dh * .2, 236, -12 + h, 317, -12 + h),
        ("C", 429, -12 + h, 582 - v, 114, 582 - v, 195),
        ("C", 582 - v, 280, 420, 327 - dh * .5, 311, 327 - dh * .5),
        ("L", 246, 327 - dh * .5), ("L", 246, 404 + dh * .5), ("L", 309, 404 + dh * .5),
        ("C", 412, 404 + dh * .5, 560 - v, 447, 560 - v, 522),
        ("C", 560 - v, 593, 411, 712 - h, 321, 712 - h),
        ("C", 247, 712 - h, 186, 612 - dh * .2, 137, 569 - dh * .3), ("Z",)))
    four = _poly((64, 219), (64, 286), (401, 700), (516, 700),
                 (516, 219 + h), (583, 219 + h), (583, 219),
                 (516, 219), (516, 0), (516 - v, 0), (516 - v, 219))
    four_counter = _poly((177 + dv * .4, 219 + h), (516 - v, 219 + h),
                          (516 - v, 594 - dv * .5))
    glyphs["4"] = _g(640, _counter(four, four_counter))
    glyphs["5"] = _g(640, _p(("M", 557, 700), ("L", 557, 700 - h),
        ("L", 211 + dv * .3, 700 - h), ("L", 190 + dv * .35, 422 + dh * .3),
        ("C", 231, 443, 279, 454, 330, 454),
        ("C", 484, 454, 577, 367, 577, 224),
        ("C", 577, 80, 475, -12, 319, -12),
        ("C", 218, -12, 135, 21, 72, 81), ("L", 124, 146 + dh * .3),
        ("C", 178, 95 + dh * .2, 242, -12 + h, 318, -12 + h),
        ("C", 423, -12 + h, 577 - v, 124, 577 - v, 222),
        ("C", 577 - v, 320, 423, 454 - h, 322, 454 - h),
        ("C", 267, 454 - h, 217, 362 - dh * .25, 173, 337 - dh * .25),
        ("L", 98, 365), ("L", 129, 700), ("Z",)))
    six_outer = _p(("M", 509, 632),
        ("C", 460, 685, 401, 712, 330, 712),
        ("C", 168, 712, 75, 570, 75, 348),
        ("C", 75, 117, 171, -12, 324, -12),
        ("C", 479, -12, 575, 100, 575, 245),
        ("C", 575, 390, 486, 468, 350, 468),
        ("C", 275, 468, 212, 442, 176 + dv * .4, 392),
        ("C", 182 + dv * .4, 546, 229, 712 - h, 333, 712 - h),
        ("C", 390, 712 - h, 436, 609 - dh * .2, 471, 571 - dh * .3), ("Z",))
    six = _counter(six_outer, _oval(75 + v, -12 + h, 575 - v, 468 - h, .56))
    glyphs["6"] = _g(640, six)
    glyphs["7"] = _g(640, _poly((68, 700), (579, 700), (579, 633 - dh * .3),
        (279 + dv * .45, 0), (172 - dv * .45, 0), (465 - dv * .5, 700 - h), (68, 700 - h)))
    eight_outer = _p(("M", 320, 712),
        ("C", 471, 712, 562, 637, 562, 526),
        ("C", 562, 451, 521, 395, 457, 365),
        ("C", 541, 333, 588, 270, 588, 185),
        ("C", 588, 65, 486, -12, 320, -12),
        ("C", 154, -12, 52, 65, 52, 185),
        ("C", 52, 270, 99, 333, 183, 365),
        ("C", 119, 395, 78, 451, 78, 526),
        ("C", 78, 637, 169, 712, 320, 712), ("Z",))
    eight_upper = _oval(78 + v, 402 + dh * .4, 562 - v, 712 - h, .56)
    eight_lower = _oval(52 + v, -12 + h, 588 - v, 325 - dh * .4, .57)
    glyphs["8"] = _g(640, _counter(eight_outer, eight_upper, eight_lower))
    glyphs["9"] = _g(640, _transform(six, -1, -1, 640, 700))

    # Currency and letter-containing badges use the new contour drawings too.
    # Their strokes are drawn as fills, so the nominal weight is not applied a
    # second time by the compiler. Badge counters and the enclosed letter's
    # counters keep opposite winding independently of one another.
    glyphs["$"] = _g(660, *glyphs["S"]["fills"],
        _rect(330 - v * .30, -85, 330 + v * .30, 785))
    glyphs["\u00a2"] = _g(570, *glyphs["c"]["fills"],
        _rect(299 - v * .30, -85, 299 + v * .30, 600))
    glyphs["\u00a5"] = _g(700, *glyphs["Y"]["fills"],
        _rect(140, 300 - h * .43, 560, 300 + h * .43),
        _rect(140, 161 - h * .43, 560, 161 + h * .43))
    glyphs["\u20ac"] = _g(700, *glyphs["C"]["fills"],
        _rect(31, 425 - h * .43, 466, 425 + h * .43),
        _rect(31, 272 - h * .43, 438, 272 + h * .43))
    badge_ring = _counter(_oval(55, -12, 785, 712, .552),
        _oval(55 + v * .64, -12 + h * .72,
              785 - v * .64, 712 - h * .72, .552))
    glyphs["\u00a9"] = _g(840, badge_ring,
        *[_transform(contour, .52, .52, 238, 168)
          for contour in glyphs["C"]["fills"]])
    glyphs["\u00ae"] = _g(840, badge_ring,
        *[_transform(contour, .49, .49, 248.5, 178.5)
          for contour in glyphs["R"]["fills"]])
    glyphs["\u2122"] = _g(850,
        *[_transform(contour, .43, .43, 100, 399)
          for contour in glyphs["T"]["fills"]],
        *[_transform(contour, .43, .43, 380, 399)
          for contour in glyphs["M"]["fills"]])

    if len(glyphs) != 130:
        raise AssertionError(f"Unexpected Latin/punctuation coverage: {len(glyphs)}")
    return glyphs
