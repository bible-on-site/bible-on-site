"""Original pen movements shared across the upright Hebrew alphabet."""
from dataclasses import dataclass


@dataclass(frozen=True)
class Nib:
    broad: int
    thin: int
    display: bool = False


def nib_for_weight(weight, *, display=False):
    """Select pen dimensions for one of the three OS/2 weights and two cuts."""
    reading, headline = {
        400: ((103, 59), (123, 57)),
        600: ((131, 80), (153, 72)),
        700: ((156, 99), (175, 87)),
    }[weight]
    broad, thin = headline if display else reading
    return Nib(broad, thin, display)


def point(x, y):
    return f'{x:.2f} {y:.2f}'


@dataclass(frozen=True)
class Turn:
    """Two contour fragments with their four intended attachment points."""
    outer_start: str
    outer: str
    outer_end: str
    inner_start: str
    inner: str
    inner_end: str


def roof_entry(nib, left, top=650, reach=96):
    """Turn a lifted nib into the shelf, leaving light under the entry."""
    edge = top - nib.broad
    crest = 38 if nib.display else 33
    spread = 1.08 if nib.display else 1
    return (f'M {point(left+3,edge)} '
            f'C {point(left-17*spread,edge+3)} {point(left-24*spread,edge+28)} {point(left-23*spread,edge+50)} '
            f'Q {point(left-21*spread,top+3)} {point(left-8,top+crest-2)} '
            f'Q {point(left-5,top+crest+4)} {point(left+1,top+crest-4)} '
            f'C {point(left+reach*.17,top+1)} {point(left+reach*.36,top-8)} {point(left+reach*.57,top-7)} '
            f'C {point(left+reach*.73,top-6)} {point(left+reach*.86,top)} {point(left+reach,top)} ')


def stem_exit(nib, right, bottom=0):
    """Release an upright along a rising cut with a narrow leading toe."""
    left = right - nib.thin
    lift = nib.thin * .20
    return (f'L {point(right,bottom+lift+5)} Q {point(right,bottom+lift)} {point(right-8,bottom+lift-1)} '
            f'Q {point(left+nib.thin*.44,bottom+lift*.50)} {point(left-4,bottom)} '
            f'Q {point(left-9,bottom-1)} {point(left-7,bottom+6)} '
            f'Q {point(left-2,bottom+20)} {point(left,bottom+34)} ')


def floor_exit(nib, left, bottom=0):
    """Let an open lower shelf thin out and lift at the left nib edge."""
    top = bottom + nib.broad
    return (f'L {point(left+5,bottom)} Q {point(left-3,bottom)} {point(left-1,bottom+11)} '
            f'C {point(left+3,bottom+24)} {point(left+9,top-20)} {point(left+16,top-6)} '
            f'Q {point(left+20,top+3)} {point(left+29,top)} '
            f'Q {point(left+45,top-5)} {point(left+68,top-4)} ')


def shoulder_turn(nib, right, top=650, run=180, drop=158):
    """Carry weight over a low crown, then narrow into the upright."""
    h, v = nib.broad, nib.thin
    run = max(run, v + 30)
    left = right - run
    elbow = min(top - drop, top - h - 32)
    fall = top - elbow
    outer_start, outer_end = point(left, top), point(right, elbow)
    outer = (f'C {point(left+run*.28,top)} {point(left+run*.47,top+8)} '
             f'{point(left+run*.68,top-3)} '
             f'C {point(left+run*.94,top-17)} {point(right,elbow+fall*.42)} {outer_end}')
    inner_width, inner_height = run - v, top - h - elbow
    inner_start, inner_end = point(right - v, elbow), point(left, top - h)
    inner = (f'C {point(right-v,elbow+inner_height*.64)} '
             f'{point(left+inner_width*.79,top-h-4)} {point(left+inner_width*.55,top-h-2)} '
             f'Q {point(left+inner_width*.30,top-h)} {inner_end}')
    return Turn(outer_start, outer, outer_end, inner_start, inner, inner_end)


def bowl_turn(nib, right, bottom=-6, run=255, rise=281):
    """Shift bowl stress onto the lower diagonal, flattening the last arc."""
    h, v = nib.broad, nib.thin
    left = right - run
    outer_start, outer_end = point(right, bottom + rise), point(left, bottom)
    outer = (f'C {point(right,bottom+rise*.67)} {point(right-run*.08,bottom+rise*.39)} '
             f'{point(right-run*.28,bottom+rise*.19)} '
             f'C {point(right-run*.45,bottom+rise*.02)} {point(left+run*.27,bottom)} {outer_end}')
    width, height = run - v, rise - h
    inner_start, inner_end = point(left, bottom + h), point(right - v, bottom + rise)
    inner = (f'C {point(left+width*.53,bottom+h)} {point(right-v,bottom+h+height*.44)} {inner_end}')
    return Turn(outer_start, outer, outer_end, inner_start, inner, inner_end)


def open_head(nib, left, top=663):
    """The tilted opening face of a freestanding upright, into its right side."""
    v = nib.thin
    return (f'Q {point(left+3,top-31)} {point(left+12,top-27)} '
            f'C {point(left+v*.42,top-23)} {point(left+v*.68,top-11)} {point(left+v*.87,top-2)} '
            f'Q {point(left+v,top+2)} {point(left+v+9,top-11)} '
            f'C {point(left+v+35,top-48)} {point(left+v+34,top-101)} {point(left+v+29,top-156)} ')


def entry_leg(nib, left):
    """Open tet and shin with an oblique nib face and a short inward sweep."""
    v = nib.thin
    outer_start, outer_end = point(left+5, 627), point(left+30+v, 285)
    outer = (f'{open_head(nib,left)}'
             f'Q {point(left+v+26,366)} {outer_end}')
    inner_start, inner_end = point(left+20, 274), outer_start
    inner = (f'C {point(left+13,364)} {point(left+26,488)} {point(left+18,559)} '
             f'Q {point(left+16,593)} {inner_end}')
    return Turn(outer_start, outer, outer_end, inner_start, inner, inner_end)


def diagonal_entry(nib, left, top=665):
    """Lift from the left edge onto the face of a diagonal downstroke."""
    width = nib.broad * .54 + nib.thin * .39
    return (f'M {point(left,top-49)} '
            f'Q {point(left-3,top-42)} {point(left+6,top-35)} '
            f'Q {point(left+width*.28,top-25)} {point(left+width*.56,top-3)} '
            f'Q {point(left+width*.62,top+2)} {point(left+width*.71,top-5)} '
            f'Q {point(left+width*.94,top-22)} {point(left+width*1.09,top-38)} ')


def returning_arm(nib, joint_x, joint_y, run=254, top=666):
    """A broad inclined head narrows into the right arm of alef and both tsadis."""
    right = joint_x + run
    rise = top - joint_y
    face = nib.broad * .66 + nib.thin * .40 + 36
    depth = nib.broad * .80 + 27
    return (f'M {point(joint_x-19,joint_y+16)} '
            f'C {point(joint_x+run*.38,joint_y+rise*.23)} '
            f'{point(right-face*.62,top-depth*1.74)} {point(right-face*.62,top-depth*1.15)} '
            f'Q {point(right-face*.62,top-depth*.91)} {point(right-face*.84,top-depth*.78)} '
            f'Q {point(right-face*1.05,top-depth*.66)} {point(right-face*1.09,top-depth*.49)} '
            f'Q {point(right-face*1.11,top-depth*.40)} {point(right-face*1.04,top-depth*.29)} '
            f'L {point(right-face*.85,top-5)} Q {point(right-face*.81,top+1)} {point(right-face*.75,top-3)} '
            f'C {point(right-face*.51,top-depth*.17)} {point(right-face*.27,top-depth*.13)} '
            f'{point(right-face*.12,top-depth*.28)} '
            f'Q {point(right+1,top-depth*.39)} {point(right+1,top-depth*.59)} '
            f'C {point(right,top-depth*1.56)} {point(joint_x+run*.60,joint_y+rise*.18)} '
            f'{point(joint_x+10,joint_y-23)} Z')
