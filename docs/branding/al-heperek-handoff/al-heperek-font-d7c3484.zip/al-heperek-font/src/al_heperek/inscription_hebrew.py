"""Original Hebrew title letters with hollowed ends and open stone-like counters.

The right wall is slightly waisted. The horizontal stroke approaches its open
end by swelling on both faces. Coordinates describe the ink before fitting.
"""
from .editorial_hebrew import glyph


def inscription_letters(weight):
    h, v = {400: (84, 69), 600: (113, 90), 700: (139, 110)}[weight]
    letters = {}

    def put(ch, advance, *contours, center=None, bottom=None, top=None):
        middle = advance // 2
        drawing = glyph(advance, *contours)
        drawing['anchors'] = {
            'center': center or (middle, 322),
            'bottom': bottom or (middle, -65),
            'top': top or (middle, 760),
        }
        letters[ch] = drawing

    def foot(right, bottom):
        # The contour arrives at the outside of the stem, just above its foot.
        return (f'C {right-2} {bottom+42} {right+8} {bottom+24} {right+23} {bottom+6} '
                f'Q {right+26} {bottom+1} {right+20} {bottom} '
                f'Q {right-v*.46} {bottom+14} {right-v-19} {bottom} '
                f'Q {right-v-24} {bottom-1} {right-v-21} {bottom+7} '
                f'C {right-v-6} {bottom+32} {right-v+2} {bottom+48} {right-v+3} {bottom+80} ')

    def left_face(x, y, depth):
        # A shallow concave end against light, with short radii at both tips.
        lift = depth*.15
        return (f'M {x+3} {y+lift} Q {x+1} {y+lift+5} {x+8} {y+lift+3} '
                f'C {x+31} {y+lift*.55} {x+53} {y} {x+90} {y} ')

    def end_face(x, y, depth):
        return (f'Q {x+32} {y-depth} {x+6} {y-depth-11} '
                f'Q {x} {y-depth-13} {x+2} {y-depth-6} '
                f'Q {x+16} {y-depth*.45} {x+3} {y+depth*.15} Z')

    def corner(left, right, bottom=0):
        top, inflect = 648, 198
        return (left_face(left,top,h) +
                f'L {right-142} {top} C {right-47} {top} {right+5} {top-34} {right+4} {top-134} '
                f'C {right+2} 383 {right-8} {bottom+inflect} {right-2} {bottom+80} ' +
                foot(right,bottom) +
                f'C {right-v+11} {bottom+inflect} {right-v+12} 377 {right-v+6} {top-139} '
                f'Q {right-v+3} {top-h} {right-152} {top-h} L {left+85} {top-h} ' +
                end_face(left,top,h))

    def pier(x, top, bottom=0):
        # An independent upright. Its broad head and broad base frame a waist.
        right = x+v
        return (f'M {x-15} {top-1} Q {x-18} {top+6} {x-10} {top+4} '
                f'Q {x+v*.43} {top-6} {right+11} {top+8} Q {right+17} {top+10} {right+14} {top+2} '
                f'C {right-5} {top-48} {right-4} {top-104} {right-5} {top-145} '
                f'C {right-6} {top-198} {right-5} {bottom+125} {right-2} {bottom+80} ' +
                foot(right,bottom) +
                f'C {x+6} {bottom+154} {x+7} {top-180} {x+5} {top-108} '
                f'Q {x+5} {top-38} {x-15} {top-1} Z')

    def basin(left, right, bottom=-3, lip=0):
        # A low, open left cup is shared by bet, tsadi, pe and kaf.
        return (f'M {left+3} {bottom+h+6} Q {left+2} {bottom+h+13} {left+11} {bottom+h+10} '
                f'Q {left+37} {bottom+h} {left+97} {bottom+h} '
                f'L {right-92} {bottom+h} Q {right-23} {bottom+h} {right+lip-5} {bottom+h+15} '
                f'Q {right+lip+4} {bottom+h+18} {right+lip+2} {bottom+h+8} '
                f'Q {right+lip-6} {bottom+h*.5} {right+lip+5} {bottom+6} '
                f'Q {right+lip+7} {bottom-1} {right+lip} {bottom} L {left+36} {bottom} '
                f'Q {left+15} {bottom} {left+2} {bottom-6} Q {left-4} {bottom-9} {left-2} {bottom-1} '
                f'Q {left+11} {bottom+h*.46} {left+3} {bottom+h+6} Z')

    def fork(x, y, right):
        # A small, broad scooped head narrows into this diagonal. Use the
        # exact drawing for tsadi, final tsadi and alef with optical lengths.
        head = v + 27
        neck = right-head*.40
        shaft = v*.82 + 7
        control = x+(right-x)*.46
        return (f'M {x-shaft*.30} {y+shaft*.44} '
                f'C {control-shaft*.32} {y+64+shaft*.42} {neck-shaft*.50} 455 {neck-shaft*.50} 532 '
                f'Q {neck-shaft*.50} 560 {right-head*1.08} 582 '
                f'Q {right-head*1.32} 598 {right-head*1.32} 617 '
                f'Q {right-head*1.32} 622 {right-head*1.25} 621 '
                f'Q {right-head*.78} 618 {right-head*.35} 650 '
                f'Q {right-head*.25} 659 {right-head*.15} 650 '
                f'Q {right+14} 615 {right+5} 572 Q {neck+shaft*.50} 550 {neck+shaft*.50} 532 '
                f'C {neck+shaft*.50} 455 {control+shaft*.32} {y+64-shaft*.42} {x+shaft*.30} {y-shaft*.44} Z')

    def descending(right, tail, y):
        # From the crown to a low blunt tongue on lamed and qof.
        return (f'C {right-30} 650 {right+2} 607 {right+2} 531 '
                f'L {right+2} 491 C {right+4} 415 {right-20} 378 {right-62} 338 '
                f'C {right-125} 278 {tail+v*.14} {y+155} {tail+v*.11} {y+89} '
                f'C {tail+v*.10} {y+54} {tail+v*.42} {y+31} {tail+v*.61} {y+24} '
                f'Q {tail+v*.73} {y+20} {tail+v*.59} {y+16} '
                f'Q {tail+v*.13} {y+13} {tail-v*.16} {y} Q {tail-v*.24} {y-4} {tail-v*.34} {y+1} '
                f'C {tail-v*.78} {y+17} {tail-v*.92} {y+53} {tail-v*.81} {y+87} '
                f'C {tail-v*.54} {y+176} {right-v-140} 285 {right-v-91} 338 '
                f'Q {right-v+4} 449 {right-v+2} 515 '
                f'Q {right-v+2} {650-h} {right-160} {650-h} ')

    put('ר',655,corner(43,590))
    put('ה',708,corner(43,640),pier(88,352))
    put('ו',284,corner(38,228),center=(124-v*.28,319),top=(154,760))
    put('ך',649,corner(41,584,-225),bottom=(277,175))
    put('ח',712,corner(43,642),pier(87,625))
    put('ב',709,corner(44,600,24),basin(42,607,-2,40))
    put('ת',756,corner(44,688),pier(151,604,18),basin(48,155+v,0))
    put('ן',285,corner(40,222,-225),bottom=(69,-65),center=(114-v*.3,319))
    put('ק',694,
        left_face(42,650,h) + 'L 495 650 ' + descending(627,332,65) +
        f'L 128 {650-h} ' + end_face(42,650,h),pier(90,356,-224))
    put('ל',604,
        f'M 48 882 Q 45 888 52 889 Q {77+v*.36} 881 {99+v*.46} 897 '
        f'Q {105+v*.46} 901 {109+v*.49} 892 '
        f'C {127+v*.55} 852 {97+v*.35} 754 {110+v*.39} 678 '
        f'Q {114+v*.43} 650 {151+v*.47} 650 L 400 650 ' + descending(535,235,-4) +
        f'L 71 {650-h} Q 62 {650-h-2} 64 {650-h+9} '
        f'C 78 646 88 743 73 801 Q 69 850 48 882 Z')
    put('ע',696,
        f'M 56 632 Q 53 638 60 638 Q {84+v*.32} 633 {111+v*.49} 653 '
        f'Q {119+v*.49} 658 {122+v*.48} 650 Q {129+v*.53} 632 {124+v*.54} 603 '
        f'L {247+v*.58} {94+h*.69} '
        f'C 416 {h+90} {605-v} 285 {605-v} 447 '
        f'C {605-v} 523 {589-v} 570 {547-v} 617 Q {542-v} 624 {553-v} 627 '
        f'Q {583-v} 631 {604-v*.40} 660 Q {609-v*.40} 665 {615-v*.36} 657 '
        f'C 627 606 626 531 625 461 C 621 245 517 133 347 70 '
        f'Q 177 7 52 -12 Q 43 -14 45 -5 Q 57 {h*.38} 47 {h+15} '
        f'Q 46 {h+22} 55 {h+19} Q 134 {h+1} 222 {h+37} '
        f'L 101 556 Q 86 607 56 632 Z')

    def pe(final):
        r = 647
        outer = (f'M 65 462 C 63 566 121 651 223 651 L 472 651 '
                 f'C 596 651 {r} 616 {r} 514 ')
        if final:
            contour = (f'C {r-1} 359 {r-9} 26 {r-2} -145 ' + foot(r,-225) +
                       f'C {r-v+12} 22 {r-v+12} 283 {r-v+6} 493 ')
        else:
            contour = (f'L {r} 249 C {r} 86 572 -4 401 -4 L 73 -4 Q 61 -4 45 -10 '
                       f'Q 40 -13 42 -5 Q 56 {h*.43} 45 {h+9} Q 44 {h+16} 51 {h+14} '
                       f'Q 79 {h-1} 136 {h-1} L 408 {h-1} '
                       f'Q {r-v+7} {h-1} {r-v+7} 287 L {r-v+6} 493 ')
        mouth = (f'Q {r-v+4} {651-h} 476 {651-h} L 242 {651-h} '
                 f'Q {65+v} {651-h} {65+v} 478 Q {65+v} 405 208 405 '
                 f'Q 262 406 310 434 Q 318 439 315 430 '
                 f'C 308 415 296 {420-h*.37} 299 {414-h*.54} '
                 f'Q 301 {410-h*.72} 314 {407-h*.87} Q 319 {401-h*.89} 310 {401-h*.90} '
                 f'C 269 {396-h*.90} 217 {404-h*.93} 174 {409-h*.88} Q 69 {430-h*.73} 65 462 Z')
        return outer + contour + mouth

    put('פ',720,pe(False),center=(386,318))
    put('ף',720,pe(True),center=(386,318))

    diagonal = (f'M 47 611 Q 42 617 52 621 Q {78+v*.24} 632 {83+v*.44} 656 '
                f'Q {87+v*.43} 662 {96+v*.42} 651 ')
    put('א',722,
        diagonal + f'C 247 482 449 265 635 72 Q 646 61 654 55 '
        f'Q 659 50 651 44 Q {611-v*.28} 21 {604-v*.29} -3 Q {600-v*.29} -10 {594-v*.29} -2 '
        f'C 426 185 236 403 47 611 Z',
        f'M 252 487 L {265+v*.46} 447 Q {166+v*.45} 368 {141+v} 301 '
        f'Q {132+v} 240 {131+v} 130 Q {130+v} 53 {151+v} 8 '
        f'Q {156+v} -1 {146+v} 1 Q {95+v*.44} 11 63 -2 Q 55 -4 59 6 '
        f'Q 77 61 77 127 Q 80 267 116 337 Q 152 406 252 487 Z',
        fork(408,257,627))
    put('צ',662,
        diagonal + f'Q 265 443 392 297 Q 465 211 544 {h+20} '
        f'Q 565 {h-4} 561 47 L 552 2 L 95 2 Q 70 2 47 -6 Q 39 -9 42 1 '
        f'Q 55 {h*.51} 44 {h+7} Q 42 {h+16} 52 {h+12} Q 76 {h} 123 {h} '
        f'L {536-v} {h} Q 256 343 47 611 Z',fork(311,356,589))
    put('ץ',633,
        diagonal + f'Q 236 471 313 367 Q {352+v*.40} 284 {349+v*.40} 178 '
        f'Q {346+v*.40} 19 {350+v*.40} -145 ' + foot(352+v*.40,-225) +
        f'Q {358-v*.56} 120 {345-v*.56} 203 Q {334-v*.53} 264 248 365 Q 148 497 47 611 Z',
        fork(280,337,575))

    def slab(left, right, base=648):
        return (left_face(left,base,h) + f'L {right-72} {base} '
                f'Q {right-26} {base} {right-4} {base+8} Q {right+3} {base+10} {right} {base} '
                f'Q {right-11} {base-h*.47} {right+1} {base-h-4} Q {right+3} {base-h-10} {right-4} {base-h-8} '
                f'Q {right-30} {base-h} {right-73} {base-h} L {left+80} {base-h} ' + end_face(left,base,h))

    put('ד',688,slab(43,631),pier(544-v,615))
    put('ז',367,slab(37,313),pier(215-v,615),center=(145-v*.48,321))
    put('י',331,
        left_face(49,651,h) + f'L 153 651 Q 265 651 269 559 Q 268 454 181 397 '
        f'Q 174 392 169 397 L {169-v*.65} 426 Q {161-v*.65} 429 {171-v*.65} 437 '
        f'Q {244-v} 477 {250-v} 515 Q {253-v} {651-h} {193-v*.70} {651-h} L 133 {651-h} ' +
        end_face(49,651,h))
    put('כ',653,
        left_face(43,650,h) + f'L 271 650 C 469 650 586 535 594 355 '
        f'C 606 146 468 -3 237 -3 L 91 -3 Q 62 -3 44 -10 Q 39 -12 41 -4 '
        f'Q 54 {h*.48} 42 {h+8} Q 41 {h+17} 49 {h+13} Q 80 {h-1} 122 {h-1} '
        f'L 251 {h-1} C 389 {h-1} {593-v} 183 {593-v} 340 '
        f'C {593-v} 485 413 {650-h} 267 {650-h} L 126 {650-h} ' + end_face(43,650,h))
    put('נ',504,
        left_face(132,650,h) + f'L 273 650 C 405 650 451 604 448 495 '
        f'L 444 306 Q 443 119 302 34 Q 234 -5 121 -3 Q 76 -4 48 -12 Q 39 -14 42 -5 '
        f'Q 57 {h*.46} 45 {h+8} Q 43 {h+16} 52 {h+12} Q 90 {h+2} 128 {h+2} '
        f'C 258 {h+2} {438-v} 169 {439-v} 313 L {445-v} 479 '
        f'Q {446-v} {650-h} 280 {650-h} L 214 {650-h} ' + end_face(132,650,h))
    put('ג',565,
        left_face(149,650,h)+f'L 265 650 Q 420 650 411 540 C 394 396 362 322 384 254 '
        f'Q 416 153 501 52 Q 514 37 523 25 Q 528 17 518 17 Q {478-v*.38} 17 {467-v*.42} -2 '
        f'Q {460-v*.46} -8 {454-v*.46} 1 Q 371 98 331 196 Q 247 76 108 10 '
        f'Q 75 -5 46 -5 Q 36 -5 41 7 Q 53 {h*.48} 44 {h+4} Q 42 {h+11} 52 {h+10} '
        f'Q 215 {h+31} 301 238 Q 330 298 {401-v} 523 Q {400-v} {650-h} 269 {650-h} '
        f'L 234 {650-h} '+end_face(149,650,h))
    put('ם',704,
        left_face(46,650,h)+f'L 474 650 Q 648 651 640 481 L 622 12 Q 621 0 610 0 '
        f'L 87 0 Q 73 0 74 12 Q 82 281 95 {650-h} L 90 {650-h} '+end_face(46,650,h),
        f'M {78+v} {h} L {625-v} {h} L {637-v} 447 Q {642-v} {650-h} 479 {650-h} '
        f'L {95+v} {650-h} Q {81+v} 357 {78+v} {h} Z')
    put('ס',710,
        left_face(47,650,h)+f'L 324 650 C 548 654 652 542 646 354 '
        f'C 644 128 522 -9 346 -9 C 163 -11 77 108 75 281 Q 77 426 112 {650-h} '
        f'L 104 {650-h} '+end_face(47,650,h),
        f'M {111+v} {650-h} Q {72+v} 414 {75+v} 284 Q {79+v} {h-5} 338 {h-5} '
        f'C 481 {h-5} {645-v} 220 {646-v} 357 Q {650-v} {650-h} 324 {650-h} Z')
    put('מ',737,
        f'M 53 624 Q 46 631 57 632 Q {90+v*.23} 632 {115+v*.42} 657 Q {123+v*.42} 662 {128+v*.42} 650 '
        f'Q 174 595 193 535 Q 281 653 414 655 Q 685 663 670 427 L 649 10 Q 648 -1 634 0 '
        f'L 356 0 Q 344 -1 346 10 Q 359 {h*.49} 348 {h+9} Q 346 {h+17} 356 {h+12} '
        f'Q 410 {h-2} {651-v} {h+2} L {668-v} 422 Q {676-v} {648-h} 420 {648-h} '
        f'C 312 {648-h} 244 497 220 396 L {100+v} 92 Q {93+v} 42 {110+v} 7 '
        f'Q {115+v} 0 {105+v} 0 Q {82+v*.43} 10 53 -1 Q 47 -3 50 6 '
        f'L 121 419 Q 144 548 53 624 Z')

    def left_prong(left, top):
        return (f'M {left} {top-44} Q {left-6} {top-37} {left+3} {top-35} '
                f'Q {left+v*.45} {top-33} {left+v*.79} {top-6} Q {left+v*.87} {top+2} {left+v*.94} {top-7} '
                f'Q {left+v+43} {top-65} {left+v+34} {top-162} ')
    put('ט',727,
        left_prong(51,665)+f'L {84+v} 327 Q {91+v} {h-2} 337 {h-2} '
        f'C 500 {h-1} {650-v} 190 {651-v} 362 L {652-v} 454 Q {653-v} {653-h} 511 {653-h} '
        f'Q 416 {653-h} 375 421 Q 361 387 364 361 Q 366 350 355 355 '
        f'Q {350-v*.47} 366 {347-v*.65} 355 Q {339-v*.66} 349 {338-v*.69} 361 '
        f'C 277 522 379 662 512 662 Q 657 665 655 498 L 651 363 '
        f'C 647 130 520 -9 336 -10 C 139 -11 66 135 75 337 L 80 487 '
        f'Q 84 567 51 621 Z')
    put('ש',817,
        left_prong(46,661)+f'L {77+v} 326 Q {73+v} 230 202 168 '
        f'C 300 246 337 359 335 478 Q 338 566 301 614 Q 293 627 305 627 '
        f'Q {330+v*.29} 627 {341+v*.56} 650 Q {348+v*.60} 657 {355+v*.62} 647 '
        f'C {397+v*.35} 572 {378+v*.40} 463 {370+v*.34} 407 Q {343+v*.37} 209 255 {h+24} '
        f'Q 306 {h-5} 386 {h-5} C 565 {h-5} {748-v} 233 {748-v} 402 '
        f'L {748-v} 483 Q {750-v} 560 {706-v} 614 Q {698-v} 625 {712-v} 626 '
        f'Q {743-v*.63} 633 {749-v*.38} 661 Q {753-v*.37} 669 {759-v*.32} 656 '
        f'C 787 588 765 502 758 414 C 739 150 614 -7 382 -9 C 166 -10 59 111 66 328 '
        f'L 76 480 Q 86 564 46 617 Z',center=(506,320))
    letters['ש']['anchors'].update(shin=(744-v*.42,750),sin=(89,750))
    return letters
