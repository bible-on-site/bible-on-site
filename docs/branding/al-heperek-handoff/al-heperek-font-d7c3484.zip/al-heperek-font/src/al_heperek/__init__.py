"""Original Al Heperek design construction, licensed under the repository LICENSE."""
