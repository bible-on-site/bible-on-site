"""Original lining figures using the SVG Hebrew cut's pen and flat returns.

The figure skeletons are authored here. Their verticals use resh's 32.4-unit
pen, flat horizontal bars use the 40.4-unit roof/floor, and rounded turns have
small optical compensation. No third-party font is a source.
"""

from .yehuda_hebrew import compile_outline, floor, pen_outline
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.svgLib.path import parse_path


def native_digits():
    digits = {}
    digits["0"] = [
        "M 63.5 -1.5 C 103 -1.5 121 19 121 67 C 121 116 103 135.1 63.5 135.1 "
        "C 24 135.1 6 114 6 67 C 6 20 24 -1.5 63.5 -1.5 Z",
        "M 63.5 38.9 C 46 38.9 38.4 49 38.4 67 C 38.4 85 46 94.7 63.5 94.7 "
        "C 81 94.7 88.6 85 88.6 67 C 88.6 49 81 38.9 63.5 38.9 Z",
    ]
    digits["1"] = [
        "M 31 54 L 12 30 57 0 89 0 87 133.6 54.6 133.6 54.6 42.5 Z",
        floor(15, 115),
    ]
    digits["2"] = [
        pen_outline("M 24 33 C 32 9 97 10 97 39 C 97 63 57 81 26 112", 35),
        floor(10, 118),
    ]
    digits["3"] = [
        pen_outline("M 22 20 C 45 6 97 10 97 36 C 97 52 79 63 57 63", 35),
        pen_outline("M 57 63 C 88 63 104 77 104 98 C 104 126 47 129 20 112", 35),
    ]
    digits["4"] = [
        pen_outline("M 83 12 L 23 86"),
        "M 76.8 0 L 109.2 0 109.2 133.6 76.8 133.6 Z",
        floor(10, 126, top=66.6, bottom=107),
    ]
    digits["5"] = [
        floor(16, 116, top=0, bottom=40.4),
        pen_outline("M 38 20 L 33 62"),
        pen_outline(
            "M 33 62 C 46 52 64 52 79 56 C 115 67 113 113 78 119 C 51 124 34 120 20 108",
            35,
        ),
    ]
    digits["6"] = [
        pen_outline(
            "M 99 21 C 83 7 60 13 47 35 C 27 65 25 98 46 113 "
            "C 65 128 102 116 102 90 C 102 64 68 59 47 78",
            35,
        )
    ]
    digits["7"] = [
        "M 20 -3 L 23 0 119 0 118.7 36 68.7 133.6 32.3 133.6 80 40.4 13 40.4 16 0 Z"
    ]
    digits["8"] = [
        "M 62.5 -1.5 C 96 -1.5 115 14 115 37 C 115 51 108 61 97 66 "
        "C 111 71 119 83 119 99 C 119 122 97 135.1 62.5 135.1 "
        "C 27 135.1 6 122 6 99 C 6 83 14 71 28 66 "
        "C 17 61 10 51 10 37 C 10 14 29 -1.5 62.5 -1.5 Z",
        "M 62.5 29 C 48 29 42.4 32 42.4 39 C 42.4 46 48 49 62.5 49 "
        "C 77 49 82.6 46 82.6 39 C 82.6 32 77 29 62.5 29 Z",
        "M 62.5 82 C 45 82 38.4 86 38.4 93.5 C 38.4 101 45 105 62.5 105 "
        "C 80 105 86.6 101 86.6 93.5 C 86.6 86 80 82 62.5 82 Z",
    ]
    nine = SVGPathPen(None)
    for contour in digits["6"]:
        parse_path(contour, TransformPen(nine, (-1, 0, 0, -1, 125, 133.6)))
    digits["9"] = [nine.getCommands()]
    return digits


def outlines(weight):
    return {
        ch: compile_outline(contours, weight)
        for ch, contours in native_digits().items()
    }
