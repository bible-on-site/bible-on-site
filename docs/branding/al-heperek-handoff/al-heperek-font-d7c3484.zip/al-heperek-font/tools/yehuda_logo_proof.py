"""Before/after proof of actual repository logos at their intended sizes."""

import argparse
import base64
from copy import deepcopy
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

from specimen import outlined

ROOT = Path(__file__).resolve().parents[1]
BEFORE = "3ae112beade68350ac753aba28174b4f10b6b367"
NS = "{http://www.w3.org/2000/svg}"
ET.register_namespace("", NS[1:-1])


def generate(repository):
    font = ROOT / "dist/ttf/AlHeperek-Regular.ttf"
    pieces = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="1440" height="1240" viewBox="0 0 1440 1240"><rect width="1440" height="1240" fill="#f2f5f9"/>'
    ]

    def label(value, x, y, size=22):
        pieces.append(outlined(font, value, x, y, size, "#435a79", direction="ltr"))

    def svg_asset(data, x, y, width, height, prefix):
        root = ET.fromstring(data)
        root.set("x", str(x))
        root.set("y", str(y))
        root.set("width", str(width))
        root.set("height", str(height))
        for el in root.iter():
            if el.get("id"):
                el.set("id", prefix + "-" + el.get("id"))
            for k, v in list(el.attrib.items()):
                el.set(k, v.replace("url(#", "url(#" + prefix + "-"))
        pieces.append(ET.tostring(root, encoding="unicode"))

    def load(relative, previous):
        if previous:
            return subprocess.check_output(
                ["git", "show", f"{BEFORE}:{relative}"], cwd=repository
            )
        return (repository / relative).read_bytes()

    for previous, x, title in [
        (True, 0, "Previous / 0.8"),
        (False, 720, "Yehuda / 0.9.2"),
    ]:
        label(title, x + 50, 55, 28)
        for name, y, dark in [
            ("header-logo.svg", 85, False),
            ("header-logo-reversed.svg", 320, True),
        ]:
            pieces.append(
                f'<rect x="{x + 35}" y="{y}" width="650" height="215" rx="14" fill="{"#3653a5" if dark else "#fff"}"/>'
            )
            svg_asset(
                load("web/bible-on-site/public/images/logos/" + name, previous),
                x + 55,
                y + 17,
                610,
                180,
                f"{x}-{name}",
            )
        label("App icon / 1024", x + 55, 575)
        svg_asset(
            load("web/bible-on-site/source-assets/logos/app-icon.svg", previous),
            x + 55,
            600,
            240,
            240,
            f"{x}-app",
        )
        label("Compact", x + 405, 575)
        header = ET.fromstring(
            load("web/bible-on-site/public/images/logos/header-logo.svg", previous)
        )
        compact = deepcopy(next(e for e in header if "viewBox" in e.attrib))
        svg_asset(ET.tostring(compact), x + 410, 590, 190, 265, f"{x}-compact")
        label("Favicons / actual size", x + 55, 910)
        for i, size in enumerate((16, 24, 32, 48)):
            center = x + 105 + i * 150
            data = load(
                f"web/bible-on-site/public/images/logos/favicon-{size}.png", previous
            )
            uri = "data:image/png;base64," + base64.b64encode(data).decode("ascii")
            pieces.append(
                f'<image href="{uri}" x="{center - size / 2}" y="{985 - size}" width="{size}" height="{size}"/>'
            )
            label(f"{size} px", center - 25, 1015, 17)
            pieces.append(
                f'<image href="{uri}" x="{center - 48}" y="1050" width="96" height="96" style="image-rendering:pixelated"/>'
            )
            label(f"{size} x {96 // size}", center - 25, 1182, 16)
    pieces.append("</svg>")
    target = ROOT / "specimens/yehuda-logos.svg"
    target.write_text("\n".join(pieces) + "\n", encoding="utf-8", newline="\n")
    print(target)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-checkout", type=Path, required=True)
    generate(parser.parse_args().source_checkout.resolve())
