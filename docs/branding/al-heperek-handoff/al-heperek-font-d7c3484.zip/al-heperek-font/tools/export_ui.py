"""Export the approved ss02 Hebrew cut as the default for native and web UI."""

import hashlib
import json
from pathlib import Path
import shutil

from fontTools.ttLib import TTFont

ROOT = Path(__file__).resolve().parents[1]
WEIGHTS = {"Regular": 400, "SemiBold": 600, "Bold": 700}


def export_ui(
    *,
    cut="ss02",
    family="Al Heperek Font UI",
    stem="AlHeperekUI",
    directory="ui",
    extra_codepoints=(),
) -> None:
    output = ROOT / "dist" / directory
    version = json.loads((ROOT / "dist" / "manifest.json").read_text(encoding="utf-8"))[
        "version"
    ]
    files = []
    for style, weight in WEIGHTS.items():
        source = ROOT / "dist" / "ttf" / f"AlHeperek-{style}.ttf"
        font = TTFont(source, recalcTimestamp=False)
        # These glyphs already carry their fitted GPOS anchors and kerning.
        # Point cmap at the requested cut so platforms need no stylistic-set
        # support. Defaults continue to export the approved ss02 UI face.
        for table in font["cmap"].tables:
            if table.isUnicode():
                for codepoint in (*range(0x05D0, 0x05EB), *extra_codepoints):
                    original = table.cmap.get(codepoint)
                    if original is not None:
                        alternate = f"uni{codepoint:04X}.{cut}"
                        if alternate not in font.getGlyphOrder():
                            raise ValueError(f"Missing requested glyph {alternate}")
                        table.cmap[codepoint] = alternate
        names = font["name"]
        replacements = {
            1: family,
            3: f"DoradSoft:{stem}-{style}:{version}",
            4: f"{family} {style}",
            6: f"{stem}-{style}",
            16: family,
            17: style,
        }
        for record in names.names:
            if record.nameID in replacements:
                record.string = replacements[record.nameID].encode(record.getEncoding())
        for format_name in ("ttf", "woff2"):
            destination = output / format_name / f"{stem}-{style}.{format_name}"
            destination.parent.mkdir(parents=True, exist_ok=True)
            font.flavor = None if format_name == "ttf" else "woff2"
            font.save(destination)
            files.append(
                {
                    "file": destination.relative_to(ROOT).as_posix(),
                    "weight": weight,
                    "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
                    "sourceSha256": hashlib.sha256(source.read_bytes()).hexdigest(),
                }
            )
    shutil.copyfile(ROOT / "LICENSE", output / "LICENSE.txt")
    manifest = {
        "family": family,
        "version": version,
        "defaultHebrewCut": cut,
        "cantillation": False,
        "files": files,
    }
    if extra_codepoints:
        manifest["additionalMappedCodepoints"] = [
            f"U+{cp:04X}" for cp in extra_codepoints
        ]
    (output / "manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8", newline="\n"
    )


if __name__ == "__main__":
    export_ui()
