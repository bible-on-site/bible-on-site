"""Draw the comparison sheet from the shaped fonts and their compiled outlines."""
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen


def generate_motif_proof(destination, fonts, outlined, version):
    ink, blue = '#1B2840', '#255DDD'
    body = ['<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="1094" viewBox="0 0 1200 1094" role="img"><title>על הפרק — מוטיבים וקווי השורה</title><rect width="1200" height="1094" fill="#FAF8F2"/>']
    def he(value, x, y, size, style='Regular', color=ink, poster=False):
        body.append(outlined(fonts[style], value, x, y, size, color, 'right', 'rtl', poster))

    def rule(y):
        body.append(f'<path d="M52 {y}H1148" stroke="#CACBC4"/>')

    he('אות לקריאה', 1138, 59, 28)
    he('אות לכרזה', 548, 59, 28)
    he('על הפרק', 1145, 184, 124, 'Bold')
    he('על הפרק', 555, 184, 124, 'Bold', poster=True)
    rule(246)
    he('החלק החוזר מסומן בכחול', 1138, 296, 29, 'SemiBold')
    font = TTFont(fonts['SemiBold'])
    glyphs = font.getGlyphSet()
    cmap = font.getBestCmap()
    # Colour a region of the original outline. Each accent is clipped to
    # the actual glyph, including its counters and any local optical change.
    def group(title, letters, right, y, step, region):
        he(title, right, y, 22)
        for index, letter in enumerate(letters):
            name = cmap[ord(letter)]
            glyph = glyphs[name]
            path = SVGPathPen(glyphs)
            glyph.draw(path)
            d = path.getCommands()
            shape = font['glyf'][name]
            bx, by, width, height = region(shape.xMin, shape.xMax, letter)
            glyph_id = f'clip{y}_{index}_{ord(letter)}'
            scale = .092
            x = right - index*step - (shape.xMin + shape.xMax)*scale/2 - 36
            body.append(f'<g transform="translate({x:.2f} {y+82}) scale({scale} {-scale})"><defs><clipPath id="{glyph_id}"><rect x="{bx}" y="{by}" width="{width}" height="{height}"/></clipPath></defs><path fill="{ink}" d="{d}"/><path fill="{blue}" clip-path="url(#{glyph_id})" d="{d}"/></g>')

    group('הכתף הימנית', 'ורחךףהבת', 1138, 349, 141,
          lambda left, right, ch: (max(left, right-215), 482, 229, 220))
    rule(469)
    group('הסיבוב התחתון', 'פסט', 1138, 515, 136,
          lambda left, right, ch: (right-239, -25, 250, 250))
    group('הכניסה משמאל', 'טש', 550, 515, 135,
          lambda left, right, ch: (left-5, 440, 175, 250))
    rule(627)
    group('מהגג אל האלכסון', 'קל', 1138, 675, 136,
          lambda left, right, ch: (right-184, 310, 200, 353))
    group('הזרוע הימנית', 'אצץ', 550, 675, 135,
          lambda left, right, ch: (right-230, 413, 238, 267))
    rule(803)
    he('קו הגג וקו הבסיס', 1138, 852, 25)
    baseline, size = 971, 112
    for guide in (baseline - size * .65, baseline):
        body.append(f'<path d="M52 {guide}H1148" stroke="#9CAEB9"/>')
    for i, letter in enumerate('אלךןףץקח'):
        body.append(outlined(fonts['SemiBold'], letter, 1082-i*138, baseline,
                             size, ink, 'center', 'rtl'))
    rule(1011)
    he('אלול · לקרוא בקול · ארץ', 1138, 1060, 34)
    body.append(outlined(fonts['Regular'], f'Al Heperek    /    {version}', 56, 1058, 21, ink))
    body.append('</svg>')
    (destination / 'motifs.svg').write_text(''.join(body), encoding='utf-8')
