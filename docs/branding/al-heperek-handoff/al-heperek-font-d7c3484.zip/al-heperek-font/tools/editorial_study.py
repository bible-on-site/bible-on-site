"""Build an isolated contour study without overwriting the canonical UFOs."""
from pathlib import Path
import base64
import html
import json
import os
import subprocess
import sys
import tempfile

from ufoLib2 import Font

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from al_heperek.editorial_hebrew import hebrew_glyphs
from al_heperek.geometry import draw_spec


def build_study():
    destination = ROOT / 'build/editorial-study'
    destination.mkdir(parents=True, exist_ok=True)
    temporary = destination / 'source-tmp'
    temporary.mkdir(exist_ok=True)
    tempfile.tempdir = str(temporary)
    metrics = json.loads((ROOT / 'sources/metrics.json').read_text(encoding='utf-8'))
    faces = []
    for style in metrics['styles']:
        font = Font.open(ROOT / 'sources' / f"AlHeperek-{style['name']}.ufo")
        specs = hebrew_glyphs(style['stroke'])
        latin_module = ROOT / 'src/al_heperek/editorial_latin.py'
        if latin_module.exists():
            from al_heperek.editorial_latin import latin_glyphs
            specs = latin_glyphs(style['stroke']) | specs
        for character, spec in specs.items():
            name = 'space' if character == ' ' else f'uni{ord(character):04X}'
            glyph = font[name]
            glyph.clearContours()
            draw_spec(glyph, spec, style['stroke'], character)
        font.info.familyName = 'Al Heperek Editorial Study'
        font.info.openTypeNamePreferredFamilyName = font.info.familyName
        source = destination / f"AlHeperekEditorial-{style['name']}.ufo"
        font.save(source, overwrite=True)
        output = destination / f"AlHeperekEditorial-{style['name']}.ttf"
        env = os.environ | {'SOURCE_DATE_EPOCH': '1794700800'}
        subprocess.run([sys.executable, '-m', 'fontmake', '-u', str(source), '-o', 'ttf', '--output-path', str(output), '--overlaps-backend', 'pathops', '--validate-ufo', '--verbose', 'WARNING'], cwd=ROOT, env=env, check=True)
        encoded = base64.b64encode(output.read_bytes()).decode('ascii')
        faces.append(f"@font-face{{font-family:Study;src:url(data:font/ttf;base64,{encoded}) format('truetype');font-weight:{style['weight']};}}")
    alphabet = 'אבגדהוזחטיכלמנסעפצקרשת ךםןףץ'
    paragraph = 'לימוד יומי מחבר אותנו אל המקורות, אל השפה ואל הסיפור שלנו. בכל יום נפתח פרק חדש, נקרא בתשומת לב ונמצא בו משמעות. הקריאה נעימה כשהאותיות מאוזנות, כשהרווחים טבעיים וכשהמילים זורמות יחד.'
    cards = []
    for weight in (400, 600, 700):
        cards.append(f'<section><p class="label">{weight}</p><p class="brand" style="font-weight:{weight}">על הפרק</p><p class="alphabet" style="font-weight:{weight}">{alphabet}</p><p class="paragraph" style="font-weight:{weight}">{paragraph}</p></section>')
    page = f'''<!doctype html><html lang="he" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Al Heperek - Editorial contour study</title><style>{''.join(faces)}*{{box-sizing:border-box}}body{{margin:0;background:#f4f3ee;color:#172b42;font:16px/1.5 Arial,sans-serif}}main{{max-width:1200px;margin:auto;padding:36px}}header{{border-bottom:1px solid #c7cbc8;padding-bottom:18px}}h1{{font-size:24px}}.label{{font:14px Arial,sans-serif;color:#656e76;letter-spacing:1px}}section{{padding:20px 0 30px;border-bottom:1px solid #c7cbc8}}.brand,.alphabet,.paragraph,.mixed{{font-family:Study}}.brand{{font-size:116px;line-height:1.05;margin:16px 0 28px}}.alphabet{{font-size:38px;letter-spacing:1px;margin:12px 0 24px}}.paragraph{{font-size:22px;line-height:1.75;max-width:920px;margin:0}}.mixed{{font-size:28px}}textarea{{font-family:Study;font-weight:600;font-size:48px;width:100%;min-height:180px;padding:24px;border:1px solid #bcc5c9;background:#fff;color:#172b42;line-height:1.5}}@media(max-width:650px){{main{{padding:20px}}.brand{{font-size:80px}}.alphabet{{font-size:30px}}}}</style><main><header><h1>Al Heperek - מחקר צורה חדש</h1><p>בדיקת אותיות חדשות, ריווח, קו בסיס וצבע טקסט. העבודה עדיין טעונה ביקורת ואישור.</p></header>{''.join(cards)}<section><p class="label">טקסט חופשי</p><textarea spellcheck="false">על הפרק\nלימוד יומי בתנ"ך</textarea><p class="mixed" dir="ltr">Al Heperek / Modern Hebrew / 0123456789</p></section></main></html>'''
    (destination / 'index.html').write_text(page, encoding='utf-8')
    print(f'Contour study: {destination / "index.html"}')


if __name__ == '__main__':
    build_study()
