"""Low-node, explicitly traced refinements of A01 and C01.

Every glyph is one authored perimeter. No stroke expansion, Boolean union,
filleting or automatic simplification contributes to the source contours.
The same fork and small lifted head are traced into alef, tsadi and final
tsadi; final tsadi is a real companion drawing for each tsadi proposal.
"""

import json
from pathlib import Path
import re

import pathops
from fontTools.svgLib.path import parse_path

ROOT = Path(__file__).resolve().parents[1]

# name, actual construction distinction, fork displacement, join displacement,
# fork curve tension, diagonal heel, lower-left stance, floor length, return.
# Each is a restrained reworking of the selected flowing skeleton, not a new
# unrelated family and not a transformation of a finished outline.
PROFILES = [
    ("רצף מאוזן", "מהלך רציף ומאוזן סביב השלד הזורם שנבחר.", 0, 0, 0, 0, 0, 0, 0),
    ("מפגש גבוה", "המפגש עולה מעט והחלל התחתון נשאר פתוח.", 0, -5, -1, 1, 0, 0, -1),
    ("מפגש נמוך", "המפגש יורד מעט והענף מתארך בקשת אחת.", 1, 5, 1, 1, -1, 1, 1),
    ("ענף פתוח", "הענף הימני מתרחק ומרחיב את החלל שמעל המפגש.", 6, 0, 2, 1, 0, 1, 0),
    ("ענף קרוב", "הענף נאסף פנימה בלי לסגור את החלל הפנימי.", -3, 0, -1, -1, 1, -1, 0),
    ("מתיחה רכה", "התנועה לרוחב מעט ארוכה יותר והחיבור נשאר רך.", 3, 1, 2, 5, -1, 4, 1),
    ("רגל זקופה", "המשיכה התחתונה זקופה יותר מול הענף הזורם.", 0, -1, 0, -2, 4, -2, -1),
    ("רגל נפתחת", "היציאה התחתונה נפתחת שמאלה בקשת רציפה.", 1, 1, 1, 2, -4, 2, 1),
    (
        "חלל מתוח",
        "החלל העליון מתוח מעט והענף עולה בצורה נקייה.",
        2,
        -3,
        -2,
        3,
        -1,
        2,
        -1,
    ),
    ("חלל עגול", "הענף מקיף חלל עגול יותר עם אותה מתיחת קו.", 3, 2, 4, 0, 1, 0, 1),
    ("מרכז פתוח", "המרכז משאיר מעט יותר אוויר בין המשיכות.", 4, -2, 1, 4, -2, 3, 0),
    ("מרכז אסוף", "המרכז נאסף בעדינות ושומר על משיכה רחבה.", -2, 3, -1, -3, 2, -3, 0),
    ("קצב רגוע", "הקימורים נפתחים לאט יותר בלי שינוי חד בכיוון.", 1, -1, 3, 2, 1, 1, 2),
    ("קצב קדימה", "הענף נוטה מעט קדימה ומאזן יציאה ארוכה.", 4, 3, -1, 4, -1, 3, 1),
    ("קשת גבוהה", "הקשת הימנית גבוהה ומפנה מקום למפגש שקט.", 1, -6, 2, 0, 1, 0, -2),
    ("קשת נמוכה", "קשת נמוכה ורחבה פוגשת את הגוף ברכות.", 4, 6, 3, 3, -1, 2, 2),
    ("חיבור עדין", "פנייה קטנה יותר במפגש משאירה רצף טבעי.", -1, -2, 1, -1, 2, -1, -1),
    ("תנועה רחבה", "מהלך רחב מתון עם בסיס פתוח וענף נדיב.", 5, 1, 2, 6, -3, 5, 0),
    (
        "תנועה זקופה",
        "הגוף מתרומם מעט מול הענף ומפחית את האלכסון.",
        -2,
        -4,
        0,
        -4,
        3,
        -3,
        -1,
    ),
    ("איזון זורם", "חלל פתוח וקשת רכה מסיימים את אותה תנועה.", 2, 2, 3, 1, -2, 2, 1),
]


def n(value):
    return f"{value:.3f}".rstrip("0").rstrip(".") or "0"


def command(verb, *values):
    return verb + " ".join(n(v) for v in values)


def head_and_fork(profile):
    """A common continuous perimeter from the left head through the right arm.

    Quadratic counter turns match the adjacent cubic tangents exactly. The
    small cut corners on the head are intentional, as in the source lettering.
    """
    _, _, dx, jy, tension, _, _, _, _ = profile
    jx = dx * 0.22
    inner_x, inner_y = 78 + jx, 73 + jy
    right_x, right_y = 100 + jx, 88 + jy
    result = [
        "M24.2 -5.8 L27.6 -2.2 C29.2 -.8 31.5 0 34.2 0 L39.2 0",
        "C41.4 0 42.9 1.5 43.9 5.4 C45.9 13.2 49.9 36.9 50.8 40.4",
        command("C", 55.3, 57.9, inner_x - 12, inner_y - 12, inner_x, inner_y),
        command("Q", inner_x + 3, inner_y + 3, inner_x + 6, inner_y - 1),
        command("C", inner_x + 18, inner_y - 17, 104 + dx + tension, 41, 102 + dx, 32),
        command("C", 101 + dx - tension * 0.5, 27.5, 96 + dx, 24, 88.5 + dx, 20),
        command("L", 77.4 + dx, 14.08),
        command("C", 80.8 + dx, 6, 85 + dx, -1, 90 + dx, -5.8),
        command("C", 109.5 + dx, 2.1, 121.5 + dx, 3.2, 128 + dx, 19),
        command("C", 134.5 + dx, 34.8, right_x + 17, right_y - 20, right_x, right_y),
        command("Q", right_x - 3.4, right_y + 4, right_x, right_y + 7.2),
    ]
    return result, (right_x, right_y + 7.2)


def head_return():
    return "C13.2 36.9 10 32.2 10 28.4 C10 18.2 12.3 8.6 14.8 -3.6 Z"


def alef(profile):
    _, _, _, jy, _, heel, stance, _, _ = profile
    path, (x, y) = head_and_fork(profile)
    lower_x = 28 + stance * 0.3
    lower_qx = lower_x + 0.15 * (20 - stance * 0.1)
    lower_end_x = lower_x + 0.8
    lower_control_x = lower_end_x + (lower_end_x - lower_qx)
    path.extend(
        [
            command("C", x + 10.2, y + 9.6, 121.2 + heel, 114.4, 131 + heel, 124),
            command("L", 112 + heel, 136.5),
            command("L", 103 + heel, 136.5),
            command(
                "C",
                91 + heel * 0.7,
                118,
                76 + stance * 0.25,
                99 + jy * 0.2,
                64 + stance * 0.25,
                88 + jy * 0.2,
            ),
            command(
                "Q",
                61 + stance * 0.25,
                85.25 + jy * 0.2,
                58 + stance * 0.25,
                88.25 + jy * 0.2,
            ),
            command(
                "C",
                43 + stance * 0.25,
                103.25 + jy * 0.2,
                33 + stance,
                114,
                33 + stance,
                130,
            ),
            command("L", 9 + stance, 136.5),
            command("L", stance, 136.5),
            command("C", stance, 109, 8 + stance * 0.4, 81, lower_x, 66),
            command("Q", lower_qx, 63.75, lower_end_x, 61.55),
            command("C", lower_control_x, 59.35, 19.8, 56.7, 14.3, 40.2),
            head_return(),
        ]
    )
    return " ".join(path)


def tsadi(profile, final=False):
    _, _, _, jy, _, heel, _, floor, return_y = profile
    path, (x, y) = head_and_fork(profile)
    if final:
        foot = heel * 0.35
        path.extend(
            [
                command("C", x + 10.2, y + 9.6, 101 + foot, 148, 98 + foot, 168.4),
                command("L", 72.6 + foot, 173.2),
                command("L", 62.4 + foot, 173.2),
                command("C", 64 + foot, 139, 63 + foot, 120, 55 + foot, 106),
                command("C", 47 + foot, 92, 19.8, 56.7, 14.3, 40.2),
                head_return(),
            ]
        )
    else:
        right = 125 + floor
        inner = 70 + floor * 0.7
        return_top = 96.6 + return_y
        path.extend(
            [
                command("C", x + 10.2, y + 9.6, right + 3, 116, right + 3, 122),
                command("C", right + 3, 128, right + 2, 133.6, right - 1, 133.6),
                command("L", floor * 0.25, 133.6),
                command("L", 1.9 + floor * 0.25, 95.8 + return_y),
                command(
                    "C",
                    24 + floor * 0.25,
                    97.8 + return_y,
                    inner - 14,
                    return_top,
                    inner - 2,
                    return_top,
                ),
                command("Q", inner + 6, return_top, inner, return_top - 4),
                command("C", inner - 18, return_top - 16, 19.8, 56.7, 14.3, 40.2),
                head_return(),
            ]
        )
    return " ".join(path)


def validate(raw, maximum):
    path = pathops.Path()
    parse_path(raw, path.getPen())
    count = len(re.findall(r"[MLCQ]", raw))
    assert count <= maximum, count
    assert len(list(path.contours)) == 1
    simplified = pathops.simplify(path, clockwise=False)
    assert len(list(simplified.contours)) == 1
    assert abs(abs(path.area) - abs(simplified.area)) < 0.1, "Self-crossing contour"
    assert abs(path.area) > 5000
    return count


def proof(letters):
    out = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="1350" height="2150" viewBox="0 0 1350 2150">',
        '<rect width="1350" height="2150" fill="#f3f6fa"/>',
    ]
    for section, ch in enumerate(("א", "צ", "ץ")):
        for index, entry in enumerate(letters["צ" if ch == "ץ" else ch]):
            x = 15 + index % 5 * 267
            y = 15 + section * 710 + index // 5 * 174
            raw = entry["companion"]["paths"][0] if ch == "ץ" else entry["paths"][0]
            out.append(
                f'<rect x="{x}" y="{y}" width="250" height="160" rx="10" fill="white"/>'
            )
            out.append(
                f'<text x="{x + 14}" y="{y + 24}" font-family="sans-serif" font-size="16" fill="#63738b">{entry["id"]}{" / final" if ch == "ץ" else ""}</text>'
            )
            scale = 0.64 if ch == "ץ" else 0.89
            out.append(
                f'<path d="{raw}" fill="#193e76" transform="translate({x + 55} {y + 32}) scale({scale})"/>'
            )
    out.append("</svg>")
    target = ROOT / "build/refine-alef-tsadi.svg"
    target.parent.mkdir(exist_ok=True)
    target.write_text("\n".join(out) + "\n", encoding="utf-8", newline="\n")


def generate():
    letters = {"א": [], "צ": []}
    for index, profile in enumerate(PROFILES, 21):
        name, note, *_ = profile
        for ch, prefix, raw in (("א", "A", alef(profile)), ("צ", "C", tsadi(profile))):
            nodes = validate(raw, 35 if ch == "א" else 26)
            corners = [[90 + profile[2], -5.8]]
            entry = {
                "id": f"{prefix}{index:02}",
                "name": name,
                "note": note,
                "paths": [raw],
                "base": "A01" if ch == "א" else "C01",
                "onCurvePoints": nodes,
                "corners": corners,
            }
            if ch == "צ":
                companion = tsadi(profile, final=True)
                entry["companion"] = {
                    "character": "ץ",
                    "paths": [companion],
                    "onCurvePoints": validate(companion, 26),
                    "corners": corners,
                }
            letters[ch].append(entry)
    for entries in letters.values():
        assert len(entries) == 20
        assert len({entry["paths"][0] for entry in entries}) == 20
    payload = {
        "basedOn": {"א": "A01", "צ": "C01"},
        "method": "Individually traced low-node continuous perimeters; no authoring Booleans or stroke expansion",
        "basisCompanion": {"character": "ץ", "paths": [tsadi(PROFILES[0], final=True)]},
        "letters": letters,
    }
    target = ROOT / "sources/yehuda/refinements/alef-tsadi.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    proof(letters)
    print("Authored 20 alef + 20 tsadi + 20 matched final-tsadi low-node refinements")


if __name__ == "__main__":
    generate()
