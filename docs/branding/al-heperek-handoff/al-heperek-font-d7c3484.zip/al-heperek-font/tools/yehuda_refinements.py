"""Review low-node refinements; preserve authored Bézier geometry exactly."""

import hashlib
import html
import json
import math
from pathlib import Path
import sys

from fontTools.pens.boundsPen import BoundsPen
from fontTools.pens.recordingPen import RecordingPen
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.svgLib.path import parse_path
from fontTools.ttLib import TTFont
import pathops
import uharfbuzz as hb

from specimen import outlined

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
FONT = ROOT / "dist/ttf/AlHeperek-Bold.ttf"
OUTPUT = ROOT / "specimens/refinements"
ALPHABET = "אבגדהוזחטיכלמנסעפצקרשתךםןףץ"
DIGITS = "0123456789"
FULL_SAMPLE = ALPHABET + " " + DIGITS
BASES = {"א": "A01", "ע": "E09", "ט": "T07", "צ": "C01", "ש": "S03"}
SLUGS = {"א": "alef", "ע": "ayin", "ט": "tet", "צ": "tsadi", "ש": "shin"}
WORDS = {"א": "אוצר", "ע": "עולם", "ט": "טוב", "צ": "צדק", "ש": "שלום"}
SAMPLE_RUNS = (ALPHABET[:11], ALPHABET[11:22], ALPHABET[22:], DIGITS)


def path_bounds(paths):
    pen = BoundsPen(None)
    for raw in paths:
        parse_path(raw, pen)
    assert pen.bounds and all(math.isfinite(v) for v in pen.bounds)
    return list(pen.bounds)


def geometry_metrics(paths):
    """Count the actual authored anchors/controls and inspect cubic tangents."""
    anchors, controls, counts, joins = [], [], {}, []
    contour = pathops.Path()
    for raw in paths:
        pen = RecordingPen()
        parse_path(raw, pen)
        parse_path(raw, contour.getPen())
        cursor = None
        previous = None
        first = None
        for operation, points in pen.value:
            counts[operation] = counts.get(operation, 0) + 1
            if operation == "moveTo":
                first = cursor = points[0]
                anchors.append(cursor)
                previous = None
            elif operation in ("lineTo", "curveTo", "qCurveTo"):
                assert cursor is not None
                end = points[-1]
                if operation in ("curveTo", "qCurveTo"):
                    assert len(points) == (3 if operation == "curveTo" else 2)
                    outgoing = (points[0][0] - cursor[0], points[0][1] - cursor[1])
                    if previous is not None and previous[0] in ("curveTo", "qCurveTo"):
                        incoming = previous[1]
                        if (
                            math.hypot(*incoming) > 1e-7
                            and math.hypot(*outgoing) > 1e-7
                        ):
                            angle = abs(
                                math.degrees(
                                    math.atan2(
                                        incoming[0] * outgoing[1]
                                        - incoming[1] * outgoing[0],
                                        incoming[0] * outgoing[0]
                                        + incoming[1] * outgoing[1],
                                    )
                                )
                            )
                            if angle > 0.05:
                                joins.append(
                                    {"point": list(cursor), "degrees": round(angle, 2)}
                                )
                    previous = (
                        operation,
                        (end[0] - points[-2][0], end[1] - points[-2][1]),
                    )
                else:
                    previous = (operation, (end[0] - cursor[0], end[1] - cursor[1]))
                controls.extend(points[:-1])
                anchors.append(end)
                cursor = end
            elif operation == "closePath":
                if anchors[-1] == first:
                    anchors.pop()
            else:
                raise AssertionError(operation)
    # This is a read-only validity check. Never serialize this boolean result.
    checked = pathops.simplify(contour, clockwise=False)
    assert abs(checked.area) > 2000
    assert len(list(checked.contours)) == 1, (
        "A proposal must be a connected open-counter letter"
    )
    return {
        "anchors": len(anchors),
        "controls": len(controls),
        "points": [list(p) for p in anchors],
        "operations": counts,
        "curveJoinAngles": joins,
        "areaDifference": abs(abs(contour.area) - abs(checked.area)),
    }


def compile_native(entry, ch, *, strict=True):
    """A single affine transform; no union, offset, fitting, rounding or resampling."""
    from al_heperek.hebrew_spacing import READING_BEARINGS

    paths = entry["paths"]
    assert len(paths) == 1 and paths[0].strip().upper().endswith("Z")
    metrics = geometry_metrics(paths)
    if strict:
        assert metrics["areaDifference"] < 0.1, (entry["id"], "self-crossing perimeter")
        assert metrics["anchors"] <= (32 if ch == "א" else 30), (
            entry["id"],
            metrics["anchors"],
        )
        corners = entry.get("corners", [])
        unexpected = [
            join
            for join in metrics["curveJoinAngles"]
            if not any(math.dist(join["point"], p) < 0.01 for p in corners)
        ]
        assert not unexpected, (entry["id"], unexpected)
    x_min, y_min, x_max, y_max = path_bounds(paths)
    assert y_min > -25 and y_max < (185 if ch == "ץ" else 148), (
        entry["id"],
        y_min,
        y_max,
    )
    left, right = READING_BEARINGS[ch]
    scale = 650 / 133.6
    dx = left - x_min * scale
    pen = SVGPathPen(None)
    for raw in paths:
        parse_path(raw, TransformPen(pen, (scale, 0, 0, -scale, dx, 650)))
    result = {
        "id": entry["id"],
        "name": entry.get("name", entry["id"]),
        "note": entry.get("note", ""),
        "base": entry.get("base"),
        "path": pen.getCommands(),
        "advance": (x_max - x_min) * scale + left + right,
        "bounds": [
            left,
            650 - y_max * scale,
            (x_max - x_min) * scale + left,
            650 - y_min * scale,
        ],
        "metrics": metrics,
    }
    result["anchors"] = [
        [x * scale + dx, 650 - y * scale] for x, y in metrics["points"]
    ]
    if "companion" in entry:
        companion = entry["companion"]
        assert companion["character"] == "ץ"
        result["companion"] = compile_native(
            companion | {"id": entry["id"] + "-final"}, "ץ"
        )
    return result


def font_glyphs(font):
    glyphs = font.getGlyphSet()
    result = {}
    for ch in " " + ALPHABET + DIGITS:
        name = "space" if ch == " " else f"uni{ord(ch):04X}.ss03"
        pen = SVGPathPen(glyphs)
        glyphs[name].draw(pen)
        raw = pen.getCommands()
        result[ch] = {"path": raw, "advance": glyphs[name].width}
    return result


def shape_runs(font, glyphs):
    shaper = hb.Font(hb.Face(FONT.read_bytes()))
    hb.ot_font_set_funcs(shaper)
    order = font.getGlyphOrder()
    result = {}
    for text in sorted(set(SAMPLE_RUNS) | set(WORDS.values()) | {ALPHABET}):
        buffer = hb.Buffer()
        buffer.add_str(text)
        buffer.direction = "ltr" if text.isascii() else "rtl"
        buffer.script = "Latn" if text.isascii() else "Hebr"
        hb.shape(shaper, buffer, {"ss03": True, "kern": True})
        parts = []
        for info, position in zip(buffer.glyph_infos, buffer.glyph_positions):
            ch = text[info.cluster]
            assert order[info.codepoint] == f"uni{ord(ch):04X}.ss03"
            parts.append(
                {
                    "ch": ch,
                    "kern": position.x_advance - glyphs[ch]["advance"],
                    "x": position.x_offset,
                    "y": position.y_offset,
                }
            )
        result[text] = parts
    # Preserve the full run's kerning across responsive wrap opportunities.
    for chunk in SAMPLE_RUNS[:-1]:
        characters = set(chunk)
        result[chunk] = [part for part in result[ALPHABET] if part["ch"] in characters]
    return result


def context(basis, ch, entry):
    result = basis | {ch: entry}
    if entry.get("companion"):
        result["ץ"] = entry["companion"]
    return result


def run_paths(text, glyphs, overrides, runs, size, right, baseline, active=None):
    cursor = 0
    paths = []
    for p in runs[text]:
        glyph = overrides.get(p["ch"], glyphs[p["ch"]])
        color = (
            "#245edb"
            if p["ch"] == active or (active == "צ" and p["ch"] == "ץ")
            else "#193e76"
        )
        paths.append(
            f'<path d="{glyph["path"]}" fill="{color}" transform="translate({cursor + p["x"]} {-p["y"]}) scale(1 -1)"/>'
        )
        cursor += glyph["advance"] + p["kern"]
    scale = size / 1000
    return (
        f'<g transform="translate({right - cursor * scale} {baseline}) scale({scale})" fill="#193e76">'
        + "".join(paths)
        + "</g>"
    )


def specimen_sheet(ch, entries, glyphs, basis, runs):
    row = 205
    height = 105 + len(entries) * row
    out = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="1500" height="{height}" viewBox="0 0 1500 {height}" role="img">',
        f"<title>{html.escape(ch)} - 20 low-node refinements, full alphabet and figures in every row</title>",
        f'<rect width="1500" height="{height}" fill="#f4f6fa"/>',
        outlined(
            FONT, f"{SLUGS[ch].upper()} / {BASES[ch]} / 20", 35, 61, 29, "#193e76"
        ),
    ]
    for index, entry in enumerate(entries):
        top = 90 + index * row
        out.append(
            f'<rect x="25" y="{top}" width="1450" height="190" rx="12" fill="white"/>'
        )
        out.append(outlined(FONT, entry["id"], 47, top + 30, 20, "#63738b"))
        for glyph, cx in ((entry, 130), (entry.get("companion"), 264)):
            if glyph:
                left, _, right, _ = glyph["bounds"]
                scale = 0.14
                out.append(
                    f'<path d="{glyph["path"]}" transform="translate({cx - (left + right) * scale / 2} {top + 133}) scale({scale} {-scale})" fill="#245edb"/>'
                )
        overrides = context(basis, ch, entry)
        out.append(run_paths(ALPHABET, glyphs, overrides, runs, 38, 1435, top + 78, ch))
        out.append(run_paths(DIGITS, glyphs, overrides, runs, 38, 1435, top + 135, ch))
        out.append(
            outlined(
                FONT,
                entry["name"],
                1435,
                top + 172,
                21,
                "#63738b",
                "right",
                "rtl",
                feature="ss03",
            )
        )
    out.append("</svg>")
    (OUTPUT / f"{SLUGS[ch]}.svg").write_text(
        "\n".join(out) + "\n", encoding="utf-8", newline="\n"
    )


def before_after(letters, basis, glyphs, runs):
    out = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="1500" height="940" viewBox="0 0 1500 940" role="img">',
        "<title>הכיוונים שסומנו ודוגמה מכל קבוצת חלופות חדשה</title>",
        '<rect width="1500" height="940" fill="#f4f6fa"/>',
    ]
    before = dict(basis)
    after = {ch: letters[ch]["entries"][0] for ch in BASES}
    after["ץ"] = after["צ"]["companion"]
    for caption, row, selected in (
        ("הכיוונים שסימנת", 0, before),
        ("סבב חדש - דוגמה אחת מכל קבוצה", 465, after),
    ):
        out.append(
            outlined(
                FONT,
                caption,
                1440,
                row + 55,
                32,
                "#193e76",
                "right",
                "rtl",
                feature="ss03",
            )
        )
        for index, ch in enumerate(BASES):
            glyph = selected[ch]
            cx = 1325 - index * 285
            out.append(
                outlined(FONT, glyph["id"], cx, row + 107, 23, "#63738b", "center")
            )
            forms = ((glyph, cx),)
            if ch == "צ":
                final = glyph.get("companion", selected["ץ"])
                forms = ((glyph, cx + 54), (final, cx - 54))
            for form, center in forms:
                left, _, right, _ = form["bounds"]
                out.append(
                    f'<path d="{form["path"]}" transform="translate({center - (left + right) * 0.16 / 2} {row + 240}) scale(.16 -.16)" fill="#193e76"/>'
                )
            out.append(
                outlined(
                    FONT,
                    str(glyph["metrics"]["anchors"]),
                    cx,
                    row + 302,
                    24,
                    "#63738b",
                    "center",
                )
            )
        out.append(run_paths(ALPHABET, glyphs, selected, runs, 43, 1440, row + 367))
        out.append(run_paths(DIGITS, glyphs, selected, runs, 43, 1440, row + 420))
    out.append('<path d="M35 450H1465" stroke="#d5deea"/>')
    out.append(
        outlined(
            FONT,
            "המספרים מציינים עוגנים. גם לנקודת המוצא הותאמה ץ.",
            750,
            922,
            19,
            "#63738b",
            "center",
            "rtl",
            feature="ss03",
        )
    )
    out.append("</svg>")
    (OUTPUT / "before-after.svg").write_text(
        "\n".join(out) + "\n", encoding="utf-8", newline="\n"
    )


def generate():
    OUTPUT.mkdir(parents=True, exist_ok=True)
    raw, basis = {}, {}
    for source in sorted((ROOT / "sources/yehuda/alternatives").glob("*.json")):
        for ch, entries in json.loads(source.read_text(encoding="utf-8"))[
            "letters"
        ].items():
            entry = next(e for e in entries if e["id"] == BASES[ch])
            basis[ch] = compile_native(entry, ch, strict=False)
    final_basis = None
    for source in sorted((ROOT / "sources/yehuda/refinements").glob("*.json")):
        content = json.loads(source.read_text(encoding="utf-8"))
        for ch, entries in content["letters"].items():
            assert ch not in raw
            raw[ch] = entries
        if content.get("basisCompanion"):
            final_basis = content["basisCompanion"]
    assert final_basis is not None
    basis["ץ"] = compile_native(final_basis | {"id": "C01-final"}, "ץ", strict=False)
    assert set(raw) == set(BASES)
    font = TTFont(FONT)
    glyphs = font_glyphs(font)
    runs = shape_runs(font, glyphs)
    letters, audit = {}, {}
    for ch in BASES:
        entries = raw[ch]
        prefix = BASES[ch][0]
        assert [e["id"] for e in entries] == [f"{prefix}{i}" for i in range(21, 41)]
        assert all(e.get("base") == BASES[ch] for e in entries)
        compiled = [compile_native(e, ch) for e in entries]
        hashes = [hashlib.sha256(e["path"].encode()).hexdigest() for e in compiled]
        assert len(set(hashes)) == 20
        if ch == "צ":
            assert all(e.get("companion") for e in compiled)
        letters[ch] = {
            "base": BASES[ch],
            "slug": SLUGS[ch],
            "word": WORDS[ch],
            "entries": compiled,
        }
        audit[ch] = {
            "basis": BASES[ch],
            "basisAnchors": basis[ch]["metrics"]["anchors"],
            "entries": {
                e["id"]: {
                    "sha256": h,
                    "metrics": {k: v for k, v in e["metrics"].items() if k != "points"},
                    "companionMetrics": {
                        k: v
                        for k, v in e["companion"]["metrics"].items()
                        if k != "points"
                    }
                    if e.get("companion")
                    else None,
                }
                for e, h in zip(compiled, hashes)
            },
        }
        specimen_sheet(ch, compiled, glyphs, basis, runs)
    before_after(letters, basis, glyphs, runs)
    data = {
        "letters": letters,
        "basis": basis,
        "glyphs": glyphs,
        "runs": runs,
        "sampleRuns": SAMPLE_RUNS,
        "fullSample": FULL_SAMPLE,
    }
    payload = json.dumps(data, ensure_ascii=False, separators=(",", ":")).replace(
        "<", "\\u003c"
    )
    page = (ROOT / "tools/yehuda_refinements.html").read_text(encoding="utf-8")
    assert "__DATA__" in page
    (ROOT / "specimens/refinements.html").write_text(
        page.replace("__DATA__", payload), encoding="utf-8", newline="\n"
    )
    (OUTPUT / "manifest.json").write_text(
        json.dumps(
            {
                "count": 100,
                "companionCount": 20,
                "weight": 700,
                "fontSha256": hashlib.sha256(FONT.read_bytes()).hexdigest(),
                "sample": FULL_SAMPLE,
                "status": "unselected refinements; existing font unchanged",
                "letters": audit,
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(
        "100 distinct low-node refinements + 20 matched final tsadis; complete alphabet and figures in every specimen"
    )


if __name__ == "__main__":
    generate()
