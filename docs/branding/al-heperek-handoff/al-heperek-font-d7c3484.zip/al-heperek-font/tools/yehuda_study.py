"""Explicit authoring of the SVG reconstruction; normal builds only read UFOs."""

from pathlib import Path
import sys
import tempfile
import json
from ufoLib2 import Font

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))


def author():
    from al_heperek.yehuda_hebrew import outlines
    from al_heperek.yehuda_digits import outlines as digit_outlines
    from al_heperek.geometry import draw_spec
    from al_heperek.hebrew_spacing import READING_BEARINGS, PAIRS

    temporary = ROOT / "build/source-tmp"
    temporary.mkdir(parents=True, exist_ok=True)
    tempfile.tempdir = str(temporary)
    metrics = json.loads((ROOT / "sources/metrics.json").read_text(encoding="utf-8"))
    for style, weight in [("Regular", 400), ("SemiBold", 600), ("Bold", 700)]:
        path = ROOT / "sources" / f"AlHeperek-{style}.ufo"
        with Font.open(path) as font:
            font.info.versionMajor = metrics["versionMajor"]
            font.info.versionMinor = metrics["versionMinor"]
            names = []
            for ch, outline in (outlines(weight) | digit_outlines(weight)).items():
                name = f"uni{ord(ch):04X}.ss03"
                if name in font:
                    del font[name]
                glyph = font.newGlyph(name)
                draw_spec(glyph, {"outlines": [outline], "advance": 700}, 70, ch)
                bounds = glyph.getBounds(font)
                if ch.isascii() and ch.isdigit():
                    glyph.move((320 - (bounds.xMin + bounds.xMax) / 2, 0))
                    glyph.width = 640
                    names.append(name)
                    continue
                left, right = READING_BEARINGS[ch]
                dx = left - round(bounds.xMin)
                glyph.move((dx, 0))
                glyph.width = round(bounds.xMax) + dx + right
                middle = glyph.width / 2
                center = {
                    "ו": left - 35,
                    "ן": left - 35,
                    "ז": left - 30,
                    "פ": middle + 35,
                    "ף": middle + 35,
                }.get(ch, middle)
                anchors = {
                    "center": (center, 320),
                    "bottom": (middle, 175 if ch == "ך" else -65),
                    "top": (middle, 775),
                }
                if ch == "ש":
                    anchors.update(shin=(glyph.width - 90, 775), sin=(left + 80, 775))
                for key, (x, y) in anchors.items():
                    glyph.appendAnchor({"name": key, "x": round(x), "y": y})
                names.append(name)
            font.glyphOrder = [
                n for n in font.glyphOrder if not n.endswith(".ss03")
            ] + sorted(names)
            font.lib["public.openTypeCategories"].update(dict.fromkeys(names, "base"))
            for pair, (_, value) in PAIRS.items():
                font.kerning[tuple(f"uni{ord(c):04X}.ss03" for c in pair)] = value
            group = font.groups["public.kern1.HebrewBeforeSpace"]
            font.groups["public.kern1.HebrewBeforeSpace"] = [
                n for n in group if not n.endswith(".ss03")
            ] + sorted(n for n in names if n.startswith("uni05"))
            # The original cuts and their anchors stay intact.
            digit_names = [f"uni{ord(ch):04X}" for ch in "0123456789"]
            digit_rule = (
                " sub @YehudaDigits by ["
                + " ".join(n + ".ss03" for n in digit_names)
                + "];\n"
            )
            feature = (
                "\n@YehudaDigits = [" + " ".join(digit_names) + "];\n"
                'feature ss03 {\n featureNames { name "Yehuda SVG reconstruction"; };\n'
                " script DFLT;\n language dflt;\n"
                + digit_rule
                + " script latn;\n language dflt;\n"
                + digit_rule
                + " script hebr;\n language dflt;\n"
                + digit_rule
                + " sub @Hebrew by ["
                + " ".join(sorted(n for n in names if n.startswith("uni05")))
                + "];\n} ss03;\n"
            )
            feature += "feature mark {\n script hebr;\n language dflt;\n"
            for name in sorted(names):
                for anchor in font[name].anchors:
                    feature += f" pos base {name} <anchor {round(anchor.x)} {round(anchor.y)}> mark @MC_{anchor.name};\n"
            feature += "} mark;\n"
            marker = "# BEGIN YEHUDA STUDY"
            font.features.text = (
                font.features.text.split(marker)[0] + marker + "\n" + feature
            )
            font.save(path, overwrite=True)
            print(f"{style}: authored 27 Hebrew letters and 10 tabular figures in ss03")


if __name__ == "__main__":
    author()
