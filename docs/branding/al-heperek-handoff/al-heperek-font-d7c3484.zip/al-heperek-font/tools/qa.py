"""Validate the built Al Heperek fonts and write a machine-readable report."""
from __future__ import annotations

from io import BytesIO
from pathlib import Path
import hashlib
import json
import sys
import unicodedata

from fontTools.ttLib import TTFont
from fontTools.ttLib.sfnt import calcChecksum
import uharfbuzz as hb

ROOT = Path(__file__).resolve().parents[1]
STYLES = {'Regular': 400, 'SemiBold': 600, 'Bold': 700}
FAMILY = 'Al Heperek Font'
SHAPING_CASES = [
    ('brand', 'תנ״ך על הפרק', 'rtl', 'Hebr'),
    ('final_forms', 'ך ם ן ף ץ', 'rtl', 'Hebr'),
    ('niqqud', 'שָׁלוֹם בְּרָכָה', 'rtl', 'Hebr'),
    ('latin', 'Al Heperek Font AVATAR', 'ltr', 'Latn'),
    ('mixed', 'על הפרק 2026 / Al Heperek 5787', 'rtl', 'Hebr'),
    ('punctuation', '“Hello” — 12.50 ₪ / 2026…', 'ltr', 'Latn'),
]
MARK_CASES = ['שַ', 'שָׁ', 'שִׂ', 'בּ', 'וֹ', 'בְ']


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def preferred_name(font: TTFont, name_id: int, fallback_id: int) -> str | None:
    return font['name'].getDebugName(name_id) or font['name'].getDebugName(fallback_id)


def shape(font_data: bytes, text: str, direction: str = 'rtl', script: str = 'Hebr', features: dict | None = None) -> list[dict]:
    face = hb.Face(font_data)
    font = hb.Font(face)
    font.scale = (face.upem, face.upem)
    hb.ot_font_set_funcs(font)
    buffer = hb.Buffer()
    buffer.add_str(text)
    buffer.direction = direction
    buffer.script = script
    buffer.language = 'he' if script == 'Hebr' else 'en'
    hb.shape(font, buffer, features or {})
    return [
        {
            'glyph': info.codepoint,
            'cluster': info.cluster,
            'xAdvance': position.x_advance,
            'yAdvance': position.y_advance,
            'xOffset': position.x_offset,
            'yOffset': position.y_offset,
        }
        for info, position in zip(buffer.glyph_infos, buffer.glyph_positions)
    ]


def glyph_bounds(font: TTFont, glyph_name: str) -> tuple[int, int, int, int] | None:
    glyph = font['glyf'][glyph_name]
    if glyph.numberOfContours == 0:
        return None
    glyph.recalcBounds(font['glyf'])
    return glyph.xMin, glyph.yMin, glyph.xMax, glyph.yMax


def positioned_ink_bounds(font: TTFont, positions: list[dict]) -> tuple[int, int, int, int] | None:
    order = font.getGlyphOrder()
    cursor_x = cursor_y = 0
    result = None
    for position in positions:
        bounds = glyph_bounds(font, order[position['glyph']])
        if bounds is not None:
            x = cursor_x + position['xOffset']
            y = cursor_y + position['yOffset']
            ink = (bounds[0] + x, bounds[1] + y, bounds[2] + x, bounds[3] + y)
            if result is None:
                result = ink
            else:
                result = (min(result[0], ink[0]), min(result[1], ink[1]), max(result[2], ink[2]), max(result[3], ink[3]))
        cursor_x += position['xAdvance']
        cursor_y += position['yAdvance']
    return result


def verify_woff2_roundtrip(ttf: TTFont, webfont_path: Path) -> dict:
    require(webfont_path.read_bytes()[:4] == b'wOF2', f'Invalid WOFF2 header: {webfont_path.name}')
    webfont = TTFont(webfont_path, recalcTimestamp=False)
    require(webfont.getBestCmap() == ttf.getBestCmap(), f'WOFF2 cmap differs: {webfont_path.name}')
    require(webfont.getGlyphOrder() == ttf.getGlyphOrder(), f'WOFF2 glyph order differs: {webfont_path.name}')
    require(webfont['hmtx'].metrics == ttf['hmtx'].metrics, f'WOFF2 advances differ: {webfont_path.name}')
    for name_id in (0, 1, 2, 4, 6, 13, 14, 16, 17):
        require(webfont['name'].getDebugName(name_id) == ttf['name'].getDebugName(name_id), f'WOFF2 name {name_id} differs: {webfont_path.name}')
    for name in ttf.getGlyphOrder():
        original = ttf['glyf'][name].getCoordinates(ttf['glyf'])
        decoded = webfont['glyf'][name].getCoordinates(webfont['glyf'])
        require(list(original[0]) == list(decoded[0]), f'WOFF2 outline coordinates differ: {name}')
        require(list(original[1]) == list(decoded[1]), f'WOFF2 contours differ: {name}')
        require(list(original[2]) == list(decoded[2]), f'WOFF2 point flags differ: {name}')
    for tag in ('GPOS', 'GDEF', 'GSUB'):
        require(webfont.getTableData(tag) == ttf.getTableData(tag), f'WOFF2 {tag} differs: {webfont_path.name}')
    webfont.flavor = None
    restored = BytesIO()
    webfont.save(restored)
    require(calcChecksum(restored.getvalue()) == 0xB1B0AFBA, 'Restored SFNT checksum is invalid')
    return {'status': 'passed', 'outlineCount': len(ttf.getGlyphOrder()), 'restoredSfntChecksum': 'B1B0AFBA'}


def inspect_font(root: Path, style: str, weight: int) -> dict:
    ttf_path = root / 'dist/ttf' / f'AlHeperek-{style}.ttf'
    webfont_path = root / 'dist/woff2' / f'AlHeperek-{style}.woff2'
    font_bytes = ttf_path.read_bytes()
    require(font_bytes[:4] == b'\x00\x01\x00\x00', f'Invalid TTF header: {ttf_path.name}')
    require(calcChecksum(font_bytes) == 0xB1B0AFBA, f'Invalid SFNT checksum: {ttf_path.name}')
    font = TTFont(ttf_path, checkChecksums=2, recalcTimestamp=False)
    font.ensureDecompiled()
    require(font['head'].unitsPerEm == 1000, 'Expected 1000 units per em')
    require(preferred_name(font, 16, 1) == FAMILY, 'Incorrect preferred font family')
    require(preferred_name(font, 17, 2) == style, 'Incorrect preferred font style')
    require(font['name'].getDebugName(6) == f'AlHeperek-{style}', 'Incorrect PostScript name')
    require(font['OS/2'].usWeightClass == weight, 'Incorrect weight class')
    require(font['OS/2'].fsType == 4, 'Expected Preview & Print embedding flag')
    require('DoradSoft' in (font['name'].getDebugName(0) or ''), 'Missing copyright holder')
    require('All rights reserved' in (font['name'].getDebugName(0) or ''), 'Missing restricted copyright notice')
    expected_license = (root / 'LICENSE').read_text(encoding='utf-8').strip()
    require((font['name'].getDebugName(13) or '').strip() == expected_license, 'Font license metadata does not match LICENSE')
    require((font['name'].getDebugName(14) or '').endswith('/font-license.txt'), 'Missing readable font license URL')

    cmap = font.getBestCmap()
    expected = set(json.loads((root / 'sources/charset.json').read_text(encoding='utf-8'))['codepoints'])
    require(set(cmap) == expected, f'Charset mismatch: missing={sorted(expected - set(cmap))}, extra={sorted(set(cmap) - expected)}')
    require(set(range(0x20, 0x7F)).issubset(cmap), 'Basic Latin coverage is incomplete')
    require(set(range(0x05D0, 0x05EB)).issubset(cmap), 'Hebrew letters or final forms are missing')
    require({0x05F3, 0x05F4}.issubset(cmap), 'Hebrew punctuation is missing')
    require(not any(0x0591 <= cp <= 0x05AF for cp in cmap), 'Cantillation must not be included')
    marks = [cp for cp in cmap if unicodedata.combining(chr(cp))]
    require(marks, 'Expected original niqqud coverage')
    for cp in marks:
        require(font['hmtx'][cmap[cp]][0] == 0, f'Combining mark U+{cp:04X} has nonzero advance')
        classes = font['GDEF'].table.GlyphClassDef.classDefs
        require(classes.get(cmap[cp]) == 3, f'Combining mark U+{cp:04X} is not classified as a mark')

    ascent, descent = font['hhea'].ascent, font['hhea'].descent
    require((ascent, descent, font['hhea'].lineGap) == (1000, -350, 0), 'Unexpected hhea line metrics')
    os2 = font['OS/2']
    require((os2.sTypoAscender, os2.sTypoDescender, os2.sTypoLineGap) == (1000, -350, 0), 'Unexpected typographic line metrics')
    for name in font.getGlyphOrder():
        bounds = glyph_bounds(font, name)
        if bounds is not None:
            require(descent <= bounds[1] <= bounds[3] <= ascent, f'Glyph {name} exceeds the line box: {bounds}')

    require('GPOS' in font and 'GDEF' in font, 'Missing positioning tables')
    feature_tags = {record.FeatureTag for record in font['GPOS'].table.FeatureList.FeatureRecord}
    require({'kern', 'mark'}.issubset(feature_tags), 'Missing original kern or mark feature')
    samples = []
    for name, text, direction, script in SHAPING_CASES:
        positions = shape(font_bytes, text, direction, script)
        require(positions and all(position['glyph'] != 0 for position in positions), f'Missing shaped glyph in {name}')
        ink = positioned_ink_bounds(font, positions)
        require(ink is not None and descent <= ink[1] <= ink[3] <= ascent, f'Positioned ink exceeds the line box in {name}: {ink}')
        samples.append({'case': name, 'text': text, 'glyphCount': len(positions), 'inkBounds': ink})

    mark_results = []
    for text in MARK_CASES:
        on = shape(font_bytes, text, features={'mark': True, 'mkmk': True})
        off = shape(font_bytes, text, features={'mark': False, 'mkmk': False})
        attached = [position for position in on if position['xAdvance'] == 0 and (position['xOffset'] or position['yOffset'])]
        require(attached, f'Niqqud lacks a positioning offset: {text!r}')
        require(on != off, f'Enabling mark does not change positioning: {text!r}')
        mark_results.append({'text': text, 'positionedMarks': len(attached)})
    kerned = shape(font_bytes, 'AV', 'ltr', 'Latn', {'kern': True})
    unkerned = shape(font_bytes, 'AV', 'ltr', 'Latn', {'kern': False})
    kerned_advance = sum(item['xAdvance'] for item in kerned)
    unkerned_advance = sum(item['xAdvance'] for item in unkerned)
    require(unkerned_advance > kerned_advance > 0, 'AV kerning does not reduce the pair advance')

    roundtrip = verify_woff2_roundtrip(font, webfont_path)
    font.close()
    return {
        'status': 'passed', 'style': style, 'weight': weight,
        'ttf': ttf_path.relative_to(root).as_posix(),
        'woff2': webfont_path.relative_to(root).as_posix(),
        'ttfSha256': hashlib.sha256(font_bytes).hexdigest(),
        'woff2Sha256': hashlib.sha256(webfont_path.read_bytes()).hexdigest(),
        'characterCount': len(cmap), 'glyphCount': roundtrip['outlineCount'],
        'combiningMarks': len(marks), 'cantillation': False,
        'lineBox': {'ascent': ascent, 'descent': descent},
        'shapingSamples': samples, 'markAttachment': mark_results,
        'avKerning': {'unkernedAdvance': unkerned_advance, 'kernedAdvance': kerned_advance, 'reduction': unkerned_advance - kerned_advance},
        'woff2Roundtrip': roundtrip,
    }


def audit_family(root: Path = ROOT) -> dict:
    results = []
    for style, weight in STYLES.items():
        try:
            results.append(inspect_font(root, style, weight))
        except Exception as error:
            results.append({'status': 'failed', 'style': style, 'weight': weight, 'error': f'{type(error).__name__}: {error}'})
    manifest_error = None
    try:
        manifest = json.loads((root / 'dist/manifest.json').read_text(encoding='utf-8'))
        require(manifest['family'] == FAMILY, 'Distribution manifest has the wrong family')
        require(manifest['cantillation'] is False, 'Distribution manifest must exclude cantillation')
        require(len(manifest['files']) == 6, 'Distribution manifest must describe three TTFs and three WOFF2 files')
        for item in manifest['files']:
            require(hashlib.sha256((root / item['file']).read_bytes()).hexdigest() == item['sha256'], f'Distribution manifest hash mismatch: {item["file"]}')
        require((root / 'dist/LICENSE.txt').read_bytes() == (root / 'LICENSE').read_bytes(), 'Distribution license differs from LICENSE')
    except Exception as error:
        manifest_error = f'{type(error).__name__}: {error}'
    passed = all(result['status'] == 'passed' for result in results) and manifest_error is None
    return {'schemaVersion': 1, 'family': FAMILY, 'status': 'passed' if passed else 'failed', 'fonts': results, 'distribution': {'status': 'passed' if manifest_error is None else 'failed', 'error': manifest_error}}


def main() -> int:
    report = audit_family()
    destination = ROOT / 'build/qa-report.json'
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    passed = sum(result['status'] == 'passed' for result in report['fonts'])
    print(f'Font QA {report["status"]}: {passed}/{len(STYLES)} styles; report: {destination.relative_to(ROOT).as_posix()}')
    for result in report['fonts']:
        if result['status'] == 'failed':
            print(f'  {result["style"]}: {result["error"]}')
    if report['distribution']['error']:
        print(f'  Distribution: {report["distribution"]["error"]}')
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    sys.exit(main())
