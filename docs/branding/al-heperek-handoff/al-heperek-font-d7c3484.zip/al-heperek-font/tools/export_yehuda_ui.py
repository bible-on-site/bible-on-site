"""Export the reviewed cut under the application's existing UI family name."""

from export_ui import export_ui


if __name__ == "__main__":
    export_ui(
        cut="ss03",
        family="Al Heperek Font UI",
        stem="AlHeperekUI",
        directory="yehuda-ui",
        extra_codepoints=tuple(range(0x30, 0x3A)),
    )
