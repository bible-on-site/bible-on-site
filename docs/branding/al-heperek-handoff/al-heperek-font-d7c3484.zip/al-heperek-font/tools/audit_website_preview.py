"""Verify the exact review fonts and optional logos on the real local website."""

import argparse
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import re
from urllib.parse import urljoin, urlparse
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parents[1]


class FontLinks(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = set()
        self.stylesheets = set()

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if tag == "link" and values.get("as") == "font":
            self.links.add(values["href"])
        if tag == "link" and values.get("rel") == "stylesheet":
            self.stylesheets.add(values["href"])


def audit(base_url):
    target = urlparse(base_url)
    if target.scheme != "http" or target.hostname not in {
        "127.0.0.1",
        "localhost",
        "::1",
    }:
        raise ValueError("Audit only the requested local preview server")
    parser = FontLinks()
    with urlopen(base_url, timeout=10) as response:
        parser.feed(response.read().decode("utf-8"))
    # Webpack development loads fonts through stylesheets instead of emitting
    # production's font preload links in the initial HTML.
    for href in sorted(parser.stylesheets):
        css_url = urljoin(base_url, href)
        if urlparse(css_url).netloc != target.netloc:
            raise ValueError("Stylesheet must stay on the local preview origin")
        with urlopen(css_url, timeout=10) as response:
            css = response.read().decode("utf-8")
        parser.links.update(
            urljoin(css_url, value)
            for value in re.findall(
                r"url\([\"\']?([^\"\')]+\.woff2(?:\?[^\"\')]*)?)", css
            )
        )
    expected = {}
    for style in ("Regular", "SemiBold", "Bold"):
        file = ROOT / f"dist/yehuda-ui/woff2/AlHeperekUI-{style}.woff2"
        expected[hashlib.sha256(file.read_bytes()).hexdigest()] = style
    matches = []
    for href in sorted(parser.links):
        url = urljoin(base_url, href)
        if urlparse(url).netloc != target.netloc:
            raise ValueError("Font asset must stay on the local preview origin")
        with urlopen(url, timeout=10) as response:
            digest = hashlib.sha256(response.read()).hexdigest()
        if digest in expected:
            matches.append({"style": expected[digest], "url": url, "sha256": digest})
    assert {item["style"] for item in matches} == {"Regular", "SemiBold", "Bold"}, (
        matches
    )
    logos = []
    prepared = ROOT / "build/website-preview.json"
    if prepared.is_file():
        for item in json.loads(prepared.read_text(encoding="utf-8")).get("logos", []):
            path = item["path"]
            if "/public/" in path:
                relative = path.split("/public/", 1)[1]
            elif path.endswith("src/app/favicon.ico"):
                relative = "favicon.ico"
            else:
                continue
            url = urljoin(base_url, "/" + relative)
            with urlopen(url, timeout=10) as response:
                actual = hashlib.sha256(response.read()).hexdigest()
            assert actual == item["sha256"], (relative, "stale logo response")
            logos.append({"url": url, "sha256": actual})
    report = {"website": base_url, "fonts": matches, "logos": logos, "status": "passed"}
    (ROOT / "build/website-preview-audit.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8"
    )
    print(
        f"Real website audit passed: all three fonts and {len(logos)} logo responses match the review exactly"
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("url")
    audit(parser.parse_args().url)
