"""Compare the reviewed SVG study with its requested contour corrections."""

from pathlib import Path
import subprocess
from specimen import outlined

ROOT = Path(__file__).resolve().parents[1]
PREVIOUS = "827eebb5b4038b2b4d9dbddf8b5dd523fae09e0c"


def generate():
    before = ROOT / "build/yehuda-before"
    before.mkdir(parents=True, exist_ok=True)
    for style in ("Regular", "SemiBold", "Bold"):
        name = f"AlHeperek-{style}.ttf"
        (before / name).write_bytes(
            subprocess.check_output(
                ["git", "show", f"{PREVIOUS}:dist/ttf/{name}"], cwd=ROOT
            )
        )
    out = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="1440" height="900" viewBox="0 0 1440 900">',
        '<rect width="1440" height="900" fill="#faf9f5"/>',
        '<path stroke="#cdd5df" d="M720 35V860 M50 310H1390 M50 490H1390"/>',
    ]
    samples = (
        ("על הפרק", 190, 126, "Bold"),
        ("ב   ם   ט", 295, 96, "Bold"),
        ("א ט מ ע צ ש ץ", 420, 72, "SemiBold"),
        ("צ   ץ   אוצר   ארץ", 580, 62, "Bold"),
        ("ת נ ך ה פ ר ק", 685, 54, "Bold"),
        ("בכל יום נפתח פרק חדש ונלמד יחד.", 775, 32, "Regular"),
        ("האותיות המקוריות נשמרו. ההשלמות תואמו.", 832, 24, "Regular"),
    )
    for right, directory, label in (
        (670, before, "0.9.0 / Before"),
        (1390, ROOT / "dist/ttf", "0.9.1 / After"),
    ):
        out.append(
            outlined(
                directory / "AlHeperek-Regular.ttf",
                label,
                right,
                66,
                25,
                "#426288",
                align="right",
                direction="ltr",
            )
        )
        for text, y, size, style in samples:
            out.append(
                outlined(
                    directory / f"AlHeperek-{style}.ttf",
                    text,
                    right,
                    y,
                    size,
                    "#183461",
                    align="right",
                    direction="rtl",
                    feature="ss03",
                )
            )
    out.append("</svg>")
    (ROOT / "specimens/yehuda-refinement.svg").write_text(
        "\n".join(out) + "\n", encoding="utf-8", newline="\n"
    )
    print("Generated before/after proof from compiled 0.9.0 and 0.9.1 fonts")


if __name__ == "__main__":
    generate()
