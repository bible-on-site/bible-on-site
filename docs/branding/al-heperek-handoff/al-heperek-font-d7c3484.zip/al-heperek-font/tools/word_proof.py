"""Compare the wordmark and reading text from two builds at matching sizes."""

import argparse
import subprocess
from pathlib import Path
from fontTools.ttLib import TTFont

from specimen import outlined


ROOT = Path(__file__).resolve().parents[1]
INK = '#182a42'
BLUE = '#1e5097'
# Both columns share these baselines, type sizes, weights and ink colors.
SAMPLES = (
    ('Bold', 'על הפרק', 193, 136, INK),
    ('Regular', 'א  צ  ץ  ע', 342, 99, INK),
    ('Regular', 'אוצר   עצה   ארץ', 409, 48, BLUE),
    ('Regular', 'איזו מילה תפסה לכם את העין?', 508, 34, INK),
    ('Regular', 'אפשר לחזור אליה ולקרוא בקול.', 552, 34, INK),
    ('Regular', 'לקרוא יחד', 632, 65, INK),
)


def write_comparison(previous_dir, current_dir, previous_label, current_label, destination):
    lines = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="1240" height="674" viewBox="0 0 1240 674">',
        '<title>Al Heperek Font word comparison</title>',
        '<rect width="1240" height="674" fill="#faf8f2"/>',
    ]
    label_font = previous_dir / 'AlHeperek-Regular.ttf'
    for right_edge, directory, label in ((572, previous_dir, previous_label),
                                         (1192, current_dir, current_label)):
        lines.append(outlined(label_font, label, right_edge, 55, 25, BLUE, align='right'))
        for weight, text, baseline, size, color in SAMPLES:
            font = directory / f'AlHeperek-{weight}.ttf'
            lines.append(outlined(font, text, right_edge, baseline, size, color,
                                  align='right', direction='rtl'))
    lines.extend([
        '<path d="M620 30V642 M48 239H1192 M48 447H1192" stroke="#c4c9c6"/>',
        '</svg>',
    ])
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text('\n'.join(lines) + '\n', encoding='utf-8', newline='\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    previous = parser.add_mutually_exclusive_group()
    previous.add_argument('--previous-dir', type=Path, help='Directory containing the earlier TTFs')
    previous.add_argument('--previous-revision', default='0e0dcf4daab97341a1da28b05e6ea84710eebe69',
                          help='Read the earlier TTFs from this Git revision (default: %(default)s)')
    parser.add_argument('--current-dir', type=Path, default=ROOT / 'dist' / 'ttf',
                        help='Directory containing the newer TTFs (default: dist/ttf)')
    parser.add_argument('--previous-label', default='0.5')
    parser.add_argument('--current-label', help='Override the version read from the current font')
    parser.add_argument('--output', type=Path, default=ROOT / 'specimens' / 'word-comparison.svg',
                        help='Destination SVG (default: specimens/word-comparison.svg)')
    args = parser.parse_args()

    previous_dir = args.previous_dir
    if previous_dir is None:
        commit = subprocess.check_output(
            ['git', 'rev-parse', '--verify', '--end-of-options', args.previous_revision + '^{commit}'],
            cwd=ROOT, text=True,
        ).strip()
        previous_dir = ROOT / 'build' / 'word-proof' / commit
        previous_dir.mkdir(parents=True, exist_ok=True)
        for weight in ('Regular', 'Bold'):
            filename = f'AlHeperek-{weight}.ttf'
            revision_path = f'{commit}:dist/ttf/{filename}'
            (previous_dir / filename).write_bytes(
                subprocess.check_output(['git', 'show', revision_path], cwd=ROOT)
            )
    with TTFont(args.current_dir / 'AlHeperek-Regular.ttf') as current:
        label = args.current_label or str(round(current['head'].fontRevision, 3))
    write_comparison(previous_dir, args.current_dir, args.previous_label, label, args.output)


if __name__ == '__main__':
    main()
