"""Twenty low-node shin studies around the user's S03 direction.

The source paths are explicit cubic perimeters. No stroked paths, Boolean
authoring, offsets or curve conversions are used. These are review proposals,
not changes to the canonical font. Coordinates retain the native 133.6 body.
"""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

BASE = dict(
    mt=71,
    rt=131,
    lx=58,
    ly=100,
    rx=117,
    ry=100,
    center=87,
    flat=24,
    olx=21,
    oly=96,
    lh=13,
    rh=25,
    hy=0,
    middle_lean=0,
    right_lean=0,
)

# Each option changes a specific part of the same compact upright skeleton.
PROFILES = [
    dict(name="זקוף רציף", note="שתי קערות נמוכות וזרוע מרכזית רציפה, בכיוון של S03."),
    dict(
        name="קערה עמוקה",
        note="החללים יורדים מעט והבסיס נשאר יציב.",
        ly=103,
        ry=103,
        flat=20,
        oly=98,
    ),
    dict(
        name="קערה רגועה",
        note="קערות מעט גבוהות יותר עם רצפה נדיבה.",
        ly=97,
        ry=98,
        lh=14,
        rh=26,
    ),
    dict(
        name="מרכז שמאלי",
        note="המרכז זז מעט שמאלה והחלל הימני נפתח.",
        mt=69,
        lx=56.5,
        rx=115,
        ly=100.5,
    ),
    dict(
        name="מרכז ימני",
        note="המרכז נפתח מעט ימינה בתוך מבנה קומפקטי.",
        mt=74,
        rt=132,
        lx=61,
        rx=120,
    ),
    dict(
        name="בסיס ישיר",
        note="קטע אופקי ארוך יותר ותחתית יציבה עם פניות חלקות.",
        center=88,
        flat=34,
        olx=20.5,
    ),
    dict(
        name="בסיס מקומר",
        note="הקטע האופקי מתקצר והקערה מתעגלת ברציפות.",
        center=88,
        flat=8,
        oly=94,
    ),
    dict(
        name="חלל שמאלי",
        note="החלל השמאלי מתרחב מעט, עם זרוע מרכזית זקופה.",
        mt=74,
        rt=132,
        lx=61,
        rx=120,
        lh=15,
        flat=28,
    ),
    dict(
        name="חלל ימני",
        note="הימין מתרווח והמרכז נשאר קרוב לשמאל.",
        mt=69,
        rt=135,
        lx=56,
        rx=115,
        flat=26,
    ),
    dict(
        name="ראש נינוח",
        note="ראש המרכז מתחיל מעט נמוך יותר ושומר על הקצב הזקוף.",
        hy=3,
        middle_lean=-0.4,
    ),
    dict(
        name="קצב אסוף",
        note="הדופן הימנית מתקרבת מעט בלי לשנות את עובי המרכז.",
        rt=129,
        rx=116,
        rh=23,
        center=86,
    ),
    dict(
        name="קצב פתוח",
        note="הדופן הימנית מתרחקת מעט והבסיס נפתח בנחת.",
        rt=135,
        rx=118,
        center=89,
        flat=26,
        rh=26,
    ),
    dict(
        name="מרכז מתוח",
        note="זרוע מרכזית מעט מתוחה ושתי פניות פנימיות שקטות.",
        mt=70,
        rx=116,
        ly=99,
        ry=98,
        middle_lean=-0.7,
    ),
    dict(
        name="שמאל יציב",
        note="דופן שמאלית יציבה וקערה פנימית שחוזרת מעט מוקדם.",
        olx=20,
        oly=98,
        lx=57,
        ly=99,
        flat=28,
    ),
    dict(
        name="שמאל זורם",
        note="הפנייה השמאלית מתחילה מעט גבוה יותר וממשיכה ללא שבירה.",
        olx=21.5,
        oly=93,
        lx=59,
        ly=100,
        lh=15,
        flat=18,
    ),
    dict(
        name="ימין זקוף",
        note="הדופן הימנית נשארת כמעט ישרה עד הפנייה התחתונה.",
        rt=132,
        rx=118,
        right_lean=-1.5,
        rh=24,
        center=88,
    ),
    dict(
        name="ימין רך",
        note="החלל הימני מתעגל מעט והמרכז ממשיך אל הקערה בקשת.",
        rt=132,
        rx=118,
        right_lean=1.5,
        rh=26,
        ry=101,
    ),
    dict(
        name="מרכז קמור",
        note="הזרוע המרכזית נפתחת בקימור מתון אל בסיס רחב.",
        mt=72,
        lx=59,
        rx=118,
        middle_lean=1.4,
        flat=30,
    ),
    dict(
        name="פנים מאוזנים",
        note="שני החללים דומים בעומקם, עם חיבורים קצרים ורציפים.",
        mt=72,
        rt=132,
        lx=58.5,
        rx=118,
        ly=101,
        ry=101,
        lh=12,
        rh=24,
    ),
    dict(
        name="מפגש שקט",
        note="מבנה זקוף עם מרכז נמשך ופניות מעט נדיבות יותר.",
        mt=71.5,
        rt=132.5,
        lx=58.5,
        rx=118,
        ly=100.5,
        ry=100,
        lh=14,
        rh=26,
        flat=20,
        center=88,
        middle_lean=0.5,
    ),
]


def number(value):
    return f"{value:.3f}".rstrip("0").rstrip(".")


def command(verb, *values):
    return verb + " ".join(map(number, values))


def outline(settings):
    p = BASE | settings
    mt, rt = p["mt"], p["rt"]
    lx, ly, rx, ry = p["lx"], p["ly"], p["rx"], p["ry"]
    lh, rh = p["lh"], p["rh"]
    hy = p["hy"]
    ro = rt + 35.6
    floor_right = p["center"] + p["flat"] / 2
    floor_left = p["center"] - p["flat"] / 2
    olx, oly = p["olx"], p["oly"]
    # All C/C connections have collinear control handles. The only corners
    # are the source family's deliberately cut top and entry terminals.
    path = [
        command("M", 24.2, -5.8),
        command("L", 27.6, -2.2),
        command("C", 29.2, -0.8, 31.5, 0, 34.2, 0),
        command("C", 42, 0, 47, 17, 49, 40),
        command("C", 51.2, 65.3, lx - lh, ly, lx, ly),
        command("C", lx + lh, ly, mt, 48 + hy, mt, 4.8 + hy),
        command("L", mt + 25.4, hy),
        command("L", mt + 35.6, hy),
        command("C", mt + 36.3 + p["middle_lean"], 43 + hy, rx - rh, ry, rx, ry),
        command("C", rx + rh, ry, rt + p["right_lean"], 48, rt, 4.8),
        command("L", rt + 25.4, 0),
        command("L", ro, 0),
        command("L", ro - 1.5, 73),
        command("C", ro - 2.25, 109.5, floor_right + 40, 136.5, floor_right, 136.5),
        command("L", floor_left, 136.5),
        command("C", floor_left - 40, 136.5, olx, oly + 26, olx, oly),
        command("C", olx, oly - 26, 17.5, 53, 14.3, 40.2),
        command("C", 12.7, 33.8, 10, 33, 10, 28.4),
        command("C", 10, 18.2, 12.3, 8.6, 14.8, -3.6),
        "Z",
    ]
    return " ".join(path)


def generate():
    entries = [
        {
            "id": f"S{21 + index}",
            "name": p["name"],
            "note": p["note"],
            "paths": [outline(p)],
            "base": "S03",
        }
        for index, p in enumerate(PROFILES)
    ]
    assert len(entries) == 20
    assert len({entry["paths"][0] for entry in entries}) == 20
    target = ROOT / "sources/yehuda/refinements/shin.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(
            {"basedOn": {"ש": "S03"}, "letters": {"ש": entries}},
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
        newline="\n",
    )
    proof = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="1240" height="760" viewBox="0 0 1240 760">',
        '<rect width="1240" height="760" fill="#f3f5f8"/>',
    ]
    for index, entry in enumerate(entries):
        x = 14 + index % 5 * 245
        y = 12 + index // 5 * 187
        proof.extend(
            [
                f'<rect x="{x}" y="{y}" width="232" height="174" rx="10" fill="white"/>',
                f'<text x="{x + 12}" y="{y + 25}" font-family="sans-serif" font-size="16" fill="#536b87">{entry["id"]}</text>',
                f'<path transform="translate({x + 40} {y + 35}) scale(.86)" d="{entry["paths"][0]}" fill="#193e76"/>',
            ]
        )
    proof.append("</svg>")
    (ROOT / "build").mkdir(exist_ok=True)
    (ROOT / "build/refine-shin.svg").write_text(
        "\n".join(proof) + "\n", encoding="utf-8", newline="\n"
    )
    print("Authored 20 low-node shin proposals, S21-S40, around S03")


if __name__ == "__main__":
    generate()
