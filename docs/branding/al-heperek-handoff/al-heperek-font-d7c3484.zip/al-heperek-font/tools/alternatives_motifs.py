"""Optically balanced motifs for review proposals, never canonical font sources.

The source roof corner spans 50.8 units. Used as a detached terminal, that
corner reads as a large block next to the 32.4-unit stems. This independently
drawn cap keeps its lifted tip but reduces the exposed width to 40.8 units.
The neck retains the original body connection points, so existing skeletons
and their branch/foot choices remain intact.
"""


def left_entry(exit_tangent=(1.5, 31.9), connection=(50.8, 40.4)):
    """Trace the quieter head to the existing outer body node (50.8, 40.4).

    The last handle follows the body's outgoing tangent. Matching that handle
    avoids introducing a kink when the same cap enters different skeletons.
    """
    dx, dy = exit_tangent
    x, y = connection
    cx, cy = x - 0.2 * dx, y - 0.2 * dy
    return (
        "M 24.2 -5.8 L 27.6 -2.2 C 29.2 -.8 31.5 0 34.2 0 "
        "L 39.2 0 C 41.4 0 42.9 1.5 43.9 5.4 "
        f"C 45.9 13.2 {cx} {cy} {x} {y} "
    )


def left_return(incoming_tangent=(-4.5, -14.8), connection=(14.3, 40.2)):
    """Return through the existing inner node without the old left overhang."""
    dx, dy = incoming_tangent
    x, y = connection
    cx, cy = x + 0.2 * dx, y + 0.2 * dy
    return f"L {x} {y} C {cx} {cy} 10 33 10 28.4 C 10 18.2 12.3 8.6 14.8 -3.6 Z"


def left_cap(
    exit_tangent=(1.5, 31.9),
    incoming_tangent=(-4.5, -14.8),
    *,
    outer_connection=(50.8, 40.4),
    inner_connection=(14.3, 40.2),
):
    """Close the shared cap for a swept-stroke proposal's standalone head."""
    return left_entry(exit_tangent, outer_connection) + left_return(
        incoming_tangent, inner_connection
    )
