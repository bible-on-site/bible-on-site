"""Render 100 unselected letter proposals without editing or rebuilding the font."""

import hashlib
import html
import json
import math
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

from fontTools.pens.boundsPen import BoundsPen
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.svgLib.path import parse_path
from fontTools.ttLib import TTFont
import uharfbuzz as hb

from specimen import outlined
from yehuda_logos import Lettering

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

LETTERS = {
    "א": ("A", "alef", "אור", "אוצר", "ארץ"),
    "ע": ("E", "ayin", "על", "עולם", "עצה"),
    "ט": ("T", "tet", "טוב", "נטע", "מבט"),
    "צ": ("C", "tsadi", "ציון", "צדק", "עצה"),
    "ש": ("S", "shin", "שלום", "ראשית", "שפה"),
}
FONT = ROOT / "dist/ttf/AlHeperek-Bold.ttf"
DESTINATION = ROOT / "specimens/alternatives"


def bounds(path):
    pen = BoundsPen(None)
    parse_path(path, pen)
    assert pen.bounds and all(math.isfinite(v) for v in pen.bounds)
    return list(pen.bounds)


def original_glyphs(font):
    glyphs = font.getGlyphSet()
    result = {}
    for ch in " " + "".join(map(chr, range(0x05D0, 0x05EB))):
        name = "space" if ch == " " else f"uni{ord(ch):04X}.ss03"
        glyph = glyphs[name]
        pen = SVGPathPen(glyphs)
        glyph.draw(pen)
        path = pen.getCommands()
        result[ch] = {
            "path": path,
            "advance": glyph.width,
            "bounds": bounds(path) if path else [0, 0, glyph.width, 0],
        }
    return result


def compile_proposal(entry, ch):
    from al_heperek.hebrew_spacing import READING_BEARINGS
    from al_heperek.yehuda_hebrew import compile_outline

    assert entry["name"] and entry["note"] and entry["paths"]
    for raw in entry["paths"]:
        assert raw.strip().upper().endswith("Z"), entry["id"]
    path = compile_outline(entry["paths"], 700)
    left, _, right, _ = bounds(path)
    lsb, rsb = READING_BEARINGS[ch]
    shifted = SVGPathPen(None)
    parse_path(path, TransformPen(shifted, (1, 0, 0, 1, lsb - left, 0)))
    path = shifted.getCommands()
    box = bounds(path)
    assert box[3] > 600 and box[1] > -80 and box[3] < 760, (entry["id"], box)
    return {
        "id": entry["id"],
        "name": entry["name"],
        "note": entry["note"],
        "path": path,
        "bounds": box,
        "advance": right - left + lsb + rsb,
    }


def path_at(glyph, cx, baseline, scale, color="#193e76"):
    left, _, right, _ = glyph["bounds"]
    x = cx - (left + right) * scale / 2
    return (
        f'<path d="{glyph["path"]}" fill="{color}" '
        f'transform="translate({x:.4f} {baseline}) scale({scale} {-scale})"/>'
    )


def shaped_runs(font, glyphs):
    shaper = hb.Font(hb.Face(FONT.read_bytes()))
    hb.ot_font_set_funcs(shaper)
    order = font.getGlyphOrder()
    result = {}
    for text in sorted({word for values in LETTERS.values() for word in values[2:]}):
        buffer = hb.Buffer()
        buffer.add_str(text)
        buffer.direction, buffer.script, buffer.language = "rtl", "Hebr", "he"
        hb.shape(shaper, buffer, {"ss03": True, "kern": True})
        parts = []
        for info, position in zip(buffer.glyph_infos, buffer.glyph_positions):
            ch = text[info.cluster]
            assert order[info.codepoint] == f"uni{ord(ch):04X}.ss03"
            parts.append(
                {
                    "ch": ch,
                    "kern": position.x_advance - glyphs[ch]["advance"],
                    "x": position.x_offset,
                    "y": position.y_offset,
                }
            )
        result[text] = parts
    return result


def word_paths(text, glyphs, proposals, runs, size=32, cx=0, baseline=0):
    pieces = []
    cursor = 0
    for placement in runs[text]:
        ch = placement["ch"]
        glyph = proposals.get(ch, glyphs[ch])
        pieces.append(
            f'<path d="{glyph["path"]}" fill="'
            + ("#245edb" if ch in proposals else "#193e76")
            + f'" transform="translate({cursor + placement["x"]} {-placement["y"]}) scale(1 -1)"/>'
        )
        cursor += glyph["advance"] + placement["kern"]
    scale = size / 1000
    return (
        f'<g transform="translate({cx - cursor * scale / 2:.4f} {baseline}) '
        f'scale({scale})">' + "".join(pieces) + "</g>"
    )


def sheet(ch, entries, glyphs, runs):
    _, slug, _, word, _ = LETTERS[ch]
    out = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="1240" height="1190" '
        'viewBox="0 0 1240 1190" role="img">',
        f"<title>{html.escape(ch)} - 20 original alternatives, Bold 700</title>",
        '<rect width="1240" height="1190" fill="#f3f5f8"/>',
        outlined(FONT, f"{slug.upper()} / 20", 40, 62, 30, "#193e76"),
        outlined(FONT, "Bold 700", 1200, 62, 22, "#63738b", align="right"),
    ]
    for index, glyph in enumerate(entries):
        col, row = index % 5, index // 5
        x, y = 30 + col * 244, 95 + row * 268
        cx = x + 110
        out.append(
            f'<rect x="{x}" y="{y}" width="226" height="248" rx="14" fill="white"/>'
        )
        out.append(outlined(FONT, glyph["id"], x + 16, y + 30, 20, "#63738b"))
        out.append(path_at(glyph, cx, y + 151, 0.157))
        out.append(word_paths(word, glyphs, {ch: glyph}, runs, 32, cx, y + 193))
        out.append(
            outlined(
                FONT,
                glyph["name"],
                cx,
                y + 227,
                19,
                "#63738b",
                align="center",
                direction="rtl",
                feature="ss03",
            )
        )
    out.append("</svg>")
    (DESTINATION / f"{slug}.svg").write_text("\n".join(out) + "\n", encoding="utf-8")


def wide_logo():
    """New wide proposal: one wordmark plus the book, without the stacked name."""
    root = ET.parse(ROOT / "sources/yehuda/alternatives/wide-logo.svg").getroot()
    lettering = Lettering(FONT)
    for element in root.iter():
        if element.get("data-run"):
            lettering.fit(element)
    assert len([el for el in root.iter() if el.get("data-run")]) == 1
    (DESTINATION / "wide-logo.svg").write_bytes(
        ET.tostring(root, encoding="utf-8", xml_declaration=True) + b"\n"
    )


def generate():
    DESTINATION.mkdir(parents=True, exist_ok=True)
    font = TTFont(FONT)
    glyphs = original_glyphs(font)
    runs = shaped_runs(font, glyphs)
    supplied = {}
    for source in sorted((ROOT / "sources/yehuda/alternatives").glob("*.json")):
        for ch, entries in json.loads(source.read_text(encoding="utf-8"))[
            "letters"
        ].items():
            assert ch not in supplied, ch
            supplied[ch] = entries
    assert set(supplied) == set(LETTERS), set(supplied)
    letters = {}
    fingerprints = {}
    for ch, (prefix, slug, *words) in LETTERS.items():
        entries = supplied[ch]
        assert len(entries) == 20, (ch, len(entries))
        assert [e["id"] for e in entries] == [f"{prefix}{n:02}" for n in range(1, 21)]
        compiled = [compile_proposal(e, ch) for e in entries]
        hashes = [hashlib.sha256(e["path"].encode()).hexdigest() for e in compiled]
        assert len(set(hashes)) == 20, (ch, "duplicate outlines")
        letters[ch] = {"slug": slug, "words": words, "entries": compiled}
        fingerprints[ch] = dict(zip((e["id"] for e in entries), hashes))
        sheet(ch, compiled, glyphs, runs)
    wide_logo()
    data = {"letters": letters, "glyphs": glyphs, "runs": runs, "weight": 700}
    page = (ROOT / "tools/yehuda_alternatives.html").read_text(encoding="utf-8")
    payload = json.dumps(data, ensure_ascii=False, separators=(",", ":")).replace(
        "<", "\\u003c"
    )
    assert "__DATA__" in page
    (ROOT / "specimens/alternatives.html").write_text(
        page.replace("__DATA__", payload), encoding="utf-8"
    )
    report = {
        "status": "unselected design proposals, not installed in the font",
        "fontSha256": hashlib.sha256(FONT.read_bytes()).hexdigest(),
        "count": 100,
        "weight": 700,
        "letters": fingerprints,
    }
    (DESTINATION / "manifest.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(
        "100 distinct vector proposals: 20 each for א ע ט צ ש; font binaries unchanged"
    )


if __name__ == "__main__":
    generate()
