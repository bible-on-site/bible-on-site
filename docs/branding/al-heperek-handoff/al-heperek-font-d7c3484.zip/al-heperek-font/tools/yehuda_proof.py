"""Review sheets use the compiled ss03 outlines and the unchanged ss02 cut."""

import json
from pathlib import Path
from specimen import outlined

ROOT = Path(__file__).resolve().parents[1]


def generate():
    fonts = {
        s: ROOT / "dist/ttf" / f"AlHeperek-{s}.ttf"
        for s in ("Regular", "SemiBold", "Bold")
    }
    source = json.loads(
        (ROOT / "sources/yehuda/lettering.json").read_text(encoding="utf-8")
    )
    out = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="1440" height="1970" viewBox="0 0 1440 1970"><rect width="1440" height="1970" fill="#faf9f5"/>'
    ]

    def text(
        value, right, y, size=40, style="Regular", feature="ss03", color="#183461"
    ):
        out.append(
            outlined(
                fonts[style],
                value,
                right,
                y,
                size,
                color,
                align="right",
                direction="rtl",
                feature=feature,
            )
        )

    text("יהודה / שחזור מתוך האותיות המקוריות", 1370, 82, 30)
    text("על הפרק", 1370, 260, 176, "Bold")
    text("לומדים יחד. מגלים יותר.", 1370, 360, 70, "Regular")
    for row, style in enumerate(fonts):
        out.append(
            outlined(
                fonts["Regular"],
                style,
                1370,
                437 + row * 80,
                22,
                "#183461",
                align="right",
                direction="ltr",
            )
        )
        text("אוצר מילים חדש בארץ שלנו", 1120, 437 + row * 80, 53, style)
    out.append('<path d="M70 660H1370" stroke="#cdd5df"/>')
    for i, ch in enumerate("אבגדהוזחטיכלמנסעפצקרשתךםןףץ"):
        col = i % 9
        row = i // 9
        right = 1370 - col * 147
        y = 810 + row * 160
        out.append(f'<path d="M{right - 125} {y}H{right}" stroke="#d4dce6"/>')
        text(
            ch,
            right - 18,
            y,
            118,
            "Bold",
            color="#164b9a" if ch in source["glyphs"] else "#183461",
        )
    text("ו ר ח ך ף ה ב ת", 1370, 1350, 67, "SemiBold")
    text("פ ס ט   ט ש   ק ל   א צ ץ", 1370, 1442, 60, "SemiBold")
    text("בכל יום נפתח פרק חדש, נקרא יחד ונמצא בו משמעות.", 1370, 1540, 38)
    text("אצלנו בארץ לומדים לשאול, להקשיב ולגלות.", 1370, 1602, 38)
    text("שָׁלוֹם, בְּרָכָה, שִׂמְחָה, לְךָ, כֵּן.", 1370, 1680, 44)
    text("על הפרק - לימוד יומי, קריאה טובה.", 1370, 1760, 32)
    text("על הפרק - לימוד יומי, קריאה טובה.", 1370, 1810, 24)
    text("על הפרק - לימוד יומי, קריאה טובה.", 1370, 1854, 16)
    text("הגרסה הקודמת: על הפרק", 1370, 1930, 48, feature="ss02")
    out.append("</svg>")
    (ROOT / "specimens/yehuda.svg").write_text("\n".join(out) + "\n", encoding="utf-8")
    template = (ROOT / "tools/yehuda_review.html").read_text(encoding="utf-8")
    letters = "אבגדהוזחטיכלמנסעפצקרשתךםןףץ"
    cards = "".join(
        f'<div class="letter {"supplied" if c in source["glyphs"] else "extended"}"><span class="draw">{c}</span><small>{"מהמקור" if c in source["glyphs"] else "השלמה"}</small></div>'
        for c in letters
    )
    source_letters = ""
    for ch in "תנךהפרק":
        d = source["glyphs"][ch]["path"]
        source_letters += f'<svg viewBox="-8 -16 150 200" aria-label="{ch}"><path fill="currentColor" d="{d}"/></svg>'
    template = template.replace("{{CARDS}}", cards).replace(
        "{{SOURCE}}", source_letters
    )
    (ROOT / "specimens/yehuda.html").write_text(template, encoding="utf-8")
    print("Generated actual-font SVG and interactive review")


if __name__ == "__main__":
    generate()
