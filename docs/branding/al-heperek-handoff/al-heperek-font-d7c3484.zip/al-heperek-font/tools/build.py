"""Compile the editable UFO masters with the locked fontmake toolchain."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys

from fontTools.ttLib import TTFont

ROOT = Path(__file__).resolve().parents[1]
EPOCH = int(datetime(2026, 11, 15, tzinfo=timezone.utc).timestamp())

def build():
    metrics = json.loads((ROOT / 'sources/metrics.json').read_text())
    target = ROOT / 'dist/ttf'
    web = ROOT / 'dist/woff2'
    target.mkdir(parents=True, exist_ok=True)
    web.mkdir(parents=True, exist_ok=True)
    env = os.environ | {'SOURCE_DATE_EPOCH': str(EPOCH), 'PYTHONHASHSEED': '0'}
    files = []
    for style in metrics['styles']:
        source = ROOT / 'sources' / f"AlHeperek-{style['name']}.ufo"
        if not source.is_dir():
            raise FileNotFoundError(f'Missing editable master {source}; bootstrap only when creating new sources')
        output = target / f"AlHeperek-{style['name']}.ttf"
        subprocess.run([sys.executable, '-m', 'fontmake', '-u', str(source), '-o', 'ttf', '--output-path', str(output), '--overlaps-backend', 'pathops', '--validate-ufo', '--verbose', 'WARNING'], check=True, cwd=ROOT, env=env)
        font = TTFont(output, recalcTimestamp=False)
        font['head'].created = EPOCH + 2082844800
        font['head'].modified = EPOCH + 2082844800
        font.save(output, reorderTables=True)
        font = TTFont(output, recalcTimestamp=False)
        font.flavor = 'woff2'
        woff = web / f"AlHeperek-{style['name']}.woff2"
        font.save(woff)
        for file in (output, woff):
            files.append({'file': file.relative_to(ROOT).as_posix(), 'sha256': hashlib.sha256(file.read_bytes()).hexdigest(), 'weight': style['weight']})
    (ROOT / 'dist/LICENSE.txt').write_bytes((ROOT / 'LICENSE').read_bytes())
    manifest = {'family': metrics['family'], 'version': metrics['version'],
                'stage': 'editorial design review', 'cantillation': False, 'files': files}
    (ROOT / 'dist/manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8', newline='\n')
    print(f'Built {len(files)} TTF/WOFF2 files with matching restricted license')

if __name__ == '__main__':
    build()
