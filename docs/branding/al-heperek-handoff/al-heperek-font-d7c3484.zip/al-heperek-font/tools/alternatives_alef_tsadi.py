"""Draw review-only alef/tsadi studies without altering the font masters.

All geometry is independently authored here. Coordinates use Yehuda's original
133.6-unit body. The twenty studies vary skeleton and attachment, not weight or
an affine transformation of one finished glyph. Each paired study shares the
same upper-right branch. These are candidates, never build inputs.
"""

from pathlib import Path
import json

import pathops
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.svgLib.path import parse_path

from alternatives_motifs import left_cap, left_entry, left_return

ROOT = Path(__file__).resolve().parents[1]


def shape(commands):
    result = pathops.Path()
    parse_path(commands, result.getPen())
    return result


def stroke(commands, width=32.4):
    result = shape(commands)
    result.stroke(width, pathops.LineCap.BUTT_CAP, pathops.LineJoin.ROUND_JOIN, 4)
    result.convertConicsToQuads(0.025)
    return result


def union(parts, fillet=1.2):
    result = pathops.Path()
    for part in parts:
        result.addPath(part)
    result = pathops.simplify(result, clockwise=False)
    if fillet:
        # Closing rounds re-entrant joins instead of leaving hard stroke unions.
        edge = pathops.Path(result)
        edge.stroke(
            2 * fillet, pathops.LineCap.ROUND_CAP, pathops.LineJoin.ROUND_JOIN, 4
        )
        edge.convertConicsToQuads(0.025)
        result = pathops.op(result, edge, pathops.PathOp.UNION)
        edge = pathops.Path(result)
        edge.stroke(
            2 * fillet, pathops.LineCap.ROUND_CAP, pathops.LineJoin.ROUND_JOIN, 4
        )
        edge.convertConicsToQuads(0.025)
        result = pathops.op(result, edge, pathops.PathOp.DIFFERENCE)
    return result


def commands(drawing):
    drawing.convertConicsToQuads(0.025)
    pen = SVGPathPen(None)
    drawing.draw(pen)
    return pen.getCommands()


# centerline controls, foot position, branch controls and body return are all
# explicit design decisions. Width stays constant across every alternative.
STUDIES = [
    (
        "זורם - מאוזן",
        "משפחה זורמת: חיבור מרכזי ורגל נפתחת",
        "flow",
        "open",
        "round",
        "round",
        0,
        0,
        1.6,
    ),
    (
        "זורם - גבוה",
        "משפחה זורמת: המפגש עולה והחלל מתחתיו מתרחב",
        "flow",
        "vertical",
        "high",
        "round",
        0,
        -17,
        1.6,
    ),
    (
        "זורם - נמוך",
        "משפחה זורמת: הענף יורד והבסיס נפתח שמאלה",
        "flow",
        "splayed",
        "low",
        "round",
        6,
        15,
        1.8,
    ),
    (
        "זורם - רחב",
        "משפחה זורמת: ימינה קשת פתוחה ושמאלה רגל מקומרת",
        "flow",
        "curve",
        "wide",
        "round",
        18,
        1,
        2.2,
    ),
    (
        "מבני - זקוף",
        "משפחה מבנית: אלכסון ישר, ענף עומד ורגל אנכית",
        "straight",
        "vertical",
        "upright",
        "box",
        2,
        -2,
        1.0,
    ),
    (
        "מבני - פתוח",
        "משפחה מבנית: אלכסון מתוח ומפגש גבוה",
        "straight",
        "splayed",
        "high",
        "box",
        7,
        -14,
        1.0,
    ),
    (
        "מבני - אסוף",
        "משפחה מבנית: ענף קצר ורגל שנאספת פנימה",
        "straight",
        "tuck",
        "short",
        "box",
        -8,
        -1,
        1.0,
    ),
    (
        "מבני - אלכסוני",
        "משפחה מבנית: ענף חד ומפגש נמוך",
        "straight",
        "open",
        "angular",
        "box",
        6,
        12,
        1.2,
    ),
    (
        "לירי - נמשך",
        "משפחה לירית: אלכסון בתנופה ורגל רחבה",
        "swoop",
        "splayed",
        "lean",
        "sweep",
        8,
        2,
        2.2,
    ),
    (
        "לירי - גבוה",
        "משפחה לירית: מפגש גבוה וסיומת שמאל קשתית",
        "swoop",
        "curve",
        "high",
        "sweep",
        6,
        -16,
        2.4,
    ),
    (
        "לירי - פתוח",
        "משפחה לירית: ענף ימני מרוחק מול רגל זקופה",
        "swoop",
        "vertical",
        "wide",
        "sweep",
        18,
        4,
        2.4,
    ),
    (
        "לירי - נמוך",
        "משפחה לירית: חיבור יורד ורגל שמתכנסת פנימה",
        "swoop",
        "tuck",
        "low",
        "sweep",
        2,
        16,
        2.2,
    ),
    (
        "אסוף - קצר",
        "משפחה אסופה: ענף קצר ויציאה שמאלית קרובה לציר",
        "fold",
        "tuck",
        "short",
        "tuck",
        -9,
        -2,
        1.6,
    ),
    (
        "אסוף - זקוף",
        "משפחה אסופה: מהלך כמעט אנכי בשתי הזרועות",
        "fold",
        "vertical",
        "upright",
        "tuck",
        -6,
        3,
        1.6,
    ),
    (
        "אסוף - פתוח",
        "משפחה אסופה: פער רחב בראש ורגל שנפתחת החוצה",
        "fold",
        "splayed",
        "wide",
        "tuck",
        11,
        2,
        1.8,
    ),
    (
        "אסוף - קמור",
        "משפחה אסופה: שני מהלכים קשתיים סביב ציר קצר",
        "fold",
        "curve",
        "round",
        "tuck",
        0,
        -8,
        2.2,
    ),
    (
        "מקושת - רחב",
        "משפחה מקושתת: אלכסון קמור וענף ימני רחב",
        "bow",
        "open",
        "wide",
        "ramp",
        16,
        2,
        2.4,
    ),
    (
        "מקושת - גבוה",
        "משפחה מקושתת: החיבור עולה והרגל נפתחת באלכסון",
        "bow",
        "splayed",
        "high",
        "ramp",
        8,
        -16,
        2.4,
    ),
    (
        "מקושת - זקוף",
        "משפחה מקושתת: מרכז רך מול זרוע ימנית זקופה",
        "bow",
        "vertical",
        "upright",
        "ramp",
        5,
        3,
        2.4,
    ),
    (
        "מקושת - שוטף",
        "משפחה מקושתת: שני קווים נעים עם רגל שמאל מתעגלת",
        "bow",
        "curve",
        "lean",
        "ramp",
        8,
        9,
        2.6,
    ),
]


def branch(mode, spread, join_shift, root_shift=0):
    # The filled upper-right entry shares the supplied nun's direction, while
    # the lower branch is one smooth broad stroke into the main diagonal.
    x = 77 + spread
    jx = 78 + spread * 0.35 + root_shift
    jy = 87 + join_shift
    controls = {
        "round": (x + 54, 24, x + 48, 58, jx + 14, jy + 10, x + 21, 50),
        "high": (x + 50, 24, x + 41, 46, jx + 6, jy + 3, x + 19, 43),
        "low": (x + 56, 32, x + 48, 69, jx + 15, jy + 12, x + 24, 59),
        "upright": (x + 49, 30, x + 45, 70, jx + 13, jy + 10, x + 21, 58),
        "lean": (x + 62, 30, x + 44, 58, jx + 12, jy + 10, x + 18, 52),
        "short": (x + 43, 25, x + 38, 48, jx + 5, jy + 5, x + 13, 44),
        "wide": (x + 62, 29, x + 54, 64, jx + 16, jy + 10, x + 29, 52),
        "angular": (x + 53, 24, x + 44, 42, jx + 12, jy + 9, x + 20, 42),
    }
    c1x, c1y, c2x, c2y, ex, ey, ix, iy = controls[mode]
    return shape(
        f"M {x + 13} -6.8 C {x + 25.1} -1.6 {x + 33.8} 2.6 {x + 39.1} 5.8 "
        f"C {x + 44.1} 8.7 {x + 47.8} 11.6 {x + 50.3} 14.5 "
        f"C {c1x} {c1y} {c2x} {c2y} {ex} {ey} "
        f"L {jx - 13} {jy - 11} "
        f"C {jx + 7} {jy - 25} {ix} {iy} {x + 20} 32 "
        f"Q {x + 20} 26 {x + 12} 22 L {x - 6.8} 12.2 "
        f"C {x - 4.7} 4.8 {x - 0.2} -7.4 {x + 6.7} -5.5 Z"
    )


def alef(main, leg, fork, spread, join_shift, fillet):
    diagonal = {
        "flow": (35, 65, 85, 81, 117 + spread * 0.4, 131),
        "straight": (55, 60, 87, 102, 122 + spread * 0.3, 131),
        "bow": (26, 81, 108, 53, 130 + spread * 0.3, 131),
        "swoop": (42, 50, 115, 82, 112 + spread * 0.3, 131),
        "fold": (35, 82, 70, 99, 101 + spread * 0.3, 131),
    }[main]
    c1x, c1y, c2x, c2y, ex, ey = diagonal
    # The optically quieter head replaces the oversized isolated roof corner;
    # all twenty diagonals, lower legs and right branches remain unchanged.
    head = shape(left_cap())
    trunk = stroke(f"M 32 24 C {c1x} {c1y} {c2x} {c2y} {ex} {ey}")
    leg_curves = {
        "open": "C 22 77 16 102 17 148",
        "vertical": "C 28 74 25 103 25 147",
        "splayed": "C 31 82 9 112 5 148",
        "curve": "C 7 86 11 113 34 148",
        "tuck": "C 39 89 43 114 44 148",
    }
    # Attach to the actual curve center rather than leaving a merely touching
    # stroke cap: the latter produces a tiny white cut when two curvatures vary.
    t = {"open": 0.36, "vertical": 0.38, "splayed": 0.47, "curve": 0.37, "tuck": 0.47}[
        leg
    ]
    if main == "fold":
        t -= 0.1
    mt = 1 - t
    root_x = mt**3 * 32 + 3 * mt**2 * t * c1x + 3 * mt * t**2 * c2x + t**3 * ex
    root_y = mt**3 * 24 + 3 * mt**2 * t * c1y + 3 * mt * t**2 * c2y + t**3 * ey
    lower_leg = stroke(f"M {root_x} {root_y} " + leg_curves[leg])
    foot_cut = shape("M -60 -30 L 220 -30 L 220 92.5 L -60 148.5 Z")
    lower_leg = pathops.op(lower_leg, foot_cut, pathops.PathOp.INTERSECTION)
    # Locate the branch root on the *actual* diagonal. A fixed x-position can
    # leave its oblique cap just outside a bowed trunk and create a tiny spur.
    low, high = 0.0, 1.0
    desired_y = 87 + join_shift
    for _ in range(32):
        step = (low + high) / 2
        rest = 1 - step
        curve_y = (
            rest**3 * 24
            + 3 * rest**2 * step * c1y
            + 3 * rest * step**2 * c2y
            + step**3 * ey
        )
        if curve_y < desired_y:
            low = step
        else:
            high = step
    step = (low + high) / 2
    rest = 1 - step
    curve_x = (
        rest**3 * 32
        + 3 * rest**2 * step * c1x
        + 3 * rest * step**2 * c2x
        + step**3 * ex
    )
    root_shift = curve_x - (78 + spread * 0.35)
    drawing = union(
        [head, trunk, lower_leg, branch(fork, spread, join_shift, root_shift)], fillet
    )
    # Level body and gently rising foot cut, rather than a rounded pen-cap.
    clip = shape("M -40 -30 L 220 -30 L 220 136.5 L -40 136.5 Z")
    return commands(pathops.op(drawing, clip, pathops.PathOp.INTERSECTION))


def tsadi(body, fork, spread, join_shift, fillet):
    right = {"round": 125, "box": 125, "sweep": 139, "tuck": 111, "ramp": 132}[
        body
    ] + spread * 0.35
    # Each body has its own skeleton and direction through the return, rather
    # than stretching one source contour. Horizontal stroke stays 39.2 units.
    return_paths = {
        "round": (
            f"C 58 66 {right - 7} 73 {right + 1} 102 "
            f"C {right + 5} 116 {right + 3} 127 {right - 1} 133.6 "
            "L 0 133.6 L 1.9 96.4 C 24 98 48 102 70 98.4 "
            "C 45 88 23 64 14.3 40.2 "
        ),
        "box": (
            f"C 69 59 {right - 4} 89 {right - 1} 107 "
            f"L {right - 2} 133.6 L 0 133.6 L 1.9 94.4 L 62 94.4 "
            "C 43 82 23 60 14.3 40.2 "
        ),
        "sweep": (
            f"C 54 70 {right - 7} 65 {right + 6} 99 "
            f"C {right + 14} 117 {right + 1} 133.6 {right - 22} 133.6 "
            "C 72 133.6 22 130 -12 133.6 L -10 98 "
            "C 24 94 62 104 83 98 "
            "C 46 87 22 65 14.3 40.2 "
        ),
        "tuck": (
            f"C 51 73 {right - 12} 80 {right - 4} 101 "
            f"Q {right + 9} 119 {right - 4} 133.6 "
            "L 18 133.6 L 19.9 94.4 L 60 94.4 "
            "C 40 82 18 66 14.3 40.2 "
        ),
        "ramp": (
            f"C 50 74 {right - 11} 65 {right + 4} 103 "
            f"C {right + 10} 119 {right + 1} 128 {right - 14} 129 "
            "L -5 133.6 L -3 96.4 L 76 92 "
            "C 47 81 20 67 14.3 40.2 "
        ),
    }
    outer_tangent, inner_tangent = {
        "round": ((7.2, 25.6), (-8.7, -23.8)),
        "box": ((18.2, 18.6), (-8.7, -19.8)),
        "sweep": ((3.2, 29.6), (-7.7, -24.8)),
        "tuck": ((0.2, 32.6), (-3.7, -25.8)),
        "ramp": ((-0.8, 33.6), (-5.7, -26.8)),
    }[body]
    trunk = shape(
        left_entry(outer_tangent) + return_paths[body] + left_return(inner_tangent)
    )
    root_shift = {"tuck": -13, "sweep": 10}.get(body, 0)
    return commands(
        union([trunk, branch(fork, spread, join_shift, root_shift)], fillet)
    )


def generate():
    letters = {"א": [], "צ": []}
    for number, study in enumerate(STUDIES, 1):
        name, note, main, leg, fork, body, spread, join_shift, fillet = study
        for ch, prefix, path in (
            ("א", "A", alef(main, leg, fork, spread, join_shift, fillet)),
            ("צ", "C", tsadi(body, fork, spread, join_shift, fillet)),
        ):
            detail = (
                note
                if ch == "א"
                else note.replace("ורגל", "וחזרה")
                .replace("רגל", "חזרה")
                .replace("לרגל", "לחזרה")
            )
            letters[ch].append(
                {
                    "id": f"{prefix}{number:02}",
                    "name": name,
                    "note": detail,
                    "paths": [path],
                }
            )
    target = ROOT / "sources/yehuda/alternatives/alef-tsadi.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps({"letters": letters}, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    # Ignored large-glyph contact sheet for local visual inspection.
    svg = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="1280" height="1380" viewBox="0 0 1280 1380">',
        '<rect width="1280" height="1380" fill="#f3f6fa"/>',
    ]
    for row, ch in enumerate(("א", "צ")):
        for index, item in enumerate(letters[ch]):
            x = 16 + (index % 5) * 252
            y = 12 + row * 688 + (index // 5) * 170
            svg.append(
                f'<rect x="{x}" y="{y}" width="240" height="160" rx="10" fill="white"/>'
            )
            svg.append(
                f'<text x="{x + 14}" y="{y + 23}" fill="#536b87" font-family="sans-serif" font-size="15">{item["id"]}</text>'
            )
            svg.append(
                f'<g transform="translate({x + 52} {y + 20}) scale(.9)" fill="#173d76"><path d="{item["paths"][0]}"/></g>'
            )
    svg.append("</svg>")
    proof = ROOT / "build/alternatives-alef-tsadi.svg"
    proof.parent.mkdir(exist_ok=True)
    proof.write_text("\n".join(svg), encoding="utf-8", newline="\n")
    print("Generated20alef+20tsadi review-only variants; canonical masters unchanged")


if __name__ == "__main__":
    generate()
