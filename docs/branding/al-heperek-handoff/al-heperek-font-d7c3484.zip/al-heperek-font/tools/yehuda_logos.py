"""Outline every logo run from the compiled Yehuda cut; no system fonts.

The editable layouts contain only project-owned book artwork, tile geometry
and text placement boxes. Fonts are read from this repository's locked build.
"""

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from fontTools.pens.boundsPen import BoundsPen
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.ttLib import TTFont
import uharfbuzz as hb

ROOT = Path(__file__).resolve().parents[1]
LAYOUTS = ROOT / "sources/yehuda/logo-layouts"
OUTPUT = ROOT / "dist/yehuda/logos"
NS = "{http://www.w3.org/2000/svg}"
LABELS = {
    "wordmark": "על הפרק",
    "tanakh": 'תנ"ך',
    "al": "על",
    "haperek": "הפרק",
    "tav": "ת",
}
ET.register_namespace("", NS[1:-1])


def digest(data):
    return hashlib.sha256(data).hexdigest()


class Lettering:
    def __init__(self, path):
        self.data = path.read_bytes()
        self.font = TTFont(path)
        self.glyphs = self.font.getGlyphSet()
        self.order = self.font.getGlyphOrder()
        self.shaper = hb.Font(hb.Face(self.data))
        hb.ot_font_set_funcs(self.shaper)

    def run(self, text):
        buffer = hb.Buffer()
        buffer.add_str(text)
        buffer.direction, buffer.script, buffer.language = "rtl", "Hebr", "he"
        hb.shape(self.shaper, buffer, {"kern": True, "mark": True, "ss03": True})
        svg, bounds = SVGPathPen(self.glyphs), BoundsPen(self.glyphs)
        cursor = 0
        for info, p in zip(buffer.glyph_infos, buffer.glyph_positions):
            name = self.order[info.codepoint]
            assert name != ".notdef", text
            if 0x05D0 <= ord(text[info.cluster]) <= 0x05EA:
                assert name.endswith(".ss03"), (text, name)
            matrix = (1, 0, 0, -1, cursor + p.x_offset, -p.y_offset)
            self.glyphs[name].draw(TransformPen(svg, matrix))
            self.glyphs[name].draw(TransformPen(bounds, matrix))
            cursor += p.x_advance
        assert bounds.bounds, text
        return svg.getCommands(), bounds.bounds

    def fit(self, element):
        run = element.get("data-run")
        text = LABELS[run]
        x, y, width, height = map(float, element.get("data-box").split())
        path, (left, top, right, bottom) = self.run(text)
        scale = min(width / (right - left), height / (bottom - top))
        dx = x - (right + left) * scale / 2
        dy = y - (top + bottom) * scale / 2
        color = element.get("fill")
        assert not list(element), "Layout placeholders must contain no old lettering"
        element.attrib.clear()
        element.set("aria-label", text)
        element.set("transform", f"translate({dx:.5f} {dy:.5f}) scale({scale:.8f})")
        element.set("fill", color)
        element.set("data-run", run)
        ET.SubElement(element, NS + "path", {"d": path})


def generate():
    font_path = ROOT / "dist/ttf/AlHeperek-Bold.ttf"
    build = json.loads((ROOT / "dist/manifest.json").read_text(encoding="utf-8"))
    data = font_path.read_bytes()
    record = next(
        f for f in build["files"] if f["file"] == "dist/ttf/AlHeperek-Bold.ttf"
    )
    assert digest(data) == record["sha256"], "Build the source fonts first"
    face = Lettering(font_path)
    provenance = {
        "sourceRepository": "https://github.com/bible-on-site/al-heperek-font",
        "fontVersion": build["version"],
        "fontSha256": digest(data),
        "weight": 700,
        "feature": "ss03",
        "generatedBy": "tools/yehuda_logos.py",
    }
    OUTPUT.mkdir(parents=True, exist_ok=True)
    drawings, layouts = {}, []
    for template in sorted(LAYOUTS.glob("*.svg")):
        raw = template.read_bytes()
        root = ET.fromstring(raw)
        for element in root.iter():
            if element.get("data-run"):
                face.fit(element)
        metadata = ET.Element(NS + "metadata")
        metadata.text = json.dumps(provenance, ensure_ascii=False, sort_keys=True)
        root.insert(0, metadata)
        drawings[template.name] = root
        layouts.append(
            {
                "file": str(template.relative_to(ROOT)).replace("\\", "/"),
                "sha256": digest(raw),
            }
        )
    # At 24px use exactly the 32px composition. Only viewport dimensions change.
    small = deepcopy(drawings["favicon-32.svg"])
    small.set("width", "24")
    small.set("height", "24")
    drawings["favicon-24.svg"] = small
    files = []
    for name, root in sorted(drawings.items()):
        raw = ET.tostring(root, encoding="utf-8", xml_declaration=True) + b"\n"
        assert b"<text" not in raw and b"data-box" not in raw
        (OUTPUT / name).write_bytes(raw)
        files.append(
            {"file": name, "sha256": digest(raw), "viewBox": root.get("viewBox")}
        )
    manifest = provenance | {"layouts": layouts, "files": files}
    (OUTPUT / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(f"Outlined {len(files)} logos from Al Heperek {build['version']} Bold / ss03")


if __name__ == "__main__":
    generate()
