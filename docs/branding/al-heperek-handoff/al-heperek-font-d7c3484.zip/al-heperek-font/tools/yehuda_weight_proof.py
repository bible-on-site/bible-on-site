"""Compare compiled Hebrew strokes and figures before and after weight fitting."""

from pathlib import Path
import subprocess
from specimen import outlined

ROOT = Path(__file__).resolve().parents[1]
PREVIOUS = "a3adba025ce4802daa2c41a23a0c5c3eb4fd1353"


def generate():
    before = ROOT / "build/weight-before"
    before.mkdir(parents=True, exist_ok=True)
    for style in ("Regular", "SemiBold", "Bold"):
        name = f"AlHeperek-{style}.ttf"
        (before / name).write_bytes(
            subprocess.check_output(
                ["git", "show", f"{PREVIOUS}:dist/ttf/{name}"], cwd=ROOT
            )
        )
    out = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="1440" height="1160" viewBox="0 0 1440 1160">',
        '<rect width="1440" height="1160" fill="#faf9f5"/>',
        '<path stroke="#cdd5df" d="M720 35V1120 M50 370H1390 M50 690H1390 M50 1010H1390"/>',
    ]
    for right, directory, label in (
        (670, before, "0.9.1 / Before"),
        (1390, ROOT / "dist/ttf", "0.9.2 / After"),
    ):
        out.append(
            outlined(
                directory / "AlHeperek-Regular.ttf",
                label,
                right,
                65,
                25,
                "#426288",
                align="right",
                direction="ltr",
            )
        )
        for style, weight, y in (
            ("Bold", 700, 105),
            ("SemiBold", 600, 425),
            ("Regular", 400, 745),
        ):
            file = directory / f"AlHeperek-{style}.ttf"
            out.append(
                outlined(
                    file,
                    f"{style} {weight}",
                    right,
                    y,
                    21,
                    "#426288",
                    align="right",
                    direction="ltr",
                    feature="ss03",
                )
            )
            out.append(
                outlined(
                    file,
                    "ר א צ ץ ג ע ש",
                    right,
                    y + 115,
                    82,
                    "#183461",
                    align="right",
                    direction="rtl",
                    feature="ss03",
                )
            )
            out.append(
                outlined(
                    file,
                    "0123456789",
                    right,
                    y + 225,
                    76,
                    "#183461",
                    align="right",
                    direction="ltr",
                    feature="ss03",
                )
            )
        out.append(
            outlined(
                directory / "AlHeperek-Regular.ttf",
                "בכל יום נפתח פרק חדש ונלמד יחד.",
                right,
                1080,
                32,
                "#183461",
                align="right",
                direction="rtl",
                feature="ss03",
            )
        )
    out.append("</svg>")
    (ROOT / "specimens/yehuda-weight.svg").write_text(
        "\n".join(out) + "\n", encoding="utf-8", newline="\n"
    )
    print("Generated actual-font stroke and digit comparison for 0.9.1 / 0.9.2")


if __name__ == "__main__":
    generate()
