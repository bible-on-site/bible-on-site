"""Export the unapproved SVG study under its own installable family name."""

from export_ui import export_ui


if __name__ == "__main__":
    export_ui(
        cut="ss03",
        family="Al Heperek Yehuda Study",
        stem="AlHeperekYehuda",
        directory="yehuda",
        extra_codepoints=tuple(range(0x30, 0x3A)),
    )
