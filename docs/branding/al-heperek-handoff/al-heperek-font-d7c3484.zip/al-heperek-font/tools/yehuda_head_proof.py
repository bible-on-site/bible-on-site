"""Compare the same proposals before/after balancing only their left heads."""

import argparse
import json
from pathlib import Path
import subprocess
import sys

import pathops
from fontTools.svgLib.path import parse_path
from fontTools.ttLib import TTFont

from specimen import outlined
from yehuda_alternatives import (
    FONT,
    compile_proposal,
    original_glyphs,
    shaped_runs,
    word_paths,
)

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
BEFORE = ROOT / "sources/yehuda/review-reference/left-head-before.json"
SOURCES = ("alef-tsadi", "ayin-tet", "shin")


def current_letters():
    result = {}
    for name in SOURCES:
        result.update(
            json.loads(
                (ROOT / f"sources/yehuda/alternatives/{name}.json").read_text(
                    encoding="utf-8"
                )
            )["letters"]
        )
    return result


def drawing(paths):
    result = pathops.Path()
    for raw in paths:
        path = pathops.Path()
        parse_path(raw, path.getPen())
        result.addPath(path)
    return pathops.simplify(result, clockwise=False)


def rectangle(left, top, right, bottom):
    path = pathops.Path()
    parse_path(f"M{left} {top}H{right}V{bottom}H{left}Z", path.getPen())
    return path


def verify_scope(revision):
    """Measure actual outline differences, not just authoring parameters."""
    current = current_letters()
    head_window = rectangle(-40, -30, 60, 40)
    body_window = rectangle(-100, 45, 300, 200)
    report = []
    for name in SOURCES:
        old = json.loads(
            subprocess.check_output(
                ["git", "show", f"{revision}:sources/yehuda/alternatives/{name}.json"],
                cwd=ROOT,
            )
        )["letters"]
        for ch, entries in old.items():
            for before, after in zip(entries, current[ch], strict=True):
                assert before["id"] == after["id"]
                previous, revised = drawing(before["paths"]), drawing(after["paths"])
                difference = pathops.op(previous, revised, pathops.PathOp.XOR)
                lower = pathops.op(difference, body_window, pathops.PathOp.INTERSECTION)
                before_head = pathops.op(
                    previous, head_window, pathops.PathOp.INTERSECTION
                )
                after_head = pathops.op(
                    revised, head_window, pathops.PathOp.INTERSECTION
                )
                changed_body = abs(lower.area)
                assert changed_body < 0.1, (after["id"], changed_body)
                assert abs(after_head.area) < abs(before_head.area), after["id"]
                report.append(
                    {
                        "id": after["id"],
                        "headInkBefore": abs(before_head.area),
                        "headInkAfter": abs(after_head.area),
                        "changedBodyAreaBelow45": changed_body,
                    }
                )
    assert len(report) == 100
    target = ROOT / "build/head-balance-scope.json"
    target.parent.mkdir(exist_ok=True)
    target.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print("100 proposals: reduced left-head ink; bodies below y=45 preserved")


def raw_glyph(paths, x, y, scale=1, highlight=False):
    art = "".join(f'<path d="{p}"/>' for p in paths)
    result = (
        f'<g transform="translate({x} {y}) scale({scale})" fill="#193e76">{art}</g>'
    )
    if highlight:
        # Exact same outline, with only the discussed region picked out.
        result += (
            f'<svg x="{x}" y="{y - 20 * scale}" width="{65 * scale}" '
            f'height="{65 * scale}" viewBox="0 -20 65 65" fill="#245edb">{art}</svg>'
        )
    return result


def generate():
    from al_heperek.yehuda_hebrew import native_letters

    before = json.loads(BEFORE.read_text(encoding="utf-8"))["letters"]
    after = current_letters()
    glyphs = original_glyphs(TTFont(FONT))
    runs = shaped_runs(TTFont(FONT), glyphs)
    out = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="1400" height="1080" viewBox="0 0 1400 1080" role="img">',
        "<title>אותן חלופות - ראש שמאלי קטן יותר, יתר המבנה נשמר</title>",
        '<rect width="1400" height="1080" fill="#f3f5f8"/>',
        outlined(
            FONT,
            "ראש שמאלי מאוזן",
            1350,
            65,
            36,
            "#193e76",
            "right",
            "rtl",
            feature="ss03",
        ),
        outlined(
            FONT,
            "כחול - אזור התיקון",
            50,
            65,
            23,
            "#245edb",
            direction="rtl",
            feature="ss03",
        ),
    ]
    for label, entries, x in (("לפני", before, 240), ("אחרי", after, 930)):
        out.append(
            outlined(
                FONT, label, x + 95, 113, 30, "#63738b", "center", "rtl", feature="ss03"
            )
        )
        item = entries["א"][0]
        out.append(raw_glyph(item["paths"], x, 140, 1.45, True))
        proposal = compile_proposal(item, "א")
        out.append(word_paths("ארץ", glyphs, {"א": proposal}, runs, 58, x + 95, 417))
    out.append('<path d="M40 460H1360" stroke="#d6dfea"/>')
    for index, ch in enumerate("עטצש"):
        x = 40 + index * 340
        out.append(
            outlined(
                FONT, ch, x + 155, 505, 30, "#63738b", "center", "rtl", feature="ss03"
            )
        )
        for entries, dx in ((before, 10), (after, 165)):
            out.append(raw_glyph(entries[ch][0]["paths"], x + dx, 540, 0.79, True))
        for label, dx in (("לפני", 65), ("אחרי", 225)):
            out.append(
                outlined(
                    FONT,
                    label,
                    x + dx,
                    690,
                    20,
                    "#63738b",
                    "center",
                    "rtl",
                    feature="ss03",
                )
            )
    out.append('<path d="M40 725H1360" stroke="#d6dfea"/>')
    out.append(
        outlined(
            FONT,
            "שאר האותיות - ללא שינוי",
            700,
            780,
            28,
            "#63738b",
            "center",
            "rtl",
            feature="ss03",
        )
    )
    references = native_letters()
    for x, ch in ((300, "ת"), (650, "ה"), (1000, "ח")):
        out.append(raw_glyph(references[ch], x, 835, 1.45, True))
    out.append("</svg>")
    target = ROOT / "specimens/alternatives/head-balance.svg"
    target.write_text("\n".join(out) + "\n", encoding="utf-8", newline="\n")
    print("Rendered exact before/after outlines and unchanged reference letters")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify-scope", metavar="BEFORE_COMMIT")
    args = parser.parse_args()
    generate()
    if args.verify_scope:
        verify_scope(args.verify_scope)
