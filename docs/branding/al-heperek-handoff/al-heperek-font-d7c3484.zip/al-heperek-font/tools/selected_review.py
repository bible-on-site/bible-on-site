"""Build a separate Bold review face from the five exact user selections.

Canonical UFOs and existing font exports are read-only. Quadratic turns are
promoted exactly to cubic curves; the CFF review face keeps the authored nodes.
"""

from copy import deepcopy
import hashlib
import html
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
from urllib.parse import urlencode

from fontTools.pens.basePen import BasePen
from fontTools.pens.recordingPen import RecordingPen
from fontTools.svgLib.path import parse_path
from fontTools.ttLib import TTFont
from ufoLib2 import Font

from build import EPOCH
from specimen import outlined
from yehuda_logos import LAYOUTS, Lettering, NS
from yehuda_refinements import ALPHABET, DIGITS, FONT, compile_native

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "dist/selected"
RECIPE = ROOT / "sources/yehuda/selected-refinements.json"
FAMILY = "Al Heperek Selected Review"
STEM = "AlHeperekSelected-Bold"


class ExactCubicPen(BasePen):
    """Elevate each quadratic's degree exactly; never fit or add anchors."""

    def __init__(self, destination):
        super().__init__(None)
        self.destination = destination

    def _moveTo(self, point):
        self.destination.moveTo(point)

    def _lineTo(self, point):
        self.destination.lineTo(point)

    def _curveToOne(self, first, second, end):
        self.destination.curveTo(first, second, end)

    def _qCurveToOne(self, control, end):
        start = self._getCurrentPoint()
        first = tuple(a + 2 * (b - a) / 3 for a, b in zip(start, control))
        second = tuple(a + 2 * (b - a) / 3 for a, b in zip(end, control))
        self.destination.curveTo(first, second, end)

    def _closePath(self):
        self.destination.closePath()

    def _endPath(self):
        self.destination.endPath()


def digest_tree(directory):
    digest = hashlib.sha256()
    for path in sorted(directory.rglob("*")):
        if path.is_file():
            digest.update(path.relative_to(directory).as_posix().encode())
            digest.update(b"\0")
            digest.update(path.read_bytes())
    return digest.hexdigest()


def load_selection():
    recipe = json.loads(RECIPE.read_text(encoding="utf-8"))
    assert recipe["weight"] == 700
    available = {}
    for source in sorted((ROOT / "sources/yehuda/refinements").glob("*.json")):
        for ch, entries in json.loads(source.read_text(encoding="utf-8"))[
            "letters"
        ].items():
            available[ch] = {entry["id"]: entry for entry in entries}
    selected = {ch: available[ch][code] for ch, code in recipe["choices"].items()}
    assert set(selected) == set("אעטצש")
    assert recipe["finalTsadiFrom"] == selected["צ"]["id"]
    companion = selected["צ"]["companion"]
    selected["ץ"] = companion | {"id": selected["צ"]["id"] + "-final"}
    return recipe, selected


def replace_glyph(font, ch, entry):
    compiled = compile_native(entry, ch)
    name = f"uni{ord(ch):04X}.ss03"
    original = font[name]
    old_anchors = deepcopy(original.anchors)
    del font[name]
    glyph = font.newGlyph(name)
    parse_path(compiled["path"], ExactCubicPen(glyph.getPen()))
    glyph.width = compiled["advance"]
    middle = glyph.width / 2
    for anchor in old_anchors:
        anchor.x = (
            glyph.width - 90
            if anchor.name == "shin"
            else compiled["bounds"][0] + 80
            if anchor.name == "sin"
            else middle
        )
        glyph.appendAnchor(anchor)
    return compiled


def validate_compiled(font, selected):
    assert font["OS/2"].usWeightClass == 700
    assert font["name"].getDebugName(1) == FAMILY
    assert font["name"].getDebugName(6) == STEM
    assert font["CFF "].cff.fontNames == [STEM]
    glyphs = font.getGlyphSet()
    cmap = font.getBestCmap()
    assert not set(range(0x0591, 0x05B0)).intersection(cmap)
    report = {}
    for ch, entry in selected.items():
        compiled = compile_native(entry, ch)
        expected = RecordingPen()
        parse_path(compiled["path"], ExactCubicPen(expected))
        actual = RecordingPen()
        name = f"uni{ord(ch):04X}.ss03"
        assert cmap[ord(ch)] == name
        glyphs[name].draw(actual)
        # SVG spells out the last edge to the start; CFF closes it implicitly.
        if expected.value[-2] == ("lineTo", expected.value[0][1]):
            expected.value.pop(-2)
        assert [op for op, _ in expected.value] == [op for op, _ in actual.value], ch
        actual_anchors = sum(
            op in ("moveTo", "lineTo", "curveTo") for op, _ in actual.value
        )
        assert actual_anchors == compiled["metrics"]["anchors"], ch
        maximum = 0
        for (_, before), (_, after) in zip(expected.value, actual.value):
            assert len(before) == len(after)
            for first, second in zip(before, after):
                maximum = max(maximum, *(abs(a - b) for a, b in zip(first, second)))
        assert maximum < 0.001, (ch, maximum)
        report[ch] = {
            "selection": entry["id"],
            "authoredAnchors": compiled["metrics"]["anchors"],
            "compiledAnchors": actual_anchors,
            "maximumCoordinateError": maximum,
            "sourcePathSha256": hashlib.sha256(entry["paths"][0].encode()).hexdigest(),
        }
    for ch in "אבגדהוזחטיכלמנסעפצקרשתךםןףץ0123456789":
        assert cmap[ord(ch)] == f"uni{ord(ch):04X}.ss03"
    return report


def build_review():
    recipe, selected = load_selection()
    source = ROOT / "sources/AlHeperek-Bold.ufo"
    original_digest = digest_tree(source)
    build = ROOT / "build"
    build.mkdir(exist_ok=True)
    signature = "-".join(recipe["choices"].values())
    environment = os.environ | {"SOURCE_DATE_EPOCH": str(EPOCH), "PYTHONHASHSEED": "0"}
    with tempfile.TemporaryDirectory(prefix="selected-review-", dir=build) as temporary:
        temporary = Path(temporary).resolve()
        assert temporary.is_relative_to(build.resolve())
        master, binary = (
            temporary / "Selected-Bold.ufo",
            temporary / "Selected-Bold.otf",
        )
        with Font.open(source) as font:
            for ch, entry in selected.items():
                replace_glyph(font, ch, entry)
            font.info.familyName = FAMILY
            font.info.styleName = "Bold"
            font.info.styleMapFamilyName = FAMILY
            font.info.styleMapStyleName = "bold"
            font.info.openTypeNamePreferredFamilyName = FAMILY
            font.info.openTypeNamePreferredSubfamilyName = "Bold"
            font.info.openTypeNameUniqueID = f"DoradSoft:{STEM}:0.9.2:{signature}"
            font.info.postscriptFontName = STEM
            font.info.postscriptFullName = FAMILY + " Bold"
            font.save(master)
        subprocess.run(
            [
                sys.executable,
                "-m",
                "fontmake",
                "-u",
                str(master),
                "-o",
                "otf",
                "--output-path",
                str(binary),
                "--keep-overlaps",
                "--keep-direction",
                "--cff-round-tolerance",
                "0",
                "--optimize-cff",
                "0",
                "--validate-ufo",
                "--verbose",
                "WARNING",
            ],
            check=True,
            cwd=ROOT,
            env=environment,
        )
        face = TTFont(binary, recalcTimestamp=False)
        for table in face["cmap"].tables:
            if table.isUnicode():
                for cp in (*range(0x05D0, 0x05EB), *range(0x30, 0x3A)):
                    table.cmap[cp] = f"uni{cp:04X}.ss03"
        face["head"].created = face["head"].modified = EPOCH + 2082844800
        files = []
        for extension, flavor in (("otf", None), ("woff2", "woff2")):
            destination = OUTPUT / extension / f"{STEM}.{extension}"
            destination.parent.mkdir(parents=True, exist_ok=True)
            face.flavor = flavor
            face.save(destination, reorderTables=True)
            files.append(
                {
                    "file": destination.relative_to(ROOT).as_posix(),
                    "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
                }
            )
        face.close()
    assert original_digest == digest_tree(source), (
        "The canonical master must stay untouched"
    )
    with TTFont(OUTPUT / "otf" / f"{STEM}.otf") as face:
        report = validate_compiled(face, selected)
    with TTFont(OUTPUT / "woff2" / f"{STEM}.woff2") as face:
        assert report == validate_compiled(face, selected)
    (OUTPUT / "LICENSE.txt").write_bytes((ROOT / "LICENSE").read_bytes())
    manifest = {
        "family": FAMILY,
        "weight": 700,
        "status": "combined selection review, not a production font",
        "choices": recipe["choices"],
        "finalTsadiFrom": recipe["finalTsadiFrom"],
        "canonicalMasterSha256": original_digest,
        "glyphs": report,
        "files": files,
    }
    (OUTPUT / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(
        f"Built separate Bold review face: {signature}; exact node sequences retained for all six selected forms"
    )
    return manifest


def review_logos(manifest):
    """Render a separate logo family from this exact review font."""
    destination = OUTPUT / "logos"
    destination.mkdir(exist_ok=True)
    font_path = OUTPUT / "otf" / f"{STEM}.otf"
    lettering = Lettering(font_path)
    drawings = {}
    for template in sorted(LAYOUTS.glob("*.svg")):
        if template.name.startswith("header-logo"):
            root = ET.parse(
                ROOT / "sources/yehuda/alternatives/wide-logo.svg"
            ).getroot()
            if "reversed" in template.name:
                for element in root.iter():
                    if element.get("data-run"):
                        element.set("fill", "#F4F9FF")
                    else:
                        for attr in ("fill", "stroke"):
                            color = element.get(attr)
                            if color in {"#143C98", "#1E66E8"}:
                                element.set(
                                    attr,
                                    {"#143C98": "#C6DFFF", "#1E66E8": "#65A5FF"}[color],
                                )
        else:
            root = ET.parse(template).getroot()
        for element in root.iter():
            if element.get("data-run"):
                lettering.fit(element)
        metadata = ET.Element(NS + "metadata")
        metadata.text = json.dumps(
            {
                "family": FAMILY,
                "weight": 700,
                "choices": manifest["choices"],
                "fontSha256": manifest["files"][0]["sha256"],
                "stage": "combined selection review",
            },
            ensure_ascii=False,
            sort_keys=True,
        )
        root.insert(0, metadata)
        drawings[template.name] = root
    small = deepcopy(drawings["favicon-32.svg"])
    small.set("width", "24")
    small.set("height", "24")
    drawings["favicon-24.svg"] = small
    outputs = []
    for name, root in sorted(drawings.items()):
        raw = ET.tostring(root, encoding="utf-8", xml_declaration=True) + b"\n"
        assert b"<text" not in raw and b"data-box" not in raw
        (destination / name).write_bytes(raw)
        outputs.append({"file": name, "sha256": hashlib.sha256(raw).hexdigest()})
    (destination / "manifest.json").write_text(
        json.dumps(
            {
                "choices": manifest["choices"],
                "fontSha256": manifest["files"][0]["sha256"],
                "files": outputs,
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(
        f"Rendered {len(outputs)} separate review logos, with one wordmark plus the book in the wide layout"
    )


def review_specimen(manifest):
    selected_font = OUTPUT / "otf" / f"{STEM}.otf"
    out = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="1500" height="1080" viewBox="0 0 1500 1080" role="img">',
        "<title>A22 E26 T21 C28 S35 - combined Bold font review</title>",
        '<rect width="1500" height="1080" fill="#f4f6fa"/>',
        outlined(
            selected_font, "הבחירה המשולבת", 1440, 73, 42, "#193e76", "right", "rtl"
        ),
        outlined(selected_font, "A22 / E26 / T21 / C28 / S35", 60, 73, 23, "#61718a"),
    ]
    for index, ch in enumerate("אעטצץש"):
        x = 1310 - index * 230
        out.append(outlined(selected_font, ch, x, 260, 164, "#245edb", "center", "rtl"))
        code = manifest["choices"].get(ch, manifest["finalTsadiFrom"] + " / final")
        out.append(outlined(selected_font, code, x, 327, 21, "#61718a", "center"))
    for path, title, baseline in (
        (FONT, "הגרסה הנוכחית באתר", 402),
        (selected_font, "הבחירה המשולבת", 617),
    ):
        out.append(
            outlined(
                selected_font, title, 1440, baseline, 26, "#61718a", "right", "rtl"
            )
        )
        if path == selected_font:
            out.append(outlined(selected_font, "Bold 700", 60, baseline, 26, "#61718a"))
        out.append(
            outlined(
                path,
                ALPHABET,
                1440,
                baseline + 87,
                43,
                "#193e76",
                "right",
                "rtl",
                feature="ss03",
            )
        )
        out.append(
            outlined(
                path,
                DIGITS,
                1440,
                baseline + 143,
                43,
                "#193e76",
                "right",
                "ltr",
                feature="ss03",
            )
        )
    for text, baseline, size in (
        ("אוצר של עצה, ציון ושלום", 866, 51),
        ("בכל יום נפתח פרק חדש, נשאל ונלמד יחד.", 941, 34),
        ("שָׁלוֹם, עֵצָה, לְךָ, אֶרֶץ.", 1017, 32),
    ):
        out.append(
            outlined(
                selected_font, text, 1440, baseline, size, "#193e76", "right", "rtl"
            )
        )
    out.append("</svg>")
    (ROOT / "specimens/selected.svg").write_text(
        "\n".join(out) + "\n", encoding="utf-8", newline="\n"
    )


def review_page(manifest):
    page = (ROOT / "tools/selected_review.html").read_text(encoding="utf-8")
    payload = json.dumps(manifest, ensure_ascii=False, separators=(",", ":")).replace(
        "<", "\\u003c"
    )
    web_hash = next(
        entry["sha256"]
        for entry in manifest["files"]
        if entry["file"].endswith(".woff2")
    )
    tiles = []
    for ch in "אעטצץש":
        code = manifest["choices"].get(ch, manifest["finalTsadiFrom"] + " / final")
        tiles.append(
            f'<div class="choice"><div class="review">{ch}</div><div class="code">{html.escape(code)}</div></div>'
        )
    choice_url = "refinements.html#" + urlencode({"letter": "צ"} | manifest["choices"])
    replacements = {
        "__FONT_HASH__": web_hash[:16],
        "__DATA__": payload,
        "__TILES__": "".join(tiles),
        "__CHOICES__": html.escape(", ".join(manifest["choices"].values())),
        "__FINAL_SOURCE__": manifest["finalTsadiFrom"],
        "__CHOICE_URL__": html.escape(choice_url, quote=True),
    }
    for token, value in replacements.items():
        page = page.replace(token, value)
    (ROOT / "specimens/selected.html").write_text(page, encoding="utf-8", newline="\n")


if __name__ == "__main__":
    selected_manifest = build_review()
    review_logos(selected_manifest)
    review_specimen(selected_manifest)
    review_page(selected_manifest)
