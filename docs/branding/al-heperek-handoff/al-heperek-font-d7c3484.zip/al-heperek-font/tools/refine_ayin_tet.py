"""Draw low-node review outlines near E09 and T07, without editing font masters.

Each drawing is one explicitly traced cubic perimeter. No stroke expansion,
offset, Boolean operation or outline simplification contributes drawing data.
Curve handles align at smooth joins; the lifted entry and cut terminals keep
their intentional corners. Native body height is 133.6 units.
"""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def number(value):
    return f"{value:.3f}".rstrip("0").rstrip(".")


def drawing(commands):
    return " ".join(
        verb + (" " + " ".join(number(v) for v in values) if values else "")
        for verb, *values in commands
    )


def entry():
    # The balanced entry is traced directly into its upright. The last handle
    # is vertical, matching both letters' first body handle exactly.
    return [
        ("M", 24.2, -5.8),
        ("L", 27.6, -2.2),
        ("C", 29.2, -0.8, 31.5, 0, 34.2, 0),
        ("L", 39.2, 0),
        ("C", 45.4, 0, 49.2, 17.2, 49.2, 34),
    ]


# name, note, outer right x, beginning of turn, counter join x/y,
# lower bowl's horizontal tangent x, left return x, foot's inner turn x,
# upper arm's second handle x/y. All variants retain E09's same architecture.
AYIN = [
    (
        "זרימה מאוזנת",
        "קשת ימנית ארוכה ומפגש פנימי מעוגל במרכז התנועה.",
        140.4,
        47,
        83,
        91,
        76,
        0,
        32,
        67,
        75,
    ),
    (
        "מפגש מוקדם",
        "המפגש עולה מעט והקשת הימנית נפתחת מוקדם יותר.",
        141,
        43,
        81,
        87,
        76,
        0,
        31,
        65,
        71,
    ),
    (
        "מפגש נמוך",
        "זרוע פנימית ארוכה יותר נוחתת נמוך מול דופן רגועה.",
        141.5,
        52,
        87,
        96,
        78,
        1,
        34,
        71,
        80,
    ),
    (
        "תנופה ארוכה",
        "הקערה מתמשכת ימינה ומאזנת זרוע פנימית פתוחה.",
        144,
        44,
        88,
        91,
        79,
        0,
        34,
        72,
        75,
    ),
    (
        "קשת מתוחה",
        "אלכסון שמאלי מתוח וסיבוב ימני אסוף יותר.",
        139.5,
        51,
        84,
        92,
        75,
        1,
        32,
        68,
        76,
    ),
    (
        "ימין רגוע",
        "הדופן נשארת אנכית זמן ארוך יותר לפני החזרה.",
        139,
        58,
        82,
        94,
        77,
        0,
        31,
        66,
        78,
    ),
    (
        "מרווח פתוח",
        "קשת ימנית רחבה לצד זרוע פנימית קצרה יותר.",
        146,
        46,
        83,
        90,
        79,
        1,
        32,
        67,
        74,
    ),
    (
        "פנייה רכה",
        "סיבוב גבוה ומפגש מעוגל מעט שמאלה מן הציר.",
        142,
        41,
        81,
        89,
        77,
        0,
        31,
        65,
        73,
    ),
    (
        "חזרה קצרה",
        "אותו מהלך קמור עם החזרה תחתונה קצרה ומדויקת.",
        141,
        47,
        84,
        91,
        77,
        11,
        34,
        68,
        75,
    ),
    (
        "רצפה נמשכת",
        "החזרה התחתונה ארוכה ומפגש הזרוע נע מעט ימינה.",
        142,
        49,
        88,
        94,
        80,
        -3,
        34,
        72,
        78,
    ),
    (
        "אלכסון נקי",
        "מהלך פנימי ישיר יותר בתוך הקשת הארוכה.",
        141.5,
        48,
        85,
        92,
        77,
        1,
        33,
        69,
        76,
    ),
    (
        "אלכסון קשתי",
        "הזרוע השמאלית מתעגלת בעדינות לפני המפגש.",
        142,
        46,
        84,
        93,
        78,
        0,
        31,
        68,
        77,
    ),
    (
        "חלל מאורך",
        "סיבוב ימני שמתחיל גבוה מול חלל פנימי עמוק.",
        143,
        39,
        87,
        95,
        79,
        0,
        33,
        71,
        79,
    ),
    (
        "מפגש אסוף",
        "קערה מעט צרה יותר ומפגש קרוב למרכז הבסיס.",
        137.5,
        51,
        81,
        92,
        74,
        1,
        30,
        65,
        76,
    ),
    (
        "סיבוב נדיב",
        "דופן רחבה וקשת תחתונה ארוכה סביב מפגש נמוך.",
        146,
        42,
        88,
        95,
        82,
        0,
        34,
        72,
        79,
    ),
    (
        "דופן מתוחה",
        "ימין זקוף יותר עם סיבוב מאוחר והחזרה קצרה.",
        140,
        56,
        84,
        94,
        76,
        5,
        32,
        68,
        78,
    ),
    (
        "פתיחה גבוהה",
        "הקערה נפתחת גבוה והזרוע הפנימית מצטרפת בעדינות.",
        144,
        40,
        83,
        88,
        78,
        1,
        31,
        67,
        72,
    ),
    (
        "בסיס שקט",
        "מפרק פנימי נמוך וקו בסיס ארוך ללא שינויי כיוון קטנים.",
        141.5,
        53,
        85,
        96,
        79,
        0,
        33,
        69,
        80,
    ),
    (
        "תנועה רחבה",
        "גרסה רחבה מעט של אותו קצב, עם אוויר בצד הימני.",
        147,
        47,
        89,
        92,
        82,
        0,
        34,
        73,
        76,
    ),
    (
        "זרימה שקטה",
        "מרווחים מאוזנים וקשת רציפה שמתחילה בגובה ביניים.",
        140.5,
        50,
        82,
        92,
        76,
        1,
        31,
        66,
        76,
    ),
]


def ayin(profile):
    _, _, right, turn, jx, jy, floor_x, toe, foot, arm_x, arm_y = profile
    inner = right - 32.4
    # The counter bottom uses one rounded turn between the diagonal and the
    # inner upright, instead of dozens of fillet/union segments.
    commands = entry() + [
        ("C", 49.2, 53, arm_x, arm_y, jx, jy),
        ("C", jx + 4, jy + 4, jx + 8, jy + 3, jx + 12, jy - 2),
        ("C", jx + 20, jy - 12, inner, turn + 16, inner, turn),
        ("L", inner, 4.8),
        ("L", right - 10.4, 0),
        ("L", right, 0),
        ("L", right, turn),
        ("C", right, turn + 45, floor_x + 36, 133.6, floor_x, 133.6),
        ("L", toe, 133.6),
        ("L", toe + 1.9, 95.2),
        ("C", toe + 16, 95.2, foot - 10, 95.2, foot, 95.2),
        ("C", foot + 6, 95.2, foot + 9, 94.4, foot + 4, 88.4),
        ("C", foot - 6, 76.4, 19.5, 54, 14.3, 40.2),
        ("C", 12.74, 36.06, 10, 33, 10, 28.4),
        ("C", 10, 18.2, 12.3, 8.6, 14.8, -3.6),
        ("Z",),
    ]
    return drawing(commands), len(commands) - 2


# name, note, right edge, inner turn y, short hook centre x and tip y,
# lower bowl centre, inner left bend x/y, outer left bend x/y.
TET = [
    (
        "וו קצר מאוזן",
        "וו פנימי קצר מול קערה רציפה בעלת תחתית רגועה.",
        148.2,
        72,
        106,
        46.8,
        88,
        62,
        89,
        23,
        105,
    ),
    (
        "וו גבוה",
        "הוו נעצר מעט גבוה יותר ומשאיר חלל פתוח מתחתיו.",
        148,
        73,
        106,
        41.5,
        88,
        62,
        89,
        23,
        106,
    ),
    (
        "וו נמוך",
        "אותו וו קצר יורד מעט יותר בתוך הקערה הפתוחה.",
        148.5,
        73,
        106.5,
        49,
        89,
        63,
        89.5,
        24,
        106,
    ),
    (
        "קערה נמשכת",
        "סיבוב ימני ארוך מעט עם חזרה פנימית קצרה ובהירה.",
        151,
        70,
        109,
        46,
        91,
        64,
        89,
        24,
        104,
    ),
    (
        "קערה אסופה",
        "מרווחים אסופים יותר סביב הוו הקצר בלי לסגור את הפתח.",
        146.5,
        74,
        104.5,
        45,
        86,
        61,
        89.5,
        22.5,
        106,
    ),
    (
        "פנייה מוקדמת",
        "הקערה הימנית פונה מעט מוקדם ומוליכה את העין ברצף.",
        149,
        67,
        107,
        45,
        89,
        62,
        88,
        23,
        103,
    ),
    (
        "פנייה נמוכה",
        "דפנות מתוחות יותר וסיבוב תחתון מאוחר סביב הוו הקצר.",
        149,
        79,
        107,
        46,
        89,
        63,
        91,
        24,
        109,
    ),
    (
        "מרווח נדיב",
        "וו מעט ימני יותר וקערה רחבה שפותחת את החלל הפנימי.",
        152,
        72,
        110,
        45.5,
        92,
        64,
        89,
        24,
        105,
    ),
    (
        "זרימה מתוחה",
        "המעבר מהשמאל לבסיס מתוח יותר, לצד וו קצר ורגוע.",
        148.5,
        74,
        106.5,
        44.5,
        88,
        60.5,
        90,
        22,
        106,
    ),
    (
        "זרימה עגולה",
        "שמאל קמור יותר ותחתית עגולה סביב אותו פתח קצר.",
        149.5,
        70,
        107.5,
        47,
        90,
        65,
        88.5,
        25,
        104,
    ),
    (
        "פתח בהיר",
        "הוו נעצר גבוה ונוטה קלות פנימה אל מרכז האות.",
        149,
        72,
        107,
        40.5,
        89,
        63,
        89,
        24,
        105,
    ),
    (
        "פתח שקט",
        "הוו והקערה מתכנסים אל מרכז מאוזן עם זרימה אחידה.",
        147.5,
        74,
        105.5,
        45.5,
        87,
        61,
        90,
        22.5,
        107,
    ),
    (
        "כתף רחבה",
        "הקשת העליונה רחבה מעט והוו נותר קצר ומאופק.",
        151,
        74,
        109.5,
        44,
        91,
        64,
        90,
        24,
        107,
    ),
    (
        "כתף קרובה",
        "קשת עליונה אסופה לצד זרוע שמאלית כמעט אנכית.",
        146.5,
        75,
        104.8,
        47,
        86.5,
        60.5,
        91,
        22,
        108,
    ),
    (
        "קצב עולה",
        "הסיבוב התחתון נפתח מוקדם והוו נעצר גבוה מעט.",
        150,
        68,
        108,
        42.5,
        90,
        64,
        88,
        24,
        103,
    ),
    (
        "קצב נמוך",
        "תחתית רחבה וקשת ימנית זקופה יותר מול וו נמוך קצר.",
        150,
        78,
        108,
        48,
        90.5,
        63,
        91,
        24,
        109,
    ),
    (
        "קערה פתוחה",
        "גרסה מרווחת של הוו הקצר עם החזרה תחתונה ארוכה.",
        153,
        71,
        111,
        46.5,
        93,
        65,
        89,
        25,
        105,
    ),
    (
        "סיבוב מרוכך",
        "המעבר הימני מתחיל בגובה ביניים ומחליק אל הבסיס.",
        149.5,
        75,
        107.5,
        46,
        90,
        63.5,
        90.5,
        24,
        107,
    ),
    (
        "קערה זקופה",
        "שמאל אסוף יותר ודופן ימנית ארוכה, עם פתח קצר ברור.",
        148,
        78,
        106,
        44,
        88,
        60.5,
        91,
        22.5,
        109,
    ),
    (
        "וו רציף",
        "מתיחה מתונה, מרווח מאוזן ומעבר נקי בין הוו לקשת.",
        149,
        72.5,
        107,
        45.8,
        89,
        62.5,
        89.5,
        23.5,
        105.5,
    ),
]


def tet(profile):
    _, _, right, turn, hook, tip_y, base, lx, ly, ox, oy = profile
    inner = right - 32.4
    tip_x = hook - 10.2
    outer_tip_x, outer_tip_y = tip_x - 31.6, tip_y - 5.6
    commands = entry() + [
        ("C", 49.2, 61, lx - 11.4, ly - 9, lx, ly),
        ("C", lx + 5.7, ly + 4.5, base - 11, 94.4, base, 94.4),
        ("C", base + 18, 94.4, inner, turn + 14, inner, turn),
        ("L", inner, 44),
        ("C", inner, 36, hook + 5.2, 32.2, hook, 32.2),
        ("C", hook - 5, 32.2, tip_x + 1.2, tip_y - 11.6, tip_x, tip_y),
        ("L", outer_tip_x, outer_tip_y),
        ("C", outer_tip_x + 2.8, outer_tip_y - 26.2, hook - 24, 0, hook, 0),
        ("C", hook + 26, 0, right, 15.5, right, 44),
        ("L", right, turn),
        ("C", right, turn + 41, base + 37, 133.6, base, 133.6),
        ("C", base - 31, 133.6, ox + 11, oy + 19, ox, oy),
        ("C", ox - 5.5, oy - 9.5, 17, 64, 16.8, 38),
        ("C", 16.74, 30.2, 10, 33, 10, 28.4),
        ("C", 10, 18.2, 12.3, 8.6, 14.8, -3.6),
        ("Z",),
    ]
    return drawing(commands), len(commands) - 2


def generate():
    letters = {"ע": [], "ט": []}
    for ch, prefix, base, profiles, draw in (
        ("ע", "E", "E09", AYIN, ayin),
        ("ט", "T", "T07", TET, tet),
    ):
        for index, profile in enumerate(profiles, 21):
            path, segments = draw(profile)
            letters[ch].append(
                {
                    "id": f"{prefix}{index}",
                    "name": profile[0],
                    "note": profile[1],
                    "base": base,
                    "paths": [path],
                    "segments": segments,
                }
            )
    destination = ROOT / "sources/yehuda/refinements/ayin-tet.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(
            {"basedOn": {"ע": "E09", "ט": "T07"}, "letters": letters},
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
        newline="\n",
    )
    proof = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="1760" viewBox="0 0 1200 1760"><rect width="1200" height="1760" fill="#f3f5f8"/>'
    ]
    for row, ch in enumerate(("ע", "ט")):
        for index, item in enumerate(letters[ch]):
            x = 14 + (index % 5) * 238
            y = 14 + (index // 5) * 216 + row * 872
            proof.append(
                f'<rect x="{x}" y="{y}" width="224" height="202" rx="10" fill="white"/>'
            )
            proof.append(
                f'<text x="{x + 14}" y="{y + 24}" font-family="sans-serif" font-size="16" fill="#63738b">{item["id"]}</text>'
            )
            proof.append(
                f'<path d="{item["paths"][0]}" transform="translate({x + 40} {y + 43})" fill="#193e76"/>'
            )
    proof.append("</svg>")
    (ROOT / "build").mkdir(exist_ok=True)
    (ROOT / "build/refine-ayin-tet.svg").write_text(
        "\n".join(proof) + "\n", encoding="utf-8", newline="\n"
    )
    print(
        "Authored 20 E09 refinements and 20 T07 refinements as direct low-node cubic contours"
    )


if __name__ == "__main__":
    generate()
