"""Generate portable design proofs from the actual compiled original fonts."""
from pathlib import Path
import base64
import hashlib
import html
import json

from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
import uharfbuzz as hb
from motif_proof import generate_motif_proof

ROOT = Path(__file__).resolve().parents[1]


def outlined(font_path, text, x, baseline, size, color='#172B42', align='left', direction=None, poster=False, *, feature=None):
    data = font_path.read_bytes()
    font = TTFont(font_path)
    glyphs, order = font.getGlyphSet(), font.getGlyphOrder()
    shaper = hb.Font(hb.Face(data))
    shaper.scale = (font['head'].unitsPerEm, font['head'].unitsPerEm)
    hb.ot_font_set_funcs(shaper)
    buffer = hb.Buffer()
    buffer.add_str(text)
    buffer.guess_segment_properties()
    if direction:
        buffer.direction = direction
    features = {'kern': True, 'mark': True, 'ss01': poster}
    if feature:
        features[feature] = True
    hb.shape(shaper, buffer, features)
    pen = SVGPathPen(glyphs)
    cursor_x = cursor_y = 0
    for info, position in zip(buffer.glyph_infos, buffer.glyph_positions):
        assert info.codepoint != 0, f'Missing glyph in {text!r}'
        matrix = (1, 0, 0, -1, cursor_x + position.x_offset, -(cursor_y + position.y_offset))
        glyphs[order[info.codepoint]].draw(TransformPen(pen, matrix))
        cursor_x += position.x_advance
        cursor_y += position.y_advance
    scale = size / font['head'].unitsPerEm
    width = cursor_x * scale
    if align == 'right':
        x -= width
    elif align == 'center':
        x -= width / 2
    return f'<g aria-label="{html.escape(text, quote=True)}" transform="translate({x} {baseline}) scale({scale})" fill="{color}"><path d="{pen.getCommands()}"/></g>'


def inscription_proof(destination, fonts):
    sheet = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="1240" height="690" viewBox="0 0 1240 690" role="img">',
        '<title>אות חקוקה לצד על הפרק 0.6</title>',
        '<rect width="1240" height="690" fill="#faf8f2"/>',
        '<path stroke="#c1c6c5" d="M620 32V650 M45 255H1195 M45 508H1195"/>',
    ]
    for right, label, tag in ((1194, 'אות חקוקה', 'ss02'), (574, '0.6', None)):
        sheet.append(outlined(fonts['Regular'], label, right, 63, 32, '#285192', 'right', 'rtl' if tag else 'ltr'))
        for style, text, y, size in (
            ('Bold', 'על הפרק', 195, 124),
            ('SemiBold', 'לומדים יחד', 353, 84),
            ('Regular', 'אצלנו בארץ', 455, 60),
            ('Regular', 'עצה   אוצר   שחר', 577, 37),
            ('Regular', 'עַל הַפֶּרֶק', 641, 37),
        ):
            sheet.append(outlined(fonts[style], text, right, y, size, '#192e46',
                                  'right', 'rtl', feature=tag))
    sheet.append('</svg>')
    (destination / 'inscription.svg').write_text('\n'.join(sheet) + '\n', encoding='utf-8', newline='\n')


def generate():
    destination = ROOT / 'specimens'
    destination.mkdir(exist_ok=True)
    version = json.loads((ROOT / 'sources/metrics.json').read_text())['version']
    fonts = {name: ROOT / 'dist/ttf' / f'AlHeperek-{name}.ttf' for name in ('Regular', 'SemiBold', 'Bold')}
    regular, semibold, bold = (fonts[name] for name in fonts)
    generate_motif_proof(destination, fonts, outlined, version)
    inscription_proof(destination, fonts)
    body = ['<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="1580" viewBox="0 0 1200 1580"><rect width="1200" height="1580" fill="#F5F4EF"/>']

    def text(value, x, baseline, size=24, font=regular, align='left', direction='ltr', color='#172B42'):
        body.append(outlined(font, value, x, baseline, size, color, align, direction))

    def line(y):
        body.append(f'<path d="M64 {y}H1136" stroke="#CED1CA"/>')

    text(f'Al Heperek / Editorial study {version}', 64, 66, 23)
    text('על הפרק', 1136, 245, 150, bold, 'right', 'rtl')
    text('אותיות עם אופי. מילים עם מקום.', 1136, 319, 40, regular, 'right', 'rtl')
    line(361)
    for name, position, weight in [('Regular', 244, 400), ('SemiBold', 600, 600), ('Bold', 956, 700)]:
        text(f'{name} {weight}', position, 405, 21, align='center')
        text('על הפרק', position, 494, 71, fonts[name], 'center', 'rtl')
    line(540)
    text('Hebrew / letterforms and final forms', 64, 588, 21)
    text('א ב ג ד ה ו ז ח ט י כ ל מ נ ס ע פ צ ק ר ש ת', 1136, 658, 39, semibold, 'right', 'rtl')
    text('ך ם ן ף ץ', 1136, 739, 59, semibold, 'right', 'rtl')
    text('דר  הח  בכ  וז  יו  מם  נן  פף  צץ', 64, 735, 35, regular, direction='rtl')
    line(782)
    for i, value in enumerate([
        'לימוד יומי מחבר אותנו אל המקורות, אל השפה ואל הסיפור שלנו.',
        'בכל יום נפתח פרק חדש, נקרא בתשומת לב ונמצא בו משמעות.',
        'הקריאה נעימה כשהאותיות מאוזנות, כשהרווחים טבעיים וכשהמילים זורמות יחד.',
    ]):
        text(value, 1136, 848 + i * 48, 30, regular, 'right', 'rtl')
    text('שָׁלוֹם, בְּרָכָה, שִׂמְחָה, לְךָ, כֵּן.', 1136, 1023, 36, semibold, 'right', 'rtl')
    line(1070)
    text('Al Heperek / A thoughtful daily reading', 64, 1132, 36, semibold)
    text('ABCDEFGHIJKLMNOPQRSTUVWXYZ', 64, 1191, 31)
    text('abcdefghijklmnopqrstuvwxyz   I l 1   rn m v w', 64, 1242, 31)
    text('0123456789   $ ¢ £ ¥ € © ® ™   @ # & ? !', 64, 1296, 30, semibold)
    line(1335)
    for i, size in enumerate((16, 20, 24, 32)):
        text(f'{size} px', 64, 1381 + i * 39, 18)
        text('על הפרק - לימוד יומי, קריאה טובה.', 1136, 1381 + i * 39, size, regular, 'right', 'rtl')
    text('Original contours / Restricted license / Design review pending', 64, 1551, 18)
    body.append('</svg>')
    (destination / 'font-review.svg').write_text(''.join(body), encoding='utf-8')
    faces = []
    for name, weight in [('Regular', 400), ('SemiBold', 600), ('Bold', 700)]:
        data = base64.b64encode((ROOT / 'dist/woff2' / f'AlHeperek-{name}.woff2').read_bytes()).decode('ascii')
        faces.append(f"@font-face{{font-family:AlHeperek;src:url(data:font/woff2;base64,{data}) format('woff2');font-weight:{weight};font-style:normal;font-display:swap}}")
    sizes = ''.join(f'<p><small>{size} px</small><span style="font-size:{size}px">על הפרק · פרשת השבוע · לקריאת הפרק</span></p>'
                    for size in (16, 24, 32, 48))
    page = (ROOT / 'tools/review.html').read_text(encoding='utf-8')
    for token, value in {'FACES': ''.join(faces), 'SIZES': sizes, 'VERSION': version,
                         'REFERENCES': '<!-- Local pairing proof -->',
                         'LICENSE': html.escape((ROOT / 'LICENSE').read_text(encoding='utf-8'))}.items():
        page = page.replace('{{' + token + '}}', value)
    (destination / 'index.html').write_text(page.rstrip() + '\n', encoding='utf-8')
    manifest = {'stage': 'editorial design review', 'version': version, 'fonts': {name: hashlib.sha256(file.read_bytes()).hexdigest() for name, file in fonts.items()}, 'specimens': ['inscription.svg', 'motifs.svg', 'font-review.svg', 'index.html']}
    (destination / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    print('Generated contour-design SVG proof and self-contained interactive WOFF2 specimen')


if __name__ == '__main__':
    generate()
