"""Author review-only shin alternatives; never replace a canonical font glyph.

Each alternative has one continuous outline around two open counters.  The
middle arm is drawn into the bowl, rather than bolted onto it with a union,
so the two interior returns have explicit horizontal/vertical tangencies.
Coordinates retain Yehuda's native body, shared left entry and cut heads.
"""

import json
from pathlib import Path

import pathops
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.svgLib.path import parse_path

from alternatives_motifs import left_entry, left_return

ROOT = Path(__file__).resolve().parents[1]


# These are individually chosen architectures, not a sweep of one parameter.
# lf/rf: counter-bottom position, ml: left side of the central arm's turn,
# mt: central head's left side, mr: right side of central arm's lower turn,
# ri/rt: right stem's inner foot/head.  Body and ink weight stay comparable.
PROFILES = [
    dict(
        name="קערה רציפה",
        note="שתי קערות מעוגלות וזרוע מרכזית זקופה שנפתחת בעדינות בבסיס.",
        lf=(72, 98),
        ml=(85, 79),
        mt=85,
        mr=(118, 82),
        rf=(130, 98),
        ri=145,
        rt=145,
        base=97,
        flat=0,
        ol=(23, 89),
    ),
    dict(
        name="חללים רחבים",
        note="שני החללים נפתחים לרוחב; בסיס אליפטי ארוך וזרוע מרכזית יציבה.",
        lf=(79, 98),
        ml=(94, 78),
        mt=94,
        mr=(127, 82),
        rf=(141, 98),
        ri=158,
        rt=158,
        base=105,
        flat=12,
        ol=(25, 86),
    ),
    dict(
        name="מבנה זקוף",
        note="מבנה צר ברוחב המקור: הזרועות כמעט אנכיות והקערה מתחילה נמוך.",
        lf=(57, 101),
        ml=(71, 83),
        mt=71,
        mr=(104, 84),
        rf=(117, 101),
        ri=131,
        rt=131,
        base=87,
        flat=24,
        ol=(21, 96),
    ),
    dict(
        name="מרכז שמאלה",
        note="הזרוע המרכזית נעה שמאלה לקראת החיבור, בקו רחב ורציף.",
        lf=(65, 98),
        ml=(78, 80),
        mt=91,
        mr=(111, 84),
        rf=(125, 98),
        ri=144,
        rt=146,
        base=94,
        flat=0,
        ol=(23, 90),
    ),
    dict(
        name="מרכז ימינה",
        note="הזרוע המרכזית נפתחת ימינה בתחתית ומאזנת את תנועת הזרוע השמאלית.",
        lf=(77, 96),
        ml=(93, 79),
        mt=83,
        mr=(126, 82),
        rf=(138, 96),
        ri=154,
        rt=151,
        base=101,
        flat=0,
        ol=(24, 88),
    ),
    dict(
        name="בסיס אופקי",
        note="תחתית ישרה עם פינות מעוגלות; החללים חוזרים לקו אופקי ברור.",
        lf=(71, 97),
        ml=(85, 81),
        mt=85,
        mr=(118, 84),
        rf=(131, 97),
        ri=149,
        rt=149,
        base=97,
        flat=44,
        ol=(22, 97),
    ),
    dict(
        name="קערה גבוהה",
        note="הפניות הפנימיות גבוהות ופתוחות יותר, והמרכז קצר ומרווח.",
        lf=(73, 87),
        ml=(86, 67),
        mt=86,
        mr=(119, 69),
        rf=(133, 87),
        ri=149,
        rt=149,
        base=98,
        flat=0,
        ol=(23, 78),
    ),
    dict(
        name="קערה נמוכה",
        note="הזרועות יורדות עמוק יותר; שני החללים צרים פחות בחלקם העליון.",
        lf=(70, 105),
        ml=(84, 87),
        mt=84,
        mr=(117, 88),
        rf=(131, 105),
        ri=148,
        rt=148,
        base=97,
        flat=16,
        ol=(22, 97),
    ),
    dict(
        name="תנועה אלכסונית",
        note="מרכז וזרוע ימנית נוטים יחד אל החיבור השמאלי, עם בסיס עגול.",
        lf=(63, 97),
        ml=(76, 79),
        mt=91,
        mr=(109, 82),
        rf=(125, 97),
        ri=143,
        rt=152,
        base=94,
        flat=0,
        ol=(25, 87),
    ),
    dict(
        name="מניפה פתוחה",
        note="הראשים מתרווחים כלפי מעלה והזרועות מתכנסות אל קערה אחת חלקה.",
        lf=(69, 99),
        ml=(82, 80),
        mt=87,
        mr=(115, 83),
        rf=(130, 99),
        ri=147,
        rt=158,
        base=98,
        flat=0,
        ol=(24, 90),
    ),
    dict(
        name="קצב מצטמצם",
        note="החלל השמאלי רחב והימני מהודק, בלי לדקק את הזרוע המרכזית.",
        lf=(81, 98),
        ml=(95, 80),
        mt=95,
        mr=(128, 82),
        rf=(141, 98),
        ri=156,
        rt=151,
        base=105,
        flat=16,
        ol=(24, 87),
    ),
    dict(
        name="קצב מתרחב",
        note="מרכז שמאלי מפנה חלל ימני נדיב; הקערה מתארכת אל הזרוע הימנית.",
        lf=(65, 98),
        ml=(78, 80),
        mt=80,
        mr=(111, 83),
        rf=(126, 98),
        ri=155,
        rt=155,
        base=99,
        flat=12,
        ol=(23, 89),
    ),
    dict(
        name="שמאל מורם",
        note="הקערה השמאלית מסתיימת גבוה מהימנית, ליצירת מקצב עולה ועדין.",
        lf=(73, 90),
        ml=(86, 70),
        mt=87,
        mr=(119, 83),
        rf=(133, 100),
        ri=150,
        rt=150,
        base=99,
        flat=0,
        ol=(23, 81),
    ),
    dict(
        name="ימין מורם",
        note="החלל הימני גבוה יותר והמרכז מתעקל בתחתיתו כלפי שמאל.",
        lf=(69, 101),
        ml=(82, 82),
        mt=87,
        mr=(115, 73),
        rf=(129, 91),
        ri=147,
        rt=147,
        base=96,
        flat=0,
        ol=(23, 91),
    ),
    dict(
        name="פינות רכות",
        note="מבנה מרובע וקומפקטי עם קימור מתון בתחתית וזרוע מרכזית כמעט ישרה.",
        lf=(61, 98),
        ml=(75, 82),
        mt=75,
        mr=(109, 83),
        rf=(122, 98),
        ri=137,
        rt=137,
        base=90,
        flat=36,
        ol=(20, 96),
    ),
    dict(
        name="זרימה קליגרפית",
        note="קשת שמאלית דינמית ומרכז נמשך; הימין מחזיר את התנועה פנימה.",
        lf=(78, 96),
        ml=(92, 77),
        mt=87,
        mr=(125, 81),
        rf=(139, 96),
        ri=156,
        rt=163,
        base=102,
        flat=0,
        ol=(27, 84),
    ),
    dict(
        name="מרכז מדורג",
        note="ראש המרכז מתחיל מעט נמוך יותר ומשאיר לזרועות החיצוניות להוביל.",
        lf=(73, 98),
        ml=(86, 80),
        mt=85,
        mr=(119, 82),
        rf=(133, 98),
        ri=150,
        rt=150,
        base=99,
        flat=8,
        ol=(23, 89),
        head_y=9,
    ),
    dict(
        name="מרכז מעוגן",
        note="מרכז רחב ואנכי עד החיבור; שתי קערות קטנות מפרידות אותו מהמסגרת.",
        lf=(63, 98),
        ml=(77, 80),
        mt=77,
        mr=(112, 82),
        rf=(125, 98),
        ri=139,
        rt=139,
        base=91,
        flat=28,
        ol=(21, 92),
    ),
    dict(
        name="קשת מאורכת",
        note="קערה אליפטית מתוחה עם מרכז זורם וזרוע ימנית מתוחה וישרה.",
        lf=(79, 96),
        ml=(93, 76),
        mt=98,
        mr=(126, 80),
        rf=(142, 96),
        ri=163,
        rt=163,
        base=107,
        flat=0,
        ol=(26, 84),
    ),
    dict(
        name="פתיחה מאוזנת",
        note="חללים פתוחים, ראש מרכזי מאופק ותחתית רחבה עם מעבר חלק בין הזרועות.",
        lf=(75, 95),
        ml=(89, 77),
        mt=86,
        mr=(122, 80),
        rf=(137, 95),
        ri=156,
        rt=153,
        base=102,
        flat=20,
        ol=(24, 87),
    ),
]


def outline(profile):
    """Trace one continuous perimeter, with explicit smooth counter returns."""
    lx, ly = profile["lf"]
    mlx, mly = profile["ml"]
    mtx = profile["mt"]
    mrx, mry = profile["mr"]
    rx, ry = profile["rf"]
    ri, rt = profile["ri"], profile["rt"]
    ro = rt + 35.6
    bx, flat = profile["base"], profile["flat"]
    olx, oly = profile["ol"]
    hy = profile.get("head_y", 0)
    bottom = 136.5
    # The reduced review cap keeps the source's lifted-tip direction. Its
    # endpoint tangents match these unchanged bowl controls exactly.
    source = (
        left_entry()
        + f"C 52.3 72.3 {lx - 17} {ly} {lx} {ly} "
        + f"C {lx + 9} {ly} {mlx - 1} {mly + 11} {mlx} {mly} "
        + f"C {mlx + 2} {mly - 22} {mtx + 2} {hy + 30} {mtx} {hy + 4.8} "
        + f"L {mtx + 25.4} {hy} {mtx + 35.6} {hy} "
        + f"C {mtx + 37.2} {hy + 34} {mrx + 12} {mry - 24} {mrx} {mry} "
        + f"C {mrx - 3} {mry + 6} {rx - 9} {ry} {rx} {ry} "
        + f"C {rx + 18} {ry} {ri} 83 {ri} 65 "
        + f"L {rt} 4.8 {rt + 25.4} 0 {ro} 0 "
        + f"L {ro - 1.5} 73 "
        + f"C {ro - 3} 113 {bx + 50} {bottom} {bx + flat / 2} {bottom} "
        + (f"L {bx - flat / 2} {bottom} " if flat else "")
        + f"C {bx - flat / 2 - 43} {bottom} {olx + 3} {oly + 30} {olx} {oly} "
        + f"C {olx - 1.2} {oly - 12} 18.8 55 14.3 40.2 "
        + left_return()
    )
    drawing = pathops.Path()
    parse_path(source, drawing.getPen())
    drawing = pathops.simplify(drawing, clockwise=False)
    drawing.convertConicsToQuads(0.02)
    pen = SVGPathPen(None)
    drawing.draw(pen)
    result = pen.getCommands()
    assert result and result.endswith("Z"), "Every candidate must be closed"
    return result


def generate():
    letters = [
        {
            "id": f"S{index:02d}",
            "name": profile["name"],
            "note": profile["note"],
            "paths": [outline(profile)],
        }
        for index, profile in enumerate(PROFILES, 1)
    ]
    assert len(letters) == 20
    assert len({entry["paths"][0] for entry in letters}) == 20
    destination = ROOT / "sources/yehuda/alternatives/shin.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps({"letters": {"ש": letters}}, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print("Authored 20 review-only shin alternatives; canonical font unchanged")


if __name__ == "__main__":
    generate()
