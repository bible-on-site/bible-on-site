"""Create the original review masters once; normal builds read the editable UFOs.

This is the authorship record for the initial geometric construction. Designers
can subsequently edit the UFO sources. Regeneration is explicit and will not
silently replace edited sources.
"""
from pathlib import Path
import argparse
import json
import sys
import tempfile

from ufoLib2 import Font

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from al_heperek.geometry import draw_spec
from al_heperek.hebrew import hebrew_glyphs as initial_hebrew_glyphs, niqqud_glyphs
from al_heperek.editorial_hebrew import hebrew_glyphs as editorial_hebrew_glyphs
from al_heperek.pen_hebrew import brand_letters
from al_heperek.reading_hebrew import reading_letters
from al_heperek.inscription_hebrew import inscription_letters
from al_heperek.nib_motifs import nib_for_weight
from al_heperek.hebrew_spacing import fit_hebrew
from al_heperek.editorial_latin import latin_glyphs

def glyph_name(character):
    return 'space' if character == ' ' else f'uni{ord(character):04X}'

def attach_hebrew_anchors(glyph, character, nib):
    thin = nib.thin
    middle = glyph.width / 2
    # Shuruk and dagesh on narrow uprights need space to the left of the ink.
    center_x = {'ו': 155-thin, 'ז': 134-thin, 'ן': 144-thin,
                'פ': 346, 'ף': 346}.get(character, middle)
    bottom_x = {'ך': 278, 'ן': 23}.get(character, middle)
    anchors = [('bottom', bottom_x, 175 if character == 'ך' else -65),
               ('top', 211-thin/2 if character == 'ו' else middle, 760),
               ('center', center_x, 320)]
    if character == 'ש':
        anchors.extend([('shin', 649-thin/2, 750), ('sin', 97, 750)])
    for name, x, y in anchors:
        glyph.appendAnchor({'name': name, 'x': round(x), 'y': y})

def bootstrap(overwrite=False):
    temporary = ROOT / 'build' / 'source-tmp'
    temporary.mkdir(parents=True, exist_ok=True)
    tempfile.tempdir = str(temporary)
    metrics = json.loads((ROOT / 'sources/metrics.json').read_text(encoding='utf-8'))
    license_text = (ROOT / 'LICENSE').read_text(encoding='utf-8')
    for style in metrics['styles']:
        stroke = style['stroke']
        reading_nib = nib_for_weight(style['weight'])
        display_nib = nib_for_weight(style['weight'], display=True)
        punctuation = {ch: drawing for ch, drawing in editorial_hebrew_glyphs(stroke).items()
                       if not 0x05D0 <= ord(ch) <= 0x05EA}
        glyphs = (latin_glyphs(stroke)
                  | {'₪': initial_hebrew_glyphs()['₪']}
                  | punctuation | reading_letters(reading_nib) | brand_letters(reading_nib) | niqqud_glyphs())
        cuts = {'ss01': reading_letters(display_nib) | brand_letters(display_nib),
                'ss02': inscription_letters(style['weight'])}
        assert all(not 0x0591 <= ord(ch) <= 0x05AF for ch in glyphs)
        assert set(map(chr, range(32, 127))) <= glyphs.keys()
        output = ROOT / 'sources' / f"AlHeperek-{style['name']}.ufo"
        assert output.resolve().parent == (ROOT / 'sources').resolve()
        if output.exists() and not overwrite:
            raise FileExistsError(f'{output}: source exists; use --overwrite only for deliberate regeneration')
        font = Font()
        info = font.info
        info.familyName = metrics['family']
        info.styleName = style['name']
        info.styleMapFamilyName = metrics['family'] if style['name'] in ('Regular','Bold') else f"{metrics['family']} {style['name']}"
        info.styleMapStyleName = 'bold' if style['name'] == 'Bold' else 'regular'
        info.unitsPerEm = metrics['unitsPerEm']
        info.ascender, info.descender = metrics['ascender'], metrics['descender']
        info.capHeight, info.xHeight = metrics['capHeight'], metrics['xHeight']
        info.versionMajor, info.versionMinor = metrics['versionMajor'], metrics['versionMinor']
        info.copyright = metrics['copyright']
        info.openTypeHeadCreated = metrics['created']
        info.openTypeHheaAscender, info.openTypeHheaDescender, info.openTypeHheaLineGap = 1000, -350, 0
        info.openTypeOS2TypoAscender, info.openTypeOS2TypoDescender, info.openTypeOS2TypoLineGap = 1000, -350, 0
        info.openTypeOS2WinAscent, info.openTypeOS2WinDescent = 1000, 350
        info.openTypeOS2WeightClass = style['weight']
        info.openTypeOS2WidthClass = 5
        info.openTypeOS2Selection = [7]
        info.openTypeOS2Type = [2]  # Preview & Print embedding; see the separate restricted license.
        info.openTypeOS2VendorID = 'NONE'
        info.openTypeNamePreferredFamilyName = metrics['family']
        info.openTypeNamePreferredSubfamilyName = style['name']
        info.openTypeNameDesigner = 'DoradSoft'
        info.openTypeNameManufacturer = 'DoradSoft'
        info.openTypeNameLicense = license_text
        info.openTypeNameLicenseURL = metrics['licenseUrl']
        info.postscriptFontName = f"AlHeperek-{style['name']}"
        info.postscriptUnderlinePosition, info.postscriptUnderlineThickness = -150, 55
        font.features.text = (ROOT / 'sources/features.fea').read_text(encoding='utf-8')
        missing = font.newGlyph('.notdef')
        draw_spec(missing, {'advance': 600, 'strokes': [[('M',100,35),('L',100,665),('L',500,665),('L',500,35),('Z',)], [('M',130,75),('L',470,625)]]}, style['stroke'])
        for character, spec in sorted(glyphs.items(), key=lambda item: ord(item[0])):
            glyph = font.newGlyph(glyph_name(character))
            glyph.unicodes = [ord(character)]
            draw_spec(glyph, spec, style['stroke'], character)
            if 0x05D0 <= ord(character) <= 0x05EA:
                attach_hebrew_anchors(glyph, character, reading_nib)
            if spec.get('mark'):
                glyph.appendAnchor({'name': '_' + spec['anchor'], 'x': 0, 'y': 0})
        alternate_names = []
        for tag, drawings in cuts.items():
            if set(drawings) != set(map(chr, range(0x05D0, 0x05EB))):
                raise ValueError(f'{tag} needs all 27 Hebrew letters and final forms')
            for character, drawing in sorted(drawings.items()):
                alternate = font.newGlyph(f'{glyph_name(character)}.{tag}')
                draw_spec(alternate, drawing, stroke, character)
                if tag == 'ss01':
                    attach_hebrew_anchors(alternate, character, display_nib)
                else:
                    for name, (x, y) in drawing['anchors'].items():
                        alternate.appendAnchor({'name': name, 'x': round(x), 'y': round(y)})
                alternate_names.append(alternate.name)
        font.glyphOrder = ['.notdef', 'space'] + [glyph_name(char) for char in sorted(glyphs, key=ord) if char != ' '] + alternate_names
        for left, right, value in [('A','V',-55),('A','W',-40),('T','o',-45),('T','a',-40),('V','a',-40),('W','a',-30),('Y','o',-45)]:
            font.kerning[(glyph_name(left), glyph_name(right))] = value
        fit_hebrew(font, style['weight'])
        font.lib['public.openTypeCategories'] = ({glyph_name(ch): 'mark' if spec.get('mark') else 'base' for ch, spec in glyphs.items()}
                                                | dict.fromkeys(alternate_names, 'base'))
        # Materialize the project's own anchor positions into standard OpenType
        # mark rules. This keeps attachment explicit and reviewable in each UFO.
        feature_lines = []
        for ch, spec in glyphs.items():
            if spec.get('mark'):
                feature_lines.append(f"markClass {glyph_name(ch)} <anchor 0 0> @MC_{spec['anchor']};")
        feature_lines += ['feature mark {', '  script hebr;', '  language dflt;']
        bases = [glyph_name(ch) for ch in glyphs if 0x05D0 <= ord(ch) <= 0x05EA]
        for name in bases + alternate_names:
            for anchor in font[name].anchors:
                feature_lines.append(f'  pos base {name} <anchor {round(anchor.x)} {round(anchor.y)}> mark @MC_{anchor.name};')
        feature_lines.append('} mark;')
        font.features.text += '\n' + '\n'.join(feature_lines) + '\n'
        font.save(output, overwrite=overwrite)
        print(f'Created {output.name}: {len(font)} original glyphs')
    charset = {'codepoints': sorted(ord(ch) for ch in glyphs), 'excludedCantillation': ['U+0591-U+05AF'], 'niqqud': 'Original basic vowel and dot glyphs; not Taamey D positioning data.'}
    (ROOT / 'sources/charset.json').write_text(json.dumps(charset, indent=2), encoding='utf-8')

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--overwrite', action='store_true', help='Deliberately regenerate initial master contours, replacing UFO edits')
    bootstrap(parser.parse_args().overwrite)
