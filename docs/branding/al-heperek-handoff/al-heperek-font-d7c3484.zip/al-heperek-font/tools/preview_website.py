"""Prepare an existing, separate website worktree for a local font review.

Generated font files, optional logo assets and local bootstrap artifacts are overlaid. The real
website sources, routes, content and font-loading code remain the reviewed site
checkout. No deployment, production database or store operation is performed.
"""

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def prepare(source_checkout, preview_checkout, node=None, logos=False):
    source_checkout = source_checkout.resolve()
    preview_checkout = preview_checkout.resolve()
    if source_checkout == preview_checkout:
        raise ValueError("Use a separate website worktree for the review")
    top = Path(
        subprocess.check_output(
            ["git", "rev-parse", "--show-toplevel"], cwd=preview_checkout, text=True
        ).strip()
    ).resolve()
    if top != preview_checkout:
        raise ValueError("Preview directory must be the website worktree root")
    site = preview_checkout / "web/bible-on-site"
    original_site = source_checkout / "web/bible-on-site"
    if not (site / "src/app/brand-font.ts").is_file():
        raise ValueError("The website checkout must include the brand font loader")
    manifest = json.loads(
        (ROOT / "dist/yehuda-ui/manifest.json").read_text(encoding="utf-8")
    )
    copied = []
    logo_files = []
    for style in ("Regular", "SemiBold", "Bold"):
        for extension, destination in (
            ("woff2", site / "public/fonts" / f"AlHeperekUI-{style}.woff2"),
            ("ttf", site / "src/lib/download/fonts" / f"AlHeperekUI-{style}.ttf"),
        ):
            source = (
                ROOT / f"dist/yehuda-ui/{extension}/AlHeperekUI-{style}.{extension}"
            )
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, destination)
            copied.append(
                {
                    "path": destination.relative_to(preview_checkout).as_posix(),
                    "sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
                }
            )
    if logos:
        logo_manifest = json.loads(
            (ROOT / "dist/yehuda/logos/manifest.json").read_text(encoding="utf-8")
        )
        expected = {entry["file"]: entry["sha256"] for entry in logo_manifest["files"]}
        relative_paths = [
            "public/images/logos/header-logo.svg",
            "public/images/logos/header-logo-reversed.svg",
            "public/images/logos/header-logo.jpg",
            "public/images/logos/logo192.webp",
            "public/images/logos/logo-white-letters-69.webp",
            "public/apple-touch-icon.png",
            "src/app/favicon.ico",
            "src/lib/download/logo_header.jpg",
        ] + [
            f"public/images/logos/favicon-{s}.{ext}"
            for s in (16, 24, 32, 48)
            for ext in ("svg", "png")
        ]
        for relative in relative_paths:
            source = original_site / relative
            data = source.read_bytes()
            sha = hashlib.sha256(data).hexdigest()
            if source.suffix == ".svg" and sha != expected[source.name]:
                raise ValueError(f"Logo is not from the current study: {source.name}")
            destination = site / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)
            logo_files.append(
                {
                    "path": destination.relative_to(preview_checkout).as_posix(),
                    "sha256": sha,
                }
            )
    # Reuse the already-populated local environment and generated canonical
    # artifact. Credentials stay in the local checkout and are never recorded.
    for relative in (
        ".dev.env",
        "src/data/db/sefaria-dump-5784-sivan-4.tanah_view.json.br",
    ):
        source = original_site / relative
        if source.is_file():
            shutil.copyfile(source, site / relative)
    if node:
        for script, arguments in (
            ("scripts/generate-client-catalog.mjs", []),
            ("scripts/collect-store-metadata.mts", ["--ensure"]),
            ("scripts/copy-local-flip-book.mjs", []),
        ):
            subprocess.run([str(node), script, *arguments], cwd=site, check=True)
    report = {
        "fontVersion": manifest["version"],
        "fontCut": manifest["defaultHebrewCut"],
        "websiteCommit": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=preview_checkout, text=True
        ).strip(),
        "fonts": copied,
        "logos": logo_files,
    }
    (ROOT / "build").mkdir(exist_ok=True)
    (ROOT / "build/website-preview.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8"
    )
    print(
        f"Prepared actual website with {len(copied)} font and {len(logo_files)} logo assets; local configuration stays private"
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-checkout", type=Path, required=True)
    parser.add_argument("--preview-checkout", type=Path, required=True)
    parser.add_argument(
        "--logos",
        action="store_true",
        help="Include the current outlined logos from the source website checkout",
    )
    parser.add_argument(
        "--node",
        type=Path,
        help="Run the website postinstall generators with this Node executable",
    )
    args = parser.parse_args()
    prepare(args.source_checkout, args.preview_checkout, args.node, args.logos)
