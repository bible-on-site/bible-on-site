# Provenance

Al Heperek Font is an independently authored typeface and implementation. Its original sources and generated fonts are copyright © 2026 DoradSoft and are subject to the repository's restricted [LICENSE](LICENSE).

## Original material

The Hebrew and Latin glyph constructions, punctuation, metrics, spacing, features, source-generation helpers, build orchestration and QA cases in this repository are created for Al Heperek Font. The version 0.9 reconstruction additionally uses the user-supplied AI-created SVG lettering documented below. Generated font files are compiled from the committed editable sources.

The build must remain traceable to the committed UFO masters. A font file obtained from another project is not an acceptable replacement for those sources, even if renamed or converted to another format.

## Taamey D references

The following upstream material was consulted to understand project organization and visual compatibility:

- Historical repository: [bdenckla/Taamey_D](https://github.com/bdenckla/Taamey_D), reference commit `1c32c5b8a2a4d7188248e2cd349131e4b38aec7e` dated 29 October 2026.
- Current project: [MAM-basics / Taamey-D](https://github.com/bdenckla/MAM-basics/tree/main/Taamey-D).
- Current upstream [README](https://github.com/bdenckla/MAM-basics/blob/main/Taamey-D/README.md) and [license](https://github.com/bdenckla/MAM-basics/blob/main/Taamey-D/LICENSE.md).

The references are not build dependencies. No Taamey D repository history, font binaries, glyph outlines, sources, anchors, positioning data, OpenType feature definitions, hinting, QA fixtures or build scripts are imported into this repository. Structural ideas such as separating authored sources, generated fonts, QA input and specimen output are implemented independently.

Taamey D continues to be used separately for cantillated text under its GPL license and font-embedding exception. Al Heperek Font does not support Hebrew cantillation U+0591–U+05AF, and its license does not alter users' rights in Taamey D.

## Visual and design-method references for version 0.2

For version 0.2, the supplied Yehuda brand SVG was inspected visually for compact proportions,
horizontal emphasis, tapered terminals and curve tension. Its path coordinates
were not used in that iteration's font sources. The first centerline-based experiment was
rejected as a brand design; its replacement Hebrew and Latin letter contours were
drawn afresh for the editorial study.

The design process also consulted primary descriptions of professional practice:

- [Peter Bilak, Designing Hebrew Type](https://www.typotheque.com/articles/designing-hebrew-type): script-specific proportions, optical weight and individually considered terminations.
- [Fontef, The Lyon Family](https://fontef.com/read/lyon): the relationship of Hebrew text rhythm, calligraphic models and contemporary editorial use.

These are visual/method references, not sources of glyph contours, point
coordinates, font binaries, spacing tables or feature code.

## Visual references for version 0.3

For version 0.3 we examined the printed specimens of [Kedem Serif](https://alefalefalef.co.il/wp-content/fonts/kedem-serif/kedem-serif-specimen.pdf) and Fontef's [Narkiss Text optical sizes](https://fontef.com/narkiss-text). They informed the use of reading-size and headline-size proofs. The repeated shoulders, bowl turns, entrances and returning arms in this project were drawn in original font coordinates. The reference specimens and third-party fonts are external to the build.

## Visual references for version 0.4

We compared printed alefs in [AlefAlefAlef's Hebrew type anatomy](https://alefalefalef.co.il/en/anatomy-of-type/) and its Kedem specimen with rendered examples from the project's copy of [Taamey D](https://bdenckla.github.io/Taamey_D/). The reference also informed how we assessed the lamed in words. The arm attachments, contour tension and pen release in this revision were drawn and adjusted in the Al Heperek sources. The local comparison displays the reference font separately at matched Hebrew body height.

## Visual references for version 0.5

We looked at the word and paragraph settings in Fontef's [Liebling](https://fontef.com/liebling) and [Hadassah Friedlaender](https://fontef.com/hadassah-friedlaender) specimens. We drew the roof turns, bowls and terminals in the Al Heperek sources and fitted the spacing against words rendered from our own masters. The before-and-after sheet uses only Al Heperek font files.

## Visual references for version 0.6

We compared words in the site's Taamey D and Frank Ruhl Libre at matched Hebrew body heights, and examined David Libre in the earlier brand proof. The horizontal emphasis, the movement of ink across a shoulder and the white spaces inside a fork informed the comparison. All Al Heperek contours, including the shared head on alef and tsadi, were drawn in this project's own masters. The font build uses no third-party font assets. [Taamey D specimens](https://bdenckla.github.io/Taamey_D/) · [Frank Ruhl Libre project](https://github.com/fontef/frankruhllibre) · [David Libre project](https://github.com/meirsadan/david-libre)

## Inscription study

The photograph of the long inscription in the entrance mosaic of the Rehov synagogue provided a visual reference for the rhythm of open space in a Hebrew line. The study uses independently drawn outlines. The cupped ends, flaring feet, spacing and mark anchors are our own interpretation for a contemporary book heading. The font and its distributed proofs contain only Al Heperek outlines. [Fanny Vitto, *Wall Paintings in the Synagogue of Rehov: An Account of Their Discovery*, fig. 1](https://museum.imj.org.il/journal/archive/2015/images/Fanny%20Vitto.pdf)

## Yehuda SVG reconstruction / 0.9

On 16 November 2026 Dorad explicitly requested a reconstruction using the actual
elements of Yehuda's supplied SVG. Dorad confirmed that Yehuda made the SVG
with AI, rather than converting lettering from an existing font in design
software. This is the provenance supplied by the project owner, not a claim
that a visual font-identification search can establish authorship.

`sources/yehuda/icon.svg` preserves the supplied file byte for byte.
`sources/yehuda/lettering.json` records its SHA-256 and the seven extracted
letter outlines: ת נ ך ה פ ר ק. The separate sans-serif ע ל in that SVG is
excluded from the reconstruction to avoid mixing two designs.

At Bold 700 those seven outlines retain the SVG curves, normalized to a
650-unit Hebrew body and individually spaced. Compilation rounds the curves
to the TrueType grid. The other twenty letters were constructed for this
study using the source's recurring shoulder, sloping entry, upright, return
and cut foot. Alef, tsadi and final tsadi share an authored upper-right arm;
lamed shares the supplied qof's descending curve. Lighter weights use inward
contour offsets with a matched body height. Their editable results are stored
in the UFOs as `ss03` glyphs.

The existing `ss02` contours remain unchanged. Neither the Bible's Taamey D
outlines nor any other third-party font was used to draw or build the new cut.
The local comparison loads Taamey D separately from an ignored `build/reference/`
directory; it is not a build input or part of the study font. The reference's
GPL license stays separate. The AI SVG origin and reconstruction do not change
the repository's existing restricted distribution policy.

### Review refinement / 0.9.1

Dorad's review identified a protruding foot on bet and final mem, contact
between tet's arms, a crossing tsadi join, and left entries that curled in
the opposite direction from the source lettering. The bet and final-mem
uprights now end within their flat floor. Tet has an open channel between
its arms. The right arms of tsadi and final tsadi terminate inside the main
stroke. Alef, tet, mem, ayin, tsadi, shin and final tsadi now share a left
entrance following the supplied tav's lifted corner and forward turn.
The seven supplied Bold glyphs remain unchanged.

The optional `tools/preview_website.py` overlays the review font in a separate
local checkout of the actual website. It reuses the site's font loader and
routes, and records font hashes plus the website commit in ignored build
output. Local environment values are not included in that record or committed.

### Stroke fitting and figures / 0.9.2

The narrowed arms and diagonals of alef, tsadi, final tsadi, gimel, ayin and
shin are fitted to the supplied resh's 32.4-unit stem. The six letters use
continuous, explicitly drawn contours rather than joins between clipped pen
strokes. Alef, tsadi and final tsadi share one right-arm construction; alef's
lower-left leg leaves room for the diagonal and the right arm. Gimel's head
and feet remain connected after thinning to Regular, shin has a smooth
lower-left turn, and ayin's return finishes on the common baseline. Protected
upper-left entrances and the original seven Bold letters remain reference
boundaries. The new figures in
`yehuda_digits.py` are original drawings, with the same stem and weight model,
40.4-unit horizontal bars and optical compensation on curved figure turns.
Their width is 640 units in each master. No third-party figure outlines or
font data contribute to them.

The figures are stored as editable `ss03` UFO alternates. The feature selects
them in DFLT, Latin and Hebrew runs; the standalone study export maps their
Unicode codepoints directly. Compiled-font probes measure actual ink normal
to the stems, curves and diagonals in all three weights.

### Logo layouts and exports

The glyph-free layouts in `sources/yehuda/logo-layouts/` retain this project's
existing book symbol, blue palette and text placement. Their previous text
outlines and stale font labels were removed. `tools/yehuda_logos.py` replaces
every text placeholder with actual HarfBuzz-shaped Bold `ss03` outlines from
the compiled Al Heperek font. The output records the font hash and version;
no system font, external font outline or raster lettering is used. The
horizontal logo remains על הפרק beside the unframed emblem. The launcher
has one background tile; operating-system masks are applied separately.

### Unselected letter explorations

At Dorad's request, `sources/yehuda/alternatives/` contains 20 independently
authored alternatives each for א ע ט צ ש. Their deterministic authoring helpers
construct original cubic contours and expanded strokes using the project's
existing motifs. No third-party outlines, font data or drawing code were added.
The rendered specimens use the current compiled Bold `ss03` glyphs for the
surrounding letters, with the same HarfBuzz kerning in the comparison words.
These are review proposals only: the canonical UFOs, font versions, installed
fonts, application and existing logo assets remain unchanged. The proposed wide
layout reuses the project's existing book artwork beside a single wordmark,
omitting the stacked name that duplicated it.

The next review identified an oversized exposed left head, most noticeably on
alef. `tools/alternatives_motifs.py` provides a separate, optically smaller head
for the review proposals, rather than changing the protected source lettering.
Its ink area is about 27% smaller. The three proposal authoring helpers share
that head and fit its neck to each existing body. Proposal IDs and skeletons
remain stable. The exact prior drawings used by the comparison are preserved
in `sources/yehuda/review-reference/left-head-before.json`, with their source
commit. The comparison generator reads this fixture without requiring older
Git history. A local scope audit also compares all 100 actual outlines with
the previous commit and verifies the bodies below the head remain intact.

### Low-node refinements around the shortlisted directions

Dorad identified A01, E09, T07, C01 and S03 as the nearest directions, explicitly
not as finished or approved designs. The second round in
`sources/yehuda/refinements/` contains 20 newly drawn variations around each of
those directions, plus a matched final tsadi for every tsadi. The three
`tools/refine_*.py` helpers trace independent continuous Bézier perimeters;
stroke expansion, outline unions and morphological closing do not author them.
Geometry libraries are used only for read-only validity checks. The review
renderer preserves the authored segments through a single affine transform.

Every card renders all 27 Hebrew letters and ten digits from the project font,
with the active proposal substituted and highlighted. Other shortlisted or
newly selected forms provide the context. The baseline final tsadi is a
review-only companion constructed to match C01; it is not claimed to have been
present in the previous round or in the installed font. New C21-C40 choices each
carry their own final form. None of these proposals changes the canonical UFOs,
font binaries, terms, license, application or deployed logos.

### Saved second-round selection

Dorad selected A22, E26, T21, C28 and S35, with C28's own final tsadi. The saved
recipe names the second-round source revision and exact IDs. A separate Bold
review export combines those six forms with the canonical master's remaining
glyphs. It is built from a temporary UFO clone, without changing the committed
masters. Its CFF outlines preserve the selected Bézier perimeters; conversion
of quadratic turns to cubic curves is exact degree elevation, not geometric
fitting. The output manifest records source hashes, actual authored/compiled
anchor counts, measured coordinate precision and the unchanged master hash.

The selected review's nine logos are outlined from this same compiled face.
Their metadata records the review font hash and the chosen IDs. The wide
proposal keeps only the wordmark and existing project-owned book symbol.
Neither this combined review nor its separate export constitutes production
font adoption or store publication. The existing restricted license applies.

## Build-tool boundary

The open-source tools listed in [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) compile and inspect original Al Heperek material. They are not the source of its glyph designs. Their own software licenses remain in force for those tools and are not replaced by the Al Heperek Font license.

Keep this record current when adding any external material or a new source of glyph, feature or positioning data. Do not describe an imported or modified third-party font as independently authored.
